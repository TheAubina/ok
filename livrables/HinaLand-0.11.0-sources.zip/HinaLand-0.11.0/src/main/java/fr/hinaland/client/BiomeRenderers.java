package fr.hinaland.client;
import fr.hinaland.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
@Mod.EventBusSubscriber(modid=HinaLand.ID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class BiomeRenderers {
 @SubscribeEvent public static void register(EntityRenderersEvent.RegisterRenderers event){event.registerEntityRenderer(BiomeMobs.OMOCHAO.get(),context->new GeoEntityRenderer<Omochao>(context,new GeoModel<Omochao>(){
 public ResourceLocation getModelResource(Omochao e){return new ResourceLocation(HinaLand.ID,"geo/omochao.geo.json");}
 public ResourceLocation getTextureResource(Omochao e){return new ResourceLocation(HinaLand.ID,"textures/entity/biome/omochao.png");}
 public ResourceLocation getAnimationResource(Omochao e){return new ResourceLocation(HinaLand.ID,"animations/omochao.animation.json");}
 }){});event.registerEntityRenderer(BiomeMobs.DARKNER_BOLT.get(),context->new net.minecraft.client.renderer.entity.ThrownItemRenderer<>(context));for(String id:BiomeMobs.NAMES)event.registerEntityRenderer(BiomeMobs.ENTITIES.get(id).get(),context->new GeoEntityRenderer<BiomeMobs.ThemedEntity>(context,new GeoModel<BiomeMobs.ThemedEntity>(){
 public ResourceLocation getModelResource(BiomeMobs.ThemedEntity e){return new ResourceLocation(HinaLand.ID,"geo/"+id+".geo.json");}
 public ResourceLocation getTextureResource(BiomeMobs.ThemedEntity e){return new ResourceLocation(HinaLand.ID,"textures/entity/biome/"+id+".png");}
 public ResourceLocation getAnimationResource(BiomeMobs.ThemedEntity e){return new ResourceLocation(HinaLand.ID,"animations/"+id+".animation.json");}
 }){
 @Override public void renderRecursively(com.mojang.blaze3d.vertex.PoseStack pose,BiomeMobs.ThemedEntity entity,software.bernie.geckolib.cache.object.GeoBone bone,net.minecraft.client.renderer.RenderType type,net.minecraft.client.renderer.MultiBufferSource buffers,com.mojang.blaze3d.vertex.VertexConsumer vertices,boolean reRender,float partial,int light,int overlay,float red,float green,float blue,float alpha){
  if(id.equals("koopa")&&bone.getName().equals("body")){
   type=net.minecraft.client.renderer.RenderType.entityCutoutNoCull(new ResourceLocation(HinaLand.ID,"textures/entity/biome/koopa_shell.png"));vertices=buffers.getBuffer(type);
  }
  super.renderRecursively(pose,entity,bone,type,buffers,vertices,reRender,partial,light,overlay,red,green,blue,alpha);
 }
 });}
}
