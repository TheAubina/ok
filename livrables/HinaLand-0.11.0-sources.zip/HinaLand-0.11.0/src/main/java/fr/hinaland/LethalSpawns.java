package fr.hinaland;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=HinaLand.ID,bus=Mod.EventBusSubscriber.Bus.MOD)
public final class LethalSpawns {
 @SubscribeEvent public static void placements(SpawnPlacementRegisterEvent e){
  for(var type:LethalMobs.ENTITIES.values())e.register(type.get(),SpawnPlacements.Type.ON_GROUND,Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
   (t,level,reason,pos,random)->IndoorHabitat.isInterior(level,pos)&&Monster.checkMonsterSpawnRules(t,level,reason,pos,random),SpawnPlacementRegisterEvent.Operation.REPLACE);
 }
}
