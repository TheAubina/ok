package fr.hinaland;

import com.mojang.datafixers.util.Pair;
import java.util.*;
import java.util.function.Consumer;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.*;
import net.minecraft.world.level.biome.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.VerticalAnchor;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import terrablender.api.*;

/** Broad themed land regions; oceans, rivers, caves and a vanilla region remain. */
@Mod.EventBusSubscriber(modid=HinaLand.ID,bus=Mod.EventBusSubscriber.Bus.MOD)
public final class HinaWorldgen {
 public static final List<String> FAMILIES=List.of("mario","sonic","omori","deltarune","genshin","overwatch","lethal");
 public static final List<String> VARIANTS=List.of("","_forest","_highlands","_dunes");
 public static ResourceKey<Biome> biome(String name){return ResourceKey.create(Registries.BIOME,new ResourceLocation(HinaLand.ID,name));}
 public static String family(ResourceLocation id){
  if(!id.getNamespace().equals(HinaLand.ID))return "vanilla";
  for(String name:FAMILIES)if(id.getPath().equals(name)||id.getPath().startsWith(name+"_"))return name;
  return "vanilla";
 }
 public static String variant(String vanilla){
  if(Set.of("nether_wastes","soul_sand_valley","crimson_forest","warped_forest","basalt_deltas","the_end","end_highlands","end_midlands","small_end_islands","end_barrens").contains(vanilla))return null;
  if(vanilla.contains("ocean")||vanilla.contains("river")||Set.of("deep_dark","dripstone_caves","lush_caves").contains(vanilla))return null;
  if(vanilla.contains("beach")||vanilla.contains("desert")||vanilla.contains("badlands"))return "_dunes";
  if(vanilla.contains("peak")||vanilla.contains("mountain")||vanilla.contains("windswept")||vanilla.contains("grove")||vanilla.contains("slope")||vanilla.equals("stony_shore")||vanilla.equals("meadow"))return "_highlands";
  if(vanilla.contains("forest")||vanilla.contains("jungle")||vanilla.contains("taiga")||vanilla.contains("swamp")||vanilla.contains("cherry"))return "_forest";
  return "";
 }
 private static SurfaceRules.RuleSource block(String name){return SurfaceRules.state(HinaLand.WORLD_BLOCKS.get(name).get().defaultBlockState());}
 @SubscribeEvent public static void setup(FMLCommonSetupEvent e){e.enqueueWork(()->{
  for(String name:FAMILIES)Regions.register(new Region(new ResourceLocation(HinaLand.ID,name),RegionType.OVERWORLD,12){
   @Override public void addBiomes(Registry<Biome> registry,Consumer<Pair<Climate.ParameterPoint,ResourceKey<Biome>>> mapper){
    addModifiedVanillaOverworldBiomes(mapper,builder->{
     for(ResourceKey<Biome> original:registry.registryKeySet()){
      if(!original.location().getNamespace().equals("minecraft"))continue;
      String replacement=variant(original.location().getPath());
      if(replacement!=null)builder.replaceBiome(original,biome(name+replacement));
     }
    });
   }
  });
  List<SurfaceRules.RuleSource> rules=new ArrayList<>();
  for(String name:FAMILIES)for(String suffix:VARIANTS){
   SurfaceRules.RuleSource top=suffix.equals("_dunes")?block(name+"_sand"):suffix.equals("_highlands")?
    SurfaceRules.sequence(SurfaceRules.ifTrue(SurfaceRules.yBlockCheck(VerticalAnchor.absolute(120),0),block(name+"_snow")),SurfaceRules.ifTrue(SurfaceRules.steep(),block(name+"_stone")),block(name+"_soil")):block(name+"_soil");
   rules.add(SurfaceRules.ifTrue(SurfaceRules.isBiome(biome(name+suffix)),SurfaceRules.sequence(
    // Unbreakable themed floor; the matching rock continues below zero.
    SurfaceRules.ifTrue(SurfaceRules.verticalGradient("hinaland:bedrock_floor",VerticalAnchor.bottom(),VerticalAnchor.aboveBottom(5)),block(name+"_bedrock")),
    SurfaceRules.ifTrue(SurfaceRules.abovePreliminarySurface(),SurfaceRules.ifTrue(SurfaceRules.ON_FLOOR,SurfaceRules.sequence(SurfaceRules.ifTrue(SurfaceRules.not(SurfaceRules.waterBlockCheck(-1,0)),block(name+"_sand")),top))),
    SurfaceRules.ifTrue(SurfaceRules.abovePreliminarySurface(),SurfaceRules.ifTrue(SurfaceRules.UNDER_FLOOR,block(name+(suffix.equals("_dunes")?"_sandstone":"_dirt")))),
    block(name+"_stone"))));
  }
  SurfaceRuleManager.addSurfaceRules(SurfaceRuleManager.RuleCategory.OVERWORLD,HinaLand.ID,SurfaceRules.sequence(rules.toArray(SurfaceRules.RuleSource[]::new)));
 });}
}
