# Hina Land 0.11.0 — bêta Forge

Minecraft Java 1.20.1, Forge 47.3.0, Java 17. JAR : GeckoLib 4.4.9 et TerraBlender 3.0.1.7 requis.

Sept univers dans l’Overworld, avec plaines, forêts, hauts plateaux et dunes : Mario, Sonic, OMORI, DELTARUNE, Genshin, Overwatch et Lethal (28 biomes). Blocs et sous-sol thématiques jusqu’au bedrock, 24 fleurs issues des packs, cinq pistes musicales Mario/Sonic/OMORI et ciel étoilé OMORI.

Dix ennemis thématiques et Omochao amical, plus les sept monstres Lethal Company. Ces sept monstres, Ghost Girl comprise, sont limités aux zones couvertes définies par la règle d’intérieur. Vingt-sept objets MirRP sont disponibles dans de petits postes de récupération générés naturellement. Les 32 structures et décors fournis sont intégrés avec leurs coffres. Le Nether mêle les 63 biomes vanilla jouables sur un terrain ouvert ; lits et sommeil y fonctionnent. L’End custom reste à réaliser. Voir RAPPORT_MONDES_STRUCTURES_0.11_FR.md pour les détails, adaptations et limites.

## Jouer

Remplacer l’ancien JAR Hina Land. Ne pas conserver plusieurs versions. Le pack complet contient 22 JAR : utiliser de préférence une nouvelle instance Forge et y copier mods, config et resourcepacks. Activer le petit pack d’intégration des autres mods. Les textures sélectionnées des cinq gros packs sont incorporées dans le JAR ; inutile de les activer globalement.

Créer un monde neuf pour reproduire le Nether modifié testé ici. La migration de l’ancien Nether n’est pas validée. Les nouvelles régions et structures Overworld nécessitent des chunks neufs. Utiliser les œufs Lethal dans une salle couverte. Rudinn et Hathy peuvent être apaisés temporairement par un clic à main vide. Une pépite d’or répare Omochao. Les musiques suivent le réglage Musique de Minecraft.

## Compiler les sources

Installer Java 17, puis utiliser le wrapper Gradle 8.8 fourni :

```sh
./gradlew build --max-workers=2
./gradlew runGameTestServer --max-workers=2
```

Sous Windows : gradlew.bat build. Le JAR reobfusqué est produit dans build/libs. Les tâches client et server lancent l’environnement de développement. Forge et les bibliothèques sont téléchargés automatiquement depuis leurs dépôts configurés ; accès réseau nécessaire au premier lancement.

Les ressources générées sont déjà incluses : aucune archive originale n’est requise pour compiler. Les scripts import_* dans tools servent au travail d’import et nécessitent les packs originaux dans imported-packs ou imported-worlds (nbtlib requis pour les structures) ; il n’est pas nécessaire de les relancer pour un build normal. tools/cloud-env.sh est spécifique au workspace cloud et ne doit pas être utilisé sur un autre ordinateur.

## Validation et limites

25 GameTests Forge passés. Audit réel du générateur : 28 biomes Hina Land observés dans l’Overworld et 58 des 63 biomes vanilla dans le Nether. 1469 JSON et 18 modèles contrôlés. Les contrôles de chunks et de structures sont détaillés dans le rapport 0.11. Client et serveur de production chargés avec les 22 JAR. Les tests ne valident pas une campagne complète ou tous les clips d’animation.

Les IA sont adaptées à Minecraft, pas reproduites intégralement. Rudinn/Hathy sont des sprites dans le monde 3D. Plusieurs autres modèles CEM restent à identifier et convertir. Boss, lunes Lethal, quotas, vaisseau et transport de coffres restent à développer. Lunaria Media manque au pack, avec trois succès de quête bloqués ; le mod de quêtes fourni peut dupliquer ses chapitres au redémarrage.

Les documents 0.6–0.10 conservés dans les sources sont historiques : les textures de fleurs manquantes en 0.9 sont désormais intégrées.
