"""Inspect actual generated FULL Nether chunks; retain raw biome/block evidence."""
from pathlib import Path
import sys,json,collections
from read_region import chunks
world=Path(sys.argv[1]);sites=json.loads(Path(sys.argv[2]).read_text());wanted={(x//16,z//16):k for k,(x,z) in sites.items()};out={}
for n in chunks(world):
 pos=(int(n.get('xPos',0)),int(n.get('zPos',0)))
 if pos not in wanted or str(n.get('Status'))!='minecraft:full':continue
 count=collections.Counter();actual=None
 for s in n['sections']:
  if int(s['Y'])==5:
   b=s['biomes'];p=b['palette'];bits=max(1,(len(p)-1).bit_length());index=(int(b.get('data',[0])[0])&((1<<bits)-1)) if len(p)>1 else 0;actual=str(p[index])
  b=s.get('block_states',{});p=[str(v['Name']) for v in b.get('palette',[])];packed=b.get('data',[])
  if len(p)==1:count[p[0]]+=4096
  elif p:
   bits=max(4,(len(p)-1).bit_length());per=64//bits;mask=(1<<bits)-1
   for i in range(4096):count[p[(int(packed[i//per])>>((i%per)*bits))&mask]]+=1
 key=wanted[pos];assert actual==key,(key,actual)
 host='netherrack' if key in ['minecraft:nether_wastes','minecraft:crimson_forest','minecraft:warped_forest'] else 'soul_soil' if key=='minecraft:soul_sand_valley' else 'basalt' if key=='minecraft:basalt_deltas' else 'end_stone' if key in ['minecraft:the_end','minecraft:end_highlands'] else 'grass_block'
 assert count['minecraft:'+host]>0,(key,host)
 assert count['minecraft:bedrock']>0,key
 if key in ['minecraft:crimson_forest','minecraft:warped_forest']:assert count['minecraft:'+('crimson_nylium' if key=='minecraft:crimson_forest' else 'warped_nylium')]>0,key
 out[key]={'chunk':pos,'biome_y80':actual,'blocks':dict(sorted(count.items()))}
assert len(out)==len(sites),(len(out),len(sites));Path(sys.argv[3]).write_text(json.dumps(out,indent=2));print('Validated',len(out),'natural mixed Nether sites, host blocks and bedrock')
