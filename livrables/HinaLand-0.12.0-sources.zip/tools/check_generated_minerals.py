"""Count actual mineral blocks in saved FULL chunks; run before any manual mineral placement."""
import collections,json,sys
from pathlib import Path
from read_region import chunks
world=Path(sys.argv[1]);sites=json.loads(Path(sys.argv[2]).read_text());manifest=json.loads((Path(__file__).resolve().parents[1]/'universe-minerals-0.12.json').read_text())
materials={r['material']+'_ore':r for r in manifest};wanted={};results={f:{'site':p,'full_chunks':0,'minerals':{}} for f,p in sites.items()}
for f,(x,z) in sites.items():
 for dx in range(-1,2):
  for dz in range(-1,2):wanted[(x//16+dx,z//16+dz)]=f
for n in chunks(world):
 cx,cz=int(n.get('xPos',0)),int(n.get('zPos',0));f=wanted.get((cx,cz))
 if f is None or str(n.get('Status')) not in {'minecraft:full','full'}:continue
 report=results[f];report['full_chunks']+=1
 for section in n.get('sections',[]):
  bs=section.get('block_states',{});palette=[str(s['Name']) for s in bs.get('palette',[])];oreindices={i:s.split(':',1)[1] for i,s in enumerate(palette) if s.startswith('hinaland:') and s.split(':',1)[1] in materials}
  if not oreindices:continue
  bits=max(4,(len(palette)-1).bit_length());per=64//bits;mask=(1<<bits)-1;data=bs.get('data',[])
  for i in range(4096):
   index=(int(data[i//per])&((1<<64)-1))>>((i%per)*bits)&mask if len(palette)>1 else 0
   if index not in oreindices:continue
   ore=oreindices[index];m=materials[ore];y=int(section['Y'])*16+(i>>8);p=[cx*16+(i&15),y,cz*16+((i>>4)&15)]
   entry=report['minerals'].setdefault(ore,{'count':0,'min_y':y,'max_y':y,'samples':[]});entry['count']+=1;entry['min_y']=min(entry['min_y'],y);entry['max_y']=max(entry['max_y'],y)
   if len(entry['samples'])<3:entry['samples'].append(p)
   assert m['min_y']-8<=y<=m['max_y']+8,(ore,'unexpected generation height',p)
for f,r in results.items():
 assert r['full_chunks']==9,(f,'missing FULL chunks',r['full_chunks'])
 for m in (m for m in manifest if m['family']==f):assert r['minerals'].get(m['material']+'_ore',{}).get('count',0)>0,(f,'no naturally generated mineral',m['material'])
Path(sys.argv[3]).write_text(json.dumps(results,indent=2)+'\n');print('Verified all 14 new minerals in 63 naturally generated FULL chunks across seven families')
for f,r in results.items():print(f,{m:d['count'] for m,d in r['minerals'].items()})
