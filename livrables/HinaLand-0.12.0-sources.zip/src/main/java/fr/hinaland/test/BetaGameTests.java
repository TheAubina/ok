package fr.hinaland.test;
import fr.hinaland.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.level.biome.Biome;
import net.minecraftforge.gametest.*;

@GameTestHolder("hinaland")
@PrefixGameTestTemplate(false)
public class BetaGameTests {
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void registeredEntities(GameTestHelper h){
  for(var r:BiomeMobs.ENTITIES.values()){var mob=r.get().create(h.getLevel());h.assertTrue(mob!=null&&mob.getMaxHealth()>0,"Biome mob creation/attributes");h.assertFalse(((LivingEntity)mob) instanceof net.minecraft.world.entity.monster.Zombie,"No disguised zombie");}
  for(var r:LethalMobs.ENTITIES.values()){var mob=r.get().create(h.getLevel());h.assertTrue(mob!=null&&mob.getMaxHealth()==30,"Lethal creation/attributes");}
  h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void biomeSpawnIsolation(GameTestHelper h){
  var registry=h.getLevel().registryAccess().registryOrThrow(Registries.BIOME);
  for(String region:HinaWorldgen.FAMILIES)for(String suffix:HinaWorldgen.VARIANTS){
   Biome b=registry.getOrThrow(HinaWorldgen.biome(region+suffix));var spawns=b.getMobSettings().getMobs(MobCategory.MONSTER).unwrap();
   var themed=spawns.stream().filter(entry->!net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getKey(entry.type).getPath().startsWith("lethal_")).toList();
   h.assertTrue(themed.size()==(region.equals("mario")?4:java.util.Set.of("genshin","overwatch","lethal").contains(region)?0:2),"Expected natural themed spawn entries in "+region);
   for(var s:themed){String name=net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getKey(s.type).getPath();h.assertTrue(BiomeMobs.region(name).equals(region),"Mob belongs to biome");}
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=100)
 public static void hoardingPickupPersistenceAndDrop(GameTestHelper h){
  var bug=h.spawn(LethalMobs.ENTITIES.get("hoarding_bug").get(),2,2,2);bug.setNoAi(true);bug.setNoGravity(true);
  var drop=h.spawnItem(Items.DIAMOND,2,2,2);drop.setItem(new ItemStack(Items.DIAMOND,3));drop.setPos(bug.getX(),bug.getY()+0.4,bug.getZ());drop.setDeltaMovement(0,0,0);drop.setNoGravity(true);
  h.runAfterDelay(25,()->{
   CompoundTag tag=new CompoundTag();bug.addAdditionalSaveData(tag);
   h.assertTrue(drop.isRemoved(),"Ground item collected: bug="+bug.position()+" drop="+drop.position()+" loot="+tag.getCompound("LethalLoot"));
   h.assertTrue(ItemStack.of(tag.getCompound("LethalLoot")).getCount()==3,"Stored count preserved");
   var restored=LethalMobs.ENTITIES.get("hoarding_bug").get().create(h.getLevel());restored.readAdditionalSaveData(tag);
   CompoundTag again=new CompoundTag();restored.addAdditionalSaveData(again);h.assertTrue(ItemStack.of(again.getCompound("LethalLoot")).getCount()==3,"Loot survives save/load");
   bug.hurt(h.getLevel().damageSources().genericKill(),1000);
   h.runAfterDelay(2,()->{h.assertItemEntityCountIs(Items.DIAMOND,new BlockPos(2,2,2),3,3);h.succeed();});
  });
 }
 @GameTest(template="test_empty",timeoutTicks=80)
 public static void coilHeadGazeFreezeAndRelease(GameTestHelper h){
  var coil=h.spawn(LethalMobs.ENTITIES.get("coil_head").get(),2,2,3);coil.setNoAi(true);coil.setNoGravity(true);
  var player=h.makeMockSurvivalPlayer();var pos=h.absolutePos(new BlockPos(2,2,1));player.moveTo(coil.getX(),coil.getY(),coil.getZ()-2,0,0);player.setNoGravity(true);h.getLevel().addFreshEntity(player);
  h.runAfterDelay(5,()->{
   player.lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES,coil.position().add(0,coil.getBbHeight()/2,0));h.assertTrue(player.hasLineOfSight(coil),"Gaze test line of sight: player="+player.position()+" coil="+coil.position()+" eyeBlock="+h.getLevel().getBlockState(BlockPos.containing(player.getEyePosition())));coil.setDeltaMovement(0.5,0,0);coil.tick();h.assertTrue(coil.getDeltaMovement().horizontalDistanceSqr()<0.001,"Watched Coil-Head stops");h.assertFalse(coil.doHurtTarget(player),"Watched Coil-Head cannot hit");
   player.setYRot(180);coil.tick();h.runAfterDelay(6,()->{h.assertTrue(coil.getTarget()==player,"Coil-Head resumes pursuit outside gaze");player.discard();h.succeed();});
  });
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void ghostVictimPersistence(GameTestHelper h){
  var ghost=LethalMobs.ENTITIES.get("ghost_girl").get().create(h.getLevel());var id=java.util.UUID.randomUUID();CompoundTag tag=new CompoundTag();tag.putUUID("LethalVictim",id);ghost.readAdditionalSaveData(tag);h.assertTrue(ghost.hauntingVictim().orElseThrow().equals(id),"Victim synchronized after load");CompoundTag saved=new CompoundTag();ghost.addAdditionalSaveData(saved);h.assertTrue(saved.getUUID("LethalVictim").equals(id),"Victim persisted");h.succeed();
 }

 @GameTest(template="test_empty",timeoutTicks=40)
 public static void spiderWebAndCooldown(GameTestHelper h){
  h.killAllEntities();var spider=h.spawn(LethalMobs.ENTITIES.get("bunker_spider").get(),2,2,3);spider.setNoAi(true);
  var player=h.makeMockSurvivalPlayer();var pos=h.absolutePos(new BlockPos(2,2,1));player.setPos(pos.getX()+0.5,pos.getY(),pos.getZ()+0.5);spider.setTarget(player);spider.tick();
  h.assertBlockPresent(net.minecraft.world.level.block.Blocks.COBWEB,new BlockPos(2,2,1));CompoundTag n=new CompoundTag();spider.addAdditionalSaveData(n);h.assertTrue(n.getInt("LethalAttackTimer")==120,"Web cooldown prevents spam");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void nutcrackerProjectilesAndReload(GameTestHelper h){
  h.killAllEntities();var nut=h.spawn(LethalMobs.ENTITIES.get("nutcracker").get(),2,2,3);nut.setNoAi(true);
  var player=h.makeMockSurvivalPlayer();var pos=h.absolutePos(new BlockPos(2,2,1));player.setPos(pos.getX()+0.5,pos.getY(),pos.getZ()+0.5);h.assertTrue(nut.hasLineOfSight(player),"Shot has clear line of sight");nut.setTarget(player);nut.tick();
  var arrows=h.getLevel().getEntitiesOfClass(net.minecraft.world.entity.projectile.AbstractArrow.class,nut.getBoundingBox().inflate(4));h.assertTrue(arrows.size()==5,"Five damaging shotgun pellets created");for(var arrow:arrows)h.assertTrue(arrow.pickup==net.minecraft.world.entity.projectile.AbstractArrow.Pickup.DISALLOWED&&arrow.getBaseDamage()==2,"Pellets have damage and cannot duplicate arrows");
  CompoundTag n=new CompoundTag();nut.addAdditionalSaveData(n);h.assertTrue(n.getInt("Magazine")==1&&n.getInt("LethalAttackTimer")==35,"Shot consumes magazine and starts cooldown");n.putInt("LethalAttackTimer",0);nut.readAdditionalSaveData(n);nut.setTarget(player);nut.tick();nut.addAdditionalSaveData(n);h.assertTrue(n.getInt("Magazine")==2&&n.getInt("LethalAttackTimer")==120,"Second shot starts reload");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void brackenGazeRetreatAndStalk(GameTestHelper h){
  h.killAllEntities();var bracken=h.spawn(LethalMobs.ENTITIES.get("bracken").get(),2,2,3);bracken.setNoAi(true);bracken.setNoGravity(true);
  var player=h.makeMockSurvivalPlayer();player.setPos(bracken.getX(),bracken.getY(),bracken.getZ()-2);player.setNoGravity(true);h.getLevel().addFreshEntity(player);player.lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES,bracken.position().add(0,bracken.getBbHeight()/2,0));h.assertTrue(player.hasLineOfSight(bracken),"Bracken gaze line of sight");
  h.runAfterDelay(5,()->{h.assertTrue(bracken.getTarget()==null,"Bracken retreats when watched");player.setYRot(180);h.runAfterDelay(6,()->{h.assertTrue(bracken.getTarget()==player,"Bracken stalks outside gaze");player.discard();h.succeed();});});
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void barberLeap(GameTestHelper h){
  h.killAllEntities();var barber=h.spawn(LethalMobs.ENTITIES.get("barber").get(),2,2,3);barber.setNoAi(true);barber.setNoGravity(true);
  var player=h.makeMockSurvivalPlayer();player.setPos(barber.getX(),barber.getY(),barber.getZ()-2);player.setNoGravity(true);h.getLevel().addFreshEntity(player);
  h.runAfterDelay(6,()->{CompoundTag n=new CompoundTag();barber.addAdditionalSaveData(n);h.assertTrue(n.getInt("LethalAttackTimer")>0&&barber.getDeltaMovement().y>0,"Barber initiates timed leap toward player");player.discard();h.succeed();});
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void themedMaterialsAndRecipes(GameTestHelper h){
  for(String family:HinaWorldgen.FAMILIES){
   h.assertTrue(HinaLand.WORLD_BLOCKS.get(family+"_oak_log").get() instanceof net.minecraft.world.level.block.RotatedPillarBlock,"Tree trunks have axis state");
   h.assertTrue(HinaLand.WORLD_BLOCKS.get(family+"_oak_leaves").get() instanceof net.minecraft.world.level.block.LeavesBlock,"Tree leaves have distance and decay state");
   h.assertTrue(HinaLand.WORLD_BLOCKS.get(family+"_soil").get().defaultBlockState().is(net.minecraft.tags.BlockTags.DIRT),"Themed soil supports trees");
   h.assertTrue(HinaLand.WORLD_BLOCKS.get(family+"_stone").get().defaultBlockState().is(net.minecraft.tags.BlockTags.STONE_ORE_REPLACEABLES),"Themed host rock supports ore placement");
   h.assertTrue(h.getLevel().getRecipeManager().byKey(new net.minecraft.resources.ResourceLocation("hinaland",family+"_iron_smelting")).isPresent(),"Silk-touched iron ore can be smelted");
  }
  h.succeed();
 }

 @GameTest(template="test_empty",timeoutTicks=40)
 public static void generationFeatureOrder(GameTestHelper h){
  var biomes=new java.util.ArrayList<>(h.getLevel().getChunkSource().getGenerator().getBiomeSource().possibleBiomes());
  net.minecraft.world.level.biome.FeatureSorter.buildFeaturesPerStep(biomes,b->b.value().getGenerationSettings().features(),true);
  h.succeed();
 }

 @GameTest(template="test_empty",timeoutTicks=40)
 public static void biomeMusicPlaylists(GameTestHelper h){
  h.assertTrue(HinaSounds.TRACKS.size()==5,"Five registered music events");
  h.assertTrue(HinaSounds.playlist("omori").size()==3,"Three OMORI tracks");
  var random=new java.util.Random(42);String previous="";var heard=new java.util.HashSet<String>();
  for(int n=0;n<100;n++){String next=HinaSounds.choose("omori",previous,random);h.assertFalse(next.equals(previous),"No immediate OMORI repeat");heard.add(next);previous=next;}
  h.assertTrue(heard.size()==3,"All OMORI tracks selectable");
  h.assertTrue(HinaSounds.choose("vanilla","",random)==null,"No custom playlist in vanilla biomes");
  for(var sound:HinaSounds.TRACKS.values())h.assertTrue(sound.isPresent(),"Sound event registered");h.succeed();
 }

 @GameTest(template="test_empty",timeoutTicks=40)
 public static void interiorGeometryAndLeafExclusion(GameTestHelper h){
  var original=h.absolutePos(new BlockPos(2,2,2));h.assertTrue(IndoorHabitat.isInterior(h.getLevel(),original),"Stone room qualifies as interior");
  var p=new BlockPos(original.getX(),h.getLevel().getMaxBuildHeight()-20,original.getZ());
  h.assertFalse(IndoorHabitat.isInterior(h.getLevel(),p),"Open sky is exterior");
  for(var direction:net.minecraft.core.Direction.Plane.HORIZONTAL)h.getLevel().setBlock(p.relative(direction,2).above(),net.minecraft.world.level.block.Blocks.STONE.defaultBlockState(),3);
  h.getLevel().setBlock(p.above(4),net.minecraft.world.level.block.Blocks.OAK_LEAVES.defaultBlockState(),3);
  h.assertFalse(IndoorHabitat.isInterior(h.getLevel(),p),"Leaves cannot provide an interior ceiling");
  h.getLevel().setBlock(p.above(4),net.minecraft.world.level.block.Blocks.STONE.defaultBlockState(),3);h.assertTrue(IndoorHabitat.isInterior(h.getLevel(),p),"Solid ceiling and walls qualify");
  h.getLevel().setBlock(p.above(4),net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),3);for(var direction:net.minecraft.core.Direction.Plane.HORIZONTAL)h.getLevel().setBlock(p.relative(direction,2).above(),net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),3);h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void allLethalRejectOutdoorSpawns(GameTestHelper h){
  for(var type:LethalMobs.ENTITIES.values()){
   var mob=type.get().create(h.getLevel());var original=h.absolutePos(new BlockPos(2,2,2));var p=new BlockPos(original.getX(),h.getLevel().getMaxBuildHeight()-4,original.getZ());mob.moveTo(p.getX()+.5,p.getY(),p.getZ()+.5,0,0);h.getLevel().addFreshEntity(mob);mob.tick();h.assertTrue(mob.isRemoved(),"Lethal entity rejects outdoors: "+mob.kind()+"");
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void allLethalStayInsideAfterExit(GameTestHelper h){
  for(var type:LethalMobs.ENTITIES.values()){
   var mob=h.spawn(type.get(),2,2,2);mob.setNoAi(true);mob.setNoGravity(true);mob.tick();var lastInside=mob.blockPosition();
   var outside=new BlockPos(lastInside.getX(),h.getLevel().getMaxBuildHeight()-4,lastInside.getZ());mob.setPos(outside.getX()+.5,outside.getY(),outside.getZ()+.5);mob.tick();
   h.assertTrue(!mob.isRemoved()&&mob.blockPosition().equals(lastInside)&&IndoorHabitat.isInterior(h.getLevel(),mob.blockPosition()),"Monster returns to its last valid interior");mob.discard();
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void ghostGirlDropsOutdoorVictim(GameTestHelper h){
  var ghost=h.spawn(LethalMobs.ENTITIES.get("ghost_girl").get(),2,2,3);ghost.setNoAi(true);ghost.setNoGravity(true);
  var player=h.makeMockSurvivalPlayer();var original=h.absolutePos(new BlockPos(2,2,2));var outside=new BlockPos(original.getX(),h.getLevel().getMaxBuildHeight()-4,original.getZ());player.setPos(outside.getX()+.5,outside.getY(),outside.getZ()+.5);h.getLevel().addFreshEntity(player);
  CompoundTag tag=new CompoundTag();tag.putUUID("LethalVictim",player.getUUID());ghost.readAdditionalSaveData(tag);ghost.setTarget(player);
  for(int i=0;i<5;i++)ghost.tick();h.assertTrue(ghost.getTarget()!=player&&!ghost.hauntingVictim().filter(player.getUUID()::equals).isPresent(),"Ghost cannot target or retain an outdoor victim");if(ghost.getTarget()!=null)h.assertTrue(IndoorHabitat.isInterior(h.getLevel(),ghost.getTarget().blockPosition()),"Any replacement victim is indoors");player.discard();h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=220)
 public static void dryBonesCollapseAndRevive(GameTestHelper h){
  var mob=h.spawn(BiomeMobs.ENTITIES.get("dry_bones").get(),2,2,2);mob.setNoAi(true);var player=h.makeMockSurvivalPlayer();
  mob.hurt(h.getLevel().damageSources().playerAttack(player),30);h.assertTrue(mob.isAlive()&&mob.behaviorState()==1,"Lethal strike collapses Dry Bones instead of killing it");
  h.runAfterDelay(170,()->{h.assertTrue(mob.isAlive()&&mob.behaviorState()==0,"Dry Bones reassembles after its recovery period");h.succeed();});
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void koopaShellKickPersistence(GameTestHelper h){
  var mob=h.spawn(BiomeMobs.ENTITIES.get("koopa").get(),2,2,3);mob.setNoAi(true);var player=h.makeMockSurvivalPlayer();var p=h.absolutePos(new BlockPos(2,2,1));player.setPos(p.getX()+.5,p.getY(),p.getZ()+.5);
  mob.hurt(h.getLevel().damageSources().playerAttack(player),4);h.assertTrue(mob.behaviorState()==2,"Koopa withdraws into shell");mob.hurt(h.getLevel().damageSources().playerAttack(player),4);
  CompoundTag tag=new CompoundTag();mob.addAdditionalSaveData(tag);h.assertTrue(tag.getInt("DisabledTicks")>0&&Math.abs(tag.getDouble("ShellVZ"))>.1,"Second hit kicks shell away");
  var restored=BiomeMobs.ENTITIES.get("koopa").get().create(h.getLevel());restored.readAdditionalSaveData(tag);h.assertTrue(restored.behaviorState()==2,"Shell state survives saving");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void darknerPatternsAndProjectileWallCollision(GameTestHelper h){
  var player=h.makeMockSurvivalPlayer();var p=h.absolutePos(new BlockPos(2,2,1));player.setPos(p.getX()+.5,p.getY(),p.getZ()+.5);
  for(String name:new String[]{"rudinn","hathy"}){
   var mob=h.spawn(BiomeMobs.ENTITIES.get(name).get(),2,2,3);mob.setNoAi(true);mob.setTarget(player);mob.tick();
   var shots=h.getLevel().getEntitiesOfClass(DarknerProjectile.class,mob.getBoundingBox().inflate(3),bolt->bolt.getOwner()==mob);h.assertTrue(shots.size()==(name.equals("rudinn")?3:8),"Diamond fan or heart ring has actual projectiles");
   for(var bolt:shots){h.assertTrue(bolt.isNoGravity()&&bolt.getItem().is(HinaLand.item(name.equals("rudinn")?"darkner_diamond":"darkner_heart")),"Projectile has correct icon and flight");bolt.discard();}
   var bolt=new DarknerProjectile(h.getLevel(),mob);bolt.setPos(mob.getX(),mob.getY()+.8,mob.getZ());bolt.shoot(0,0,1,.8f,0);h.getLevel().addFreshEntity(bolt);for(int t=0;t<12&&!bolt.isRemoved();t++)bolt.tick();h.assertTrue(bolt.isRemoved(),"Physical bullets stop at walls");mob.discard();
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void darknerPersuasionStopsCombat(GameTestHelper h){
  var player=h.makeMockSurvivalPlayer();player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,ItemStack.EMPTY);
  for(String name:new String[]{"rudinn","hathy"}){
   var mob=h.spawn(BiomeMobs.ENTITIES.get(name).get(),2,2,3);mob.setNoAi(true);mob.setTarget(player);mob.interact(player,net.minecraft.world.InteractionHand.MAIN_HAND);mob.tick();
   CompoundTag tag=new CompoundTag();mob.addAdditionalSaveData(tag);h.assertTrue(tag.getInt("SparedTicks")>0&&mob.getTarget()==null,"Empty-hand interaction spares Darkner temporarily");h.assertFalse(mob.doHurtTarget(player),"Spared Darkner cannot damage player");mob.discard();
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void themedFlowersSurviveAndDrop(GameTestHelper h){
  var p=h.absolutePos(new BlockPos(2,2,2));
  for(String f:new String[]{"mario","omori","deltarune","genshin","overwatch","lethal"})for(String flower:new String[]{"dandelion","poppy","blue_orchid","oxeye_daisy"}){
   h.setBlock(new BlockPos(2,1,2),HinaLand.WORLD_BLOCKS.get(f+"_soil").get());var plant=HinaLand.WORLD_BLOCKS.get(f+"_"+flower).get();h.assertTrue(plant.defaultBlockState().canSurvive(h.getLevel(),p),"Flower grows on its themed soil");
   h.getLevel().setBlock(p,plant.defaultBlockState(),3);h.getLevel().destroyBlock(p,true);
   h.assertTrue(!h.getLevel().getEntitiesOfClass(ItemEntity.class,new net.minecraft.world.phys.AABB(p).inflate(1),e->e.getItem().is(HinaLand.item(f+"_"+flower))).isEmpty(),"Flower drops its own registered item");
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void omochaoGoldInteractionAndPeacefulTarget(GameTestHelper h){
  var helper=h.spawn(BiomeMobs.OMOCHAO.get(),2,2,3);helper.setNoAi(true);helper.setHealth(5);var player=h.makeMockSurvivalPlayer();player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,new ItemStack(Items.GOLD_NUGGET,2));
  helper.interact(player,net.minecraft.world.InteractionHand.MAIN_HAND);helper.tick();h.assertTrue(helper.getHealth()==10&&player.getMainHandItem().getCount()==1,"Gold repairs friendly Omochao and is consumed");h.assertTrue(helper.getTarget()==null&&helper.isNoGravity(),"Omochao stays non-hostile and flies");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=60)
 public static void customDimensionsAndMixedNether(GameTestHelper h){
  var possible=h.getLevel().getServer().overworld().getChunkSource().getGenerator().getBiomeSource().possibleBiomes();
  for(String family:HinaWorldgen.FAMILIES)for(String suffix:HinaWorldgen.VARIANTS)h.assertTrue(possible.stream().anyMatch(b->b.unwrapKey().orElseThrow().equals(HinaWorldgen.biome(family+suffix))),"Themed biome belongs to actual Overworld source: "+family+suffix);
  var nether=h.getLevel().getServer().getLevel(net.minecraft.world.level.Level.NETHER);
  h.assertTrue(nether.dimensionType().bedWorks()&&nether.dimensionType().natural()&&!nether.dimensionType().ultraWarm(),"Mixed Nether supports non-explosive beds and natural sleep");
  var ids=nether.getChunkSource().getGenerator().getBiomeSource().possibleBiomes().stream().map(b->b.unwrapKey().orElseThrow().location().toString()).collect(java.util.stream.Collectors.toSet());
  h.assertTrue(ids.size()==63&&ids.contains("minecraft:plains")&&ids.contains("minecraft:nether_wastes")&&ids.contains("minecraft:end_highlands"),"All 63 playable vanilla biomes are registered in the Nether source");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=60)
 public static void importedTemplatesAndLootLoaded(GameTestHelper h){
  String[] names={"sonic_falaise","lethal_cratere","overwatch_bassin","mario_champignons","omori_grotte","lethal_rochers","lethal_bois_morts","omori_sapins_violets","genshin_sakura","sonic_cascade","omori_grand_arbre","overwatch_arche","mario_nuage","omori_ilot_noir","overwatch_cenote","genshin_cristaux","genshin_dragonspine","genshin_pics","sonic_fleurs_geantes","mario_colline","sonic_looping","lethal_company_vaisseau","mario_tuyau_blocs","overwatch_point","overwatch_payload","omori_white_space","lethal_company_batiment","mario_chateau","genshin_pavillon","genshin_statue","omori_jardin","sonic_master_emerald"};
  for(String name:names){var id=new net.minecraft.resources.ResourceLocation(HinaLand.ID,name);var template=h.getLevel().getStructureManager().get(id);h.assertTrue(template.isPresent()&&template.get().getSize().getX()>0,"Imported template loads: "+name);var nbt=template.get().save(new CompoundTag());h.assertTrue(nbt.getList("blocks",10).size()>0,"Template contains actual blocks");}
  for(String family:new String[]{"mario","sonic","omori","genshin","overwatch","lethal_facility"}){
   var table=h.getLevel().getServer().getLootData().getLootTable(new net.minecraft.resources.ResourceLocation(HinaLand.ID,"chests/"+family));
   var params=new net.minecraft.world.level.storage.loot.LootParams.Builder(h.getLevel()).withParameter(net.minecraft.world.level.storage.loot.parameters.LootContextParams.ORIGIN,h.absoluteVec(new net.minecraft.world.phys.Vec3(2,2,2))).create(net.minecraft.world.level.storage.loot.parameters.LootContextParamSets.CHEST);
   h.assertTrue(!table.getRandomItems(params).isEmpty(),"Imported chest table produces items: "+family);
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=40)
 public static void netherSleepAdvancesSharedClock(GameTestHelper h){
  var server=h.getLevel().getServer();var nether=server.getLevel(net.minecraft.world.level.Level.NETHER);var overworld=server.overworld();long original=overworld.getDayTime();
  overworld.setDayTime(13000);net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new net.minecraftforge.event.level.SleepFinishedTimeEvent(nether,24000,13000));
  h.assertTrue(overworld.getDayTime()==24000&&nether.getDayTime()==24000,"Completing sleep in the Nether advances the shared clock to morning");overworld.setDayTime(original);h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=100)
 public static void universeMineralRecipes(GameTestHelper h){
  h.assertTrue(new ItemStack(Items.DIAMOND_PICKAXE).isCorrectToolForDrops(net.minecraft.world.level.block.Blocks.OBSIDIAN.defaultBlockState()),"Adding custom tiers preserves vanilla diamond harvesting");
  h.assertFalse(new ItemStack(Items.IRON_PICKAXE).isCorrectToolForDrops(net.minecraft.world.level.block.Blocks.OBSIDIAN.defaultBlockState()),"Adding custom tiers preserves vanilla iron limits");
  var menu=new net.minecraft.world.inventory.AbstractContainerMenu(null,-1){
   @Override public ItemStack quickMoveStack(net.minecraft.world.entity.player.Player p,int slot){return ItemStack.EMPTY;}
   @Override public boolean stillValid(net.minecraft.world.entity.player.Player p){return true;}
  };
  var grid=new net.minecraft.world.inventory.TransientCraftingContainer(menu,3,3);
  for(var f:UniverseMinerals.FAMILIES){
   for(String material:java.util.List.of(f.primary(),f.secondary())){
    grid.clearContent();for(int slot=0;slot<9;slot++)grid.setItem(slot,new ItemStack(HinaLand.item(material)));
    checkCraft(h,grid,material+"_block",1);
    grid.clearContent();grid.setItem(0,new ItemStack(HinaLand.item(material+"_block")));checkCraft(h,grid,material,9);
    var input=new net.minecraft.world.SimpleContainer(new ItemStack(HinaLand.item(material+"_ore")));
    var furnace=h.getLevel().getRecipeManager().getRecipeFor(net.minecraft.world.item.crafting.RecipeType.SMELTING,input,h.getLevel()).orElseThrow();
    var blast=h.getLevel().getRecipeManager().getRecipeFor(net.minecraft.world.item.crafting.RecipeType.BLASTING,input,h.getLevel()).orElseThrow();
    h.assertTrue(furnace.assemble(input,h.getLevel().registryAccess()).is(HinaLand.item(material))&&furnace.getCookingTime()==200,"Correct smelting resource/time: "+material);
    h.assertTrue(blast.assemble(input,h.getLevel().registryAccess()).is(HinaLand.item(material))&&blast.getCookingTime()==100,"Correct blast resource/time: "+material);
   }
   grid.clearContent();for(int i=0;i<3;i++)grid.setItem(i,new ItemStack(HinaLand.item(f.primary())));grid.setItem(4,new ItemStack(HinaLand.item(f.secondary())));grid.setItem(7,new ItemStack(Items.STICK));checkCraft(h,grid,f.name()+"_mineral_pickaxe",1);
   grid.clearContent();grid.setItem(1,new ItemStack(HinaLand.item(f.secondary())));grid.setItem(4,new ItemStack(HinaLand.item(f.secondary())));grid.setItem(7,new ItemStack(HinaLand.item(f.primary())));checkCraft(h,grid,f.name()+"_mineral_sword",1);
   grid.clearContent();grid.setItem(0,new ItemStack(HinaLand.item(f.primary())));grid.setItem(1,new ItemStack(HinaLand.item(f.secondary())));checkCraft(h,grid,f.name()+"_essence",2);
   var pick=new ItemStack(HinaLand.item(f.name()+"_mineral_pickaxe"));
   h.assertTrue(pick.isCorrectToolForDrops(net.minecraft.world.level.block.Blocks.OBSIDIAN.defaultBlockState()),"New pickaxe harvests obsidian: "+f.name());
   h.assertTrue(pick.getItem().isValidRepairItem(pick,new ItemStack(HinaLand.item(f.primary()))),"Repair uses its own mineral");
   h.assertFalse(pick.getItem().isValidRepairItem(pick,new ItemStack(Items.DIAMOND)),"Vanilla diamonds do not repair universe tools");
  }h.succeed();
 }
 private static void checkCraft(GameTestHelper h,net.minecraft.world.inventory.CraftingContainer grid,String item,int count){
  var recipe=h.getLevel().getRecipeManager().getRecipeFor(net.minecraft.world.item.crafting.RecipeType.CRAFTING,grid,h.getLevel()).orElseThrow();var result=recipe.assemble(grid,h.getLevel().registryAccess());
  h.assertTrue(result.is(HinaLand.item(item))&&result.getCount()==count,"Actual crafting grid result: "+item+" x"+count);
 }
 @GameTest(template="test_empty",timeoutTicks=100)
 public static void universeMineralHarvestAndLoot(GameTestHelper h){
  var pos=h.absolutePos(new BlockPos(2,2,2));var silk=new ItemStack(Items.DIAMOND_PICKAXE);silk.enchant(net.minecraft.world.item.enchantment.Enchantments.SILK_TOUCH,1);
  var fortune=new ItemStack(Items.DIAMOND_PICKAXE);fortune.enchant(net.minecraft.world.item.enchantment.Enchantments.BLOCK_FORTUNE,3);
  for(var f:UniverseMinerals.FAMILIES)for(String material:java.util.List.of(f.primary(),f.secondary())){
   var ore=HinaLand.WORLD_BLOCKS.get(material+"_ore").get();var state=ore.defaultBlockState();
   h.assertFalse(new ItemStack(Items.STONE_PICKAXE).isCorrectToolForDrops(state),"Stone pick cannot harvest: "+material);
   h.assertTrue(new ItemStack(Items.IRON_PICKAXE).isCorrectToolForDrops(state),"Iron pick harvests: "+material);
   h.assertTrue(new ItemStack(HinaLand.item(f.name()+"_mineral_pickaxe")).isCorrectToolForDrops(state),"New pick harvests its own mineral");
   var normal=net.minecraft.world.level.block.Block.getDrops(state,h.getLevel(),pos,null,null,new ItemStack(Items.IRON_PICKAXE));
   h.assertTrue(normal.size()==1&&normal.get(0).is(HinaLand.item(material))&&normal.get(0).getCount()==1,"Ore drops new resource, not vanilla mineral");
   var intact=net.minecraft.world.level.block.Block.getDrops(state,h.getLevel(),pos,null,null,silk);
   h.assertTrue(intact.size()==1&&intact.get(0).is(ore.asItem()),"Silk Touch preserves exact ore");
   boolean bonus=false;for(int i=0;i<32;i++){
    var drops=net.minecraft.world.level.block.Block.getDrops(state,h.getLevel(),pos,null,null,fortune);
    h.assertTrue(drops.size()==1&&drops.get(0).is(HinaLand.item(material))&&drops.get(0).getCount()>=1&&drops.get(0).getCount()<=4,"Fortune stays within 1–4 resources");bonus|=drops.get(0).getCount()>1;
   }h.assertTrue(bonus,"Fortune produces a resource bonus");
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=100)
 public static void universeMineralGeneration(GameTestHelper h){
  var configured=h.getLevel().registryAccess().registryOrThrow(Registries.CONFIGURED_FEATURE);var placed=h.getLevel().registryAccess().registryOrThrow(Registries.PLACED_FEATURE);var biomes=h.getLevel().registryAccess().registryOrThrow(Registries.BIOME);
  for(var f:UniverseMinerals.FAMILIES)for(String material:java.util.List.of(f.primary(),f.secondary())){
   var key=new net.minecraft.resources.ResourceLocation(HinaLand.ID,material+"_veins");var feature=configured.get(key);h.assertTrue(feature!=null&&placed.containsKey(key),"Configured/placed mineral feature loaded");
   var config=(net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration)feature.config();var host=HinaLand.WORLD_BLOCKS.get(f.name()+"_stone").get().defaultBlockState();
   h.assertTrue(config.targetStates.stream().anyMatch(t->t.target.test(host,net.minecraft.util.RandomSource.create(1))),"Vein replaces its themed underground rock");
   h.assertTrue(config.targetStates.stream().noneMatch(t->t.target.test(net.minecraft.world.level.block.Blocks.BEDROCK.defaultBlockState(),net.minecraft.util.RandomSource.create(1))),"Vein never replaces bedrock");
   for(String suffix:HinaWorldgen.VARIANTS){var biome=biomes.getOrThrow(HinaWorldgen.biome(f.name()+suffix));h.assertTrue(biome.getGenerationSettings().features().get(6).stream().anyMatch(p->p.unwrapKey().orElseThrow().location().equals(key)),"Vein registered in all four family biomes");}
   for(var other:UniverseMinerals.FAMILIES)if(!other.name().equals(f.name())){
    h.assertTrue(config.targetStates.stream().noneMatch(t->t.target.test(HinaLand.WORLD_BLOCKS.get(other.name()+"_stone").get().defaultBlockState(),net.minecraft.util.RandomSource.create(1))),"Vein does not replace another family's rock");
    h.assertTrue(biomes.getOrThrow(HinaWorldgen.biome(other.name())).getGenerationSettings().features().get(6).stream().noneMatch(p->p.unwrapKey().orElseThrow().location().equals(key)),"Vein isolated from other biomes");
   }
  }h.succeed();
 }
}
