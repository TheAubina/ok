# Hina Land 0.7.0 — bêta Forge 1.20.1

Cette version part de l'archive 0.6. Le livrable est un vrai JAR Java 17 réobfusqué avec ForgeGradle, accompagné d'un rapport séparant les validations et les limites.

## Installation

Dans `mods/` d'une installation **Minecraft Java 1.20.1 avec Forge 47.3.0**, placer :

- `hinaland-0.7.0.jar`
- `geckolib-forge-1.20.1-4.4.9.jar`
- `TerraBlender-forge-1.20.1-3.0.1.7.jar`

Les trois JAR seront fournis dans le paquet d'installation. Installer les mêmes versions sur le client et le serveur. Aucun des autres mods personnels n'est obligatoire. Utiliser un nouveau monde pour observer les biomes dans les nouveaux chunks.

## Contenu de cette bêta

- Trois biomes réels dans l'Overworld via TerraBlender ; les biomes vanilla sont conservés. Les sols Mario, Sonic et OMORI se génèrent naturellement.
- Blocs décoratifs et textures fournis ; modèles, loot tables et tags d'outils vérifiés. Les 60 blocs décoratifs ne se génèrent pas tous automatiquement.
- Six entités distinctes : Goomba, Koopa, Motobug, Buzz Bomber, Sprout Mole et Forest Bunny. Modèles et textures simples, créés pour cette bêta ; pas des zombies renommés. Listes de spawns propres aux trois biomes.
- Skybox OMORI utilisant l'image fournie, avec atténuation à l'intérieur des frontières du biome. Le ciel vanilla revient à l'extérieur.
- Sept monstres Lethal rendus par GeckoLib avec les modèles/animations fournis et leurs comportements serveur expérimentaux. Le fusil fourni est inclus dans le modèle du Nutcracker.

## Commandes de test

Activer les commandes du monde ou être opérateur. Les commandes `testbiome` et `spawn` nécessitent un joueur ; ne pas les exécuter directement depuis une console sans `execute as <joueur> at <joueur> run ...`.

```
/hinaland testbiome mario 24
/hinaland testbiome sonic 24
/hinaland testbiome omori 24
/hinaland where
/hinaland spawn goomba
/hinaland spawn koopa
/hinaland spawn motobug
/hinaland spawn buzz_bomber
/hinaland spawn sprout_mole
/hinaland spawn forest_bunny
/hinaland spawn lethal_bracken
/hinaland spawn lethal_coil_head
/hinaland spawn lethal_hoarding_bug
/hinaland spawn lethal_barber
/hinaland spawn lethal_bunker_spider
/hinaland spawn lethal_ghost_girl
/hinaland spawn lethal_nutcracker
/locate biome hinaland:mario
/locate biome hinaland:sonic
/locate biome hinaland:omori
```

`testbiome` est une commande d'administration qui modifie les biomes et certains blocs de surface d'une zone ; elle n'est pas nécessaire à la génération naturelle. Rayon accepté : 8 à 48. Les créatures ciblent les joueurs de Survie, pas les joueurs de Créatif/Spectateur. Lethal reste accessible par œufs/commandes : les installations et spawns naturels associés ne sont pas encore créés.

## Compilation et tests

Installer Java 17, puis depuis la racine :

```
./gradlew build
./gradlew runGameTestServer
python3 tools/check_assets.py
```

Sous Windows : `gradlew.bat build`. Gradle Wrapper 8.8, distribution vérifiée par SHA-256 ; ForgeGradle 6.0.54, Forge 47.3.0, GeckoLib 4.4.9 et TerraBlender 3.0.1.7 sont épinglés. Le JAR final se trouve dans `build/libs/`. Les GameTests et leur structure sont exclus du JAR distribué.

Dans le workspace cloud préparé : `source tools/cloud-env.sh` avant les commandes. Les paramètres de proxy et le magasin TLS du cloud sont dans le cache Gradle externe, pas dans les sources portables. Un affichage est nécessaire pour `./gradlew runClient`.

## Limites et suite

Voir `RAPPORT_BETA_FR.md` et `ROADMAP_FR.md`. Les anciennes notes 0.1–0.6 décrivent des états historiques et ne prouvent aucune validation actuelle.

La génération des structures, les autres territoires, les boss complets, le Dragon en cinq phases, le Sanctuaire à douze socles et les intégrations de mods personnels restent à développer. Les modèles Lethal demandent encore des ajustements artistiques/animations et des essais prolongés. Aucun son Lethal original n'a été fourni. Les quêtes FTB héritées ne sont pas validées avec FTB Quests.
