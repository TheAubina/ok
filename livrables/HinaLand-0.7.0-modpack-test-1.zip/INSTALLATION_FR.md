# Hina Land — modpack de test 0.7.0, paquet 1

## Installation

Utiliser **Minecraft Java 1.20.1, Java 17 et Forge 47.3.0**. Extraire les dossiers `mods`, `config` et `resourcepacks` du paquet à la racine d'une nouvelle instance Minecraft. Le dossier `mods` contient **22 JAR** : Hina Land 0.7.0, ses deux dépendances et les 19 JAR supplémentaires récupérés.

Dans Options → Packs de ressources, activer **HinaLand-integration-textures.zip** au-dessus des ressources des mods. Ce correctif ajoute douze textures existantes à l'atlas pour les objets d'OverCraft, Flandre et Portal Rick. Les JAR fournis ne sont pas modifiés.

Le carnet FTB est accessible depuis l'icône de livre de l'inventaire. Un raccourci peut être attribué dans les contrôles. Les 14 chapitres proviennent du mod Hina Land Quest fourni ; les anciens chapitres expérimentaux des sources Hina Land ne sont pas ajoutés en doublon.

Installer les mêmes 22 JAR sur le serveur. Le pack de ressources est destiné au client. Les paramètres de serveur de test, l'authentification hors ligne et le monde de test ne sont pas distribués.

## Élément manquant

**Lunaria Media 2.0.2 n'est pas inclus** : son fichier dépasse la limite de transfert de 32 Mio de l'outil. Les objectifs utilisant `lunariamedia:flat_screen_stand` et `lunariamedia:speaker_tower` restent bloqués ; trois succès de quête ne se chargent pas. Ajouter ce JAR lorsque son transfert sera possible, puis redémarrer le jeu/serveur. Ne pas considérer les 148 quêtes comme toutes validées.

Voir `RAPPORT_INTEGRATION_FR.md` pour les contrôles et limites, et `audit/inventory.json` pour les versions exactes. Le JAR Hina Land conserve les limites de sa bêta 0.7.0. Carry On n'est pas présent et le Hoarding Bug n'emporte pas encore les coffres.
