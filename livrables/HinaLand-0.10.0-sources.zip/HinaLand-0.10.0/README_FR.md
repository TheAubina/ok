# Hina Land 0.10.0 — bêta Forge

Minecraft Java 1.20.1, Forge 47.3.0, Java 17. JAR : GeckoLib 4.4.9 et TerraBlender 3.0.1.7 requis.

Quatre univers dans l’Overworld, avec plaines, forêts, hauts plateaux et dunes : Mario, Sonic, OMORI et DELTARUNE. Blocs et sous-sol thématiques jusqu’au bedrock, douze fleurs issues des nouveaux packs, cinq pistes musicales Mario/Sonic/OMORI et ciel étoilé OMORI.

Dix ennemis thématiques et Omochao amical, plus les sept monstres Lethal Company. Ces sept monstres, Ghost Girl comprise, sont limités aux zones couvertes définies par la règle d’intérieur. Vingt-sept objets MirRP sont disponibles dans de petits postes de récupération générés naturellement. Voir RAPPORT_PACKS_CREATURES_0.10_FR.md pour les détails, adaptations et limites.

## Jouer

Remplacer l’ancien JAR Hina Land. Ne pas conserver plusieurs versions. Le pack complet contient 22 JAR : utiliser de préférence une nouvelle instance Forge et y copier mods, config et resourcepacks. Activer le petit pack d’intégration des autres mods. Les textures sélectionnées des cinq gros packs sont incorporées dans le JAR ; inutile de les activer globalement.

Créer un monde neuf ou explorer de nouveaux chunks pour les nouvelles régions, fleurs et postes. Utiliser les œufs Lethal dans une salle couverte. Rudinn et Hathy peuvent être apaisés temporairement par un clic à main vide. Une pépite d’or répare Omochao. Les musiques suivent le réglage Musique de Minecraft.

## Compiler les sources

Installer Java 17, puis utiliser le wrapper Gradle 8.8 fourni :

```sh
./gradlew build --max-workers=2
./gradlew runGameTestServer --max-workers=2
```

Sous Windows : gradlew.bat build. Le JAR reobfusqué est produit dans build/libs. Les tâches client et server lancent l’environnement de développement. Forge et les bibliothèques sont téléchargés automatiquement depuis leurs dépôts configurés ; accès réseau nécessaire au premier lancement.

Les ressources générées sont déjà incluses : aucune archive originale n’est requise pour compiler. Les scripts import_* dans tools servent au travail d’import et nécessitent les packs originaux dans imported-packs ; il n’est pas nécessaire de les relancer pour un build normal. tools/cloud-env.sh est spécifique au workspace cloud et ne doit pas être utilisé sur un autre ordinateur.

## Validation et limites

22 GameTests Forge passés. 16 sites naturels contrôlés, 12 fleurs comptées réellement, 9 coffres Lethal naturels identifiés. 856 JSON et 18 modèles contrôlés. Client et serveur de production chargés avec les 22 JAR. Les tests ne valident pas une campagne complète ou tous les clips d’animation.

Les IA sont adaptées à Minecraft, pas reproduites intégralement. Rudinn/Hathy sont des sprites dans le monde 3D. Plusieurs autres modèles CEM restent à identifier et convertir. Boss, lunes Lethal, quotas, vaisseau et transport de coffres restent à développer. Lunaria Media manque au pack, avec trois succès de quête bloqués ; le mod de quêtes fourni peut dupliquer ses chapitres au redémarrage.

Les documents 0.6–0.9 conservés dans les sources sont historiques : les textures de fleurs manquantes en 0.9 sont désormais intégrées.
