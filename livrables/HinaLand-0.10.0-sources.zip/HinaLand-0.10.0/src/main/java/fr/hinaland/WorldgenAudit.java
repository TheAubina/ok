package fr.hinaland;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.nio.file.*;
import java.util.*;

/** Operator-only diagnostic: sample the actual generator without generating thousands of chunks. */
@Mod.EventBusSubscriber(modid=HinaLand.ID)
public final class WorldgenAudit {
 @SubscribeEvent public static void commands(RegisterCommandsEvent e){
  e.getDispatcher().register(Commands.literal("hinaland").requires(s->s.hasPermission(2))
   .then(Commands.literal("auditworldgen").executes(ctx->{
    ServerLevel level=ctx.getSource().getServer().overworld();
    var source=level.getChunkSource().getGenerator().getBiomeSource();
    var sampler=level.getChunkSource().randomState().sampler();
    StringBuilder csv=new StringBuilder("x,z,biome\n");Map<String,Integer> counts=new TreeMap<>();Map<String,String> positions=new TreeMap<>();
    for(int x=-8192;x<=8192;x+=128)for(int z=-8192;z<=8192;z+=128){
     var holder=source.getNoiseBiome(Math.floorDiv(x,4),20,Math.floorDiv(z,4),sampler);
     String key=holder.unwrapKey().orElseThrow().location().toString();
     csv.append(x).append(',').append(z).append(',').append(key).append('\n');counts.merge(key,1,Integer::sum);
     if(key.startsWith("hinaland:"))positions.putIfAbsent(key,x+" "+z);
    }
    try{Files.writeString(Path.of("hinaland-worldgen-audit.csv"),csv);}catch(java.io.IOException ex){ctx.getSource().sendFailure(Component.literal(ex.toString()));return 0;}
    ctx.getSource().sendSuccess(()->Component.literal("Worldgen sample (16641 points at Y=80): "+counts+"; first positions: "+positions),true);
    return counts.size();
   })));
 }
}
