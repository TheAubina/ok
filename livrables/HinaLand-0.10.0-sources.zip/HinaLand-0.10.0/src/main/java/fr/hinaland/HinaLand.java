package fr.hinaland;

import net.minecraft.world.item.*;
import net.minecraft.core.registries.Registries;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.*;
import java.util.*;

@Mod(HinaLand.ID)
public class HinaLand {
 public static final String ID="hinaland";
 public static final String[] BOSSES={"bowser","king_boo","sweetheart","space_ex_boyfriend","something","spamton_neo","jevil","metal_sonic","eggman","dvalin","andrius","dead_end_butcher","twin_marionettes","remilia","flandre","mewtwo"};
 public static final DeferredRegister<Block> BLOCKS=DeferredRegister.create(ForgeRegistries.BLOCKS,ID);
 public static final Map<String,RegistryObject<Block>> WORLD_BLOCKS=new LinkedHashMap<>();
 public static final String[] REGIONS={"mario","omori","sonic","deltarune","genshin","zzz","touhou","pokemon","lethal","repo","fnaf"};
 public static final DeferredRegister<Item> ITEMS=DeferredRegister.create(ForgeRegistries.ITEMS,ID);
 public static final DeferredRegister<CreativeModeTab> TABS=DeferredRegister.create(Registries.CREATIVE_MODE_TAB,ID);
 public static final Map<String,RegistryObject<Item>> ALL=new LinkedHashMap<>();
 public static final RegistryObject<CreativeModeTab> TAB=TABS.register("main",()->CreativeModeTab.builder().title(Component.translatable("itemGroup.hinaland")).icon(()->ALL.get("rift_shard").get().getDefaultInstance()).displayItems((params,output)->ALL.values().forEach(it->output.accept(it.get()))).build());
 static {
  register("rift_shard",new Item.Properties());register("multiverse_core",new Item.Properties().rarity(Rarity.RARE));register("dragon_scale",new Item.Properties());register("echo_fragment",new Item.Properties());
  register("stronghold_compass",new Item.Properties().stacksTo(1));register("boss_locator",new Item.Properties().stacksTo(1));
  ALL.put("rift_blade",ITEMS.register("rift_blade",()->new SwordItem(Tiers.DIAMOND,5,-2.4f,new Item.Properties().durability(1561))));
  ALL.put("echo_hammer",ITEMS.register("echo_hammer",()->new AxeItem(Tiers.DIAMOND,7,-3.2f,new Item.Properties().durability(1561))));
  ALL.put("anemo_wand",ITEMS.register("anemo_wand",()->new Item(new Item.Properties().durability(384))));
  registerArmor("rift_helmet",ArmorItem.Type.HELMET);registerArmor("rift_chestplate",ArmorItem.Type.CHESTPLATE);registerArmor("rift_leggings",ArmorItem.Type.LEGGINGS);registerArmor("rift_boots",ArmorItem.Type.BOOTS);
  for(String region:REGIONS){
    String blockId=region+"_soil";
    RegistryObject<Block> b=BLOCKS.register(blockId,()->new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(0.6f).sound(SoundType.GRASS)));
    WORLD_BLOCKS.put(blockId,b);
    ALL.put(blockId,ITEMS.register(blockId,()->new BlockItem(b.get(),new Item.Properties())));
    register(region+"_essence",new Item.Properties());
    register(region+"_relic",new Item.Properties().rarity(Rarity.UNCOMMON));
  }
  // Blocks generated from the supplied Mario, Sonic and OMORI texture packs.
  for(String region:new String[]{"mario","sonic","omori","deltarune"}){
   for(String kind:new String[]{"bedrock","redstone_ore","iron_ore","gold_ore","obsidian","oak_leaves","bricks","snow","stone","cobblestone","gravel","coal_ore","sandstone","oak_log","dirt","oak_planks","sand","stone_bricks","diamond_ore","netherrack"}){
    String id=region+"_"+kind;
    RegistryObject<Block> themed=BLOCKS.register(id,()->themedBlock(kind));
    WORLD_BLOCKS.put(id,themed);ALL.put(id,ITEMS.register(id,()->new BlockItem(themed.get(),new Item.Properties())));
   }
  }
  for(String family:new String[]{"mario","omori","deltarune"})for(String flower:new String[]{"dandelion","poppy","blue_orchid","oxeye_daisy"}){
   String id=family+"_"+flower;RegistryObject<Block> plant=BLOCKS.register(id,()->new FlowerBlock(net.minecraft.world.effect.MobEffects.REGENERATION,5,BlockBehaviour.Properties.copy(Blocks.DANDELION)));
   WORLD_BLOCKS.put(id,plant);ALL.put(id,ITEMS.register(id,()->new BlockItem(plant.get(),new Item.Properties())));
  }
  RegistryObject<Block> altar=BLOCKS.register("sanctuary_altar",()->new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(5f,1200f).lightLevel(s->11)));
  WORLD_BLOCKS.put("sanctuary_altar",altar);
  ALL.put("sanctuary_altar",ITEMS.register("sanctuary_altar",()->new BlockItem(altar.get(),new Item.Properties().rarity(Rarity.EPIC))));
  for(String id:new String[]{"dragon_eye","echo_token","rift_ingot","multiverse_heart","scarlet_gem","mechanical_core","dream_dust","cosmic_crystal","invasion_detector","echo_pouch","healing_orb","rift_bow","rift_pickaxe","rift_axe","rift_shovel","flame_staff","frost_staff","lightning_staff","teleport_dagger","scarlet_scythe","echo_chest","sanctuary_key"}){
    if(id.equals("rift_bow")) ALL.put(id,ITEMS.register(id,()->new BowItem(new Item.Properties().durability(650))));
    else if(id.equals("rift_pickaxe")) ALL.put(id,ITEMS.register(id,()->new PickaxeItem(Tiers.DIAMOND,2,-2.8f,new Item.Properties().durability(1561))));
    else if(id.equals("rift_axe")) ALL.put(id,ITEMS.register(id,()->new AxeItem(Tiers.DIAMOND,5,-3.0f,new Item.Properties().durability(1561))));
    else if(id.equals("rift_shovel")) ALL.put(id,ITEMS.register(id,()->new ShovelItem(Tiers.DIAMOND,2,-3.0f,new Item.Properties().durability(1561))));
    else if(id.equals("teleport_dagger")) ALL.put(id,ITEMS.register(id,()->new SwordItem(Tiers.DIAMOND,2,-1.5f,new Item.Properties().durability(850))));
    else if(id.equals("scarlet_scythe")) ALL.put(id,ITEMS.register(id,()->new SwordItem(Tiers.NETHERITE,6,-3f,new Item.Properties().durability(2031))));
    else register(id,new Item.Properties().rarity(id.contains("heart")?Rarity.EPIC:Rarity.UNCOMMON));
  }
  register("darkner_heart",new Item.Properties());register("darkner_diamond",new Item.Properties());
  for(String scrap:new String[]{"bigbolt","bottles","brassbell","cashregister","clock","clownhorn","cola","comedy","cookiemoldpan","fancylamp","flask","giftbox","goldbar","goldencup","hairdryer","jarofpickles","largeaxle","magic7ball","painting","perfumebottle","remote","ring","robot","rubberducky","smallfox","stopsign","toiletpaper"})register("lethal_scrap_"+scrap,new Item.Properties().stacksTo(16));
  ALL.put("spawn_omochao",ITEMS.register("spawn_omochao",()->new ForgeSpawnEggItem(BiomeMobs.OMOCHAO,0x7fceda,0xffee6e,new Item.Properties())));
  for(String mob:BiomeMobs.NAMES){ALL.put("spawn_"+mob,ITEMS.register("spawn_"+mob,()->new ForgeSpawnEggItem(BiomeMobs.ENTITIES.get(mob),0x6343A0,0xEEC26A,new Item.Properties())));}
  for(String mob:LethalMobs.NAMES){ALL.put("spawn_lethal_"+mob,ITEMS.register("spawn_lethal_"+mob,()->new ForgeSpawnEggItem(LethalMobs.ENTITIES.get(mob),0x393039,0xC74A4A,new Item.Properties())));}
  for(String boss:BOSSES){register("eye_"+boss,new Item.Properties().stacksTo(1).rarity(Rarity.RARE));register("sigil_"+boss,new Item.Properties().stacksTo(16));}
 }
 private static void register(String id,Item.Properties p){ALL.put(id,ITEMS.register(id,()->new Item(p)));}
 private static void registerArmor(String id,ArmorItem.Type type){ALL.put(id,ITEMS.register(id,()->new ArmorItem(ArmorMaterials.DIAMOND,type,new Item.Properties())));}
 private static Block themedBlock(String kind){
  Block original=kind.equals("snow")?Blocks.SNOW_BLOCK:ForgeRegistries.BLOCKS.getValue(new ResourceLocation("minecraft",kind));
  var properties=BlockBehaviour.Properties.copy(original);
  if(kind.equals("redstone_ore"))return new RedStoneOreBlock(properties);
  if(kind.equals("oak_log"))return new RotatedPillarBlock(properties);
  if(kind.equals("oak_leaves"))return new LeavesBlock(properties);
  if(kind.equals("sand")||kind.equals("gravel"))return new FallingBlock(properties);
  return new Block(properties);
 }
 public HinaLand(){software.bernie.geckolib.GeckoLib.initialize();IEventBus bus=FMLJavaModLoadingContext.get().getModEventBus();HinaSounds.SOUNDS.register(bus);ThemedGeology.FEATURES.register(bus);ITEMS.register(bus);BLOCKS.register(bus);TABS.register(bus);LethalMobs.register(bus);BiomeMobs.TYPES.register(bus);}
 public static Item item(String id){return ALL.get(id).get();}
 public static String bossFromEye(Item item){for(String b:BOSSES)if(item==item("eye_"+b))return b;return null;}
}
