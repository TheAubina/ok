package fr.hinaland.client;
import fr.hinaland.*;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.world.level.FoliageColor;
import net.minecraft.world.level.GrassColor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid=HinaLand.ID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class BiomeBlockColors {
 @SubscribeEvent public static void colors(RegisterColorHandlersEvent.Block e){
  for(String f:HinaWorldgen.FAMILIES){e.register((state,world,pos,tint)->world!=null&&pos!=null?BiomeColors.getAverageGrassColor(world,pos):GrassColor.getDefaultColor(),HinaLand.WORLD_BLOCKS.get(f+"_soil").get());}
 }
 @SubscribeEvent public static void itemColors(RegisterColorHandlersEvent.Item e){
  for(String f:HinaWorldgen.FAMILIES){int color=switch(f){case "mario"->7912276;case "sonic"->4641604;case "omori"->9333206;default->5012878;};e.register((stack,tint)->tint==0?color:-1,HinaLand.item(f+"_soil"));}
 }
 @SubscribeEvent public static void setup(FMLClientSetupEvent e){e.enqueueWork(()->{
  for(var entry:HinaLand.WORLD_BLOCKS.entrySet())if(entry.getValue().get() instanceof net.minecraft.world.level.block.FlowerBlock||entry.getKey().endsWith("_oak_leaves"))net.minecraft.client.renderer.ItemBlockRenderTypes.setRenderLayer(entry.getValue().get(),net.minecraft.client.renderer.RenderType.cutout());
 });}
}
