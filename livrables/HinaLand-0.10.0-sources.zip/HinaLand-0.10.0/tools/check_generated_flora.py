"""Count actual decoded flower blocks in saved FULL chunks (not palette membership)."""
from pathlib import Path
import json,sys,collections
from read_region import chunks
wanted={'hinaland:'+f+'_'+p for f in ['mario','omori','deltarune'] for p in ['dandelion','poppy','blue_orchid','oxeye_daisy']};count=collections.Counter();full=0
for chunk in chunks(sys.argv[1]):
 if str(chunk.get('Status')) not in {'minecraft:full','full'}:continue
 full+=1
 for section in chunk.get('sections',[]):
  bs=section.get('block_states',{});palette=[str(x['Name']) for x in bs.get('palette',[])];targets={i:n for i,n in enumerate(palette) if n in wanted}
  if not targets:continue
  if len(palette)==1:count[palette[0]]+=4096;continue
  bits=max(4,(len(palette)-1).bit_length());per=64//bits;mask=(1<<bits)-1;data=bs['data']
  for i in range(4096):
   value=((int(data[i//per])&((1<<64)-1))>>((i%per)*bits))&mask
   if value in targets:count[targets[value]]+=1
assert wanted.issubset(count),sorted(wanted-set(count))
Path(sys.argv[2]).write_text(json.dumps({'full_chunks':full,'actual_flower_blocks':dict(sorted(count.items()))},indent=2));print('All twelve flower blocks naturally present:',dict(sorted(count.items())))
