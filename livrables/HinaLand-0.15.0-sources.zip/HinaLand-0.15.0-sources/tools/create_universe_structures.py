"""Author 70 additional, compact game-inspired landmarks. Does not execute supplied pack scripts.
The catalogue is additive; existing 21 curated structures keep their own IDs. Run after 0.14 generators.
"""
import pathlib,json,sys,hashlib,collections
sys.path.insert(0,'/workspace/tools/pythonlibs')
import nbtlib as n
ROOT=pathlib.Path(__file__).resolve().parents[1]; DATA=ROOT/'src/main/resources/data/hinaland'
FAMILIES=['mario','sonic','omori','deltarune','genshin','overwatch','lethal']
# ID, French label, architectural programme, colour, named source-game inspiration, dungeon.
CATALOG={
'mario':[
 ('toad_house','Maison champignon de Toad','mushroom','red','Toad Houses — New Super Mario Bros.',False),
 ('peach_gatehouse','Porte du jardin royal','gate','pink','Peach’s Castle — Super Mario 64',False),
 ('bobomb_watchtower','Tour du champ de bataille','tower','red','Bob-omb Battlefield — Super Mario 64',False),
 ('yoshi_stable','Abri de Yoshi','stable','lime','Yoshi’s House — Super Mario World',False),
 ('underground_pipeworks','Galerie des tuyaux','tunnel','green','World 1-2 — Super Mario Bros.',False),
 ('desert_pyramid','Pyramide des sables','pyramid','yellow','Shifting Sand Land — Super Mario 64',True),
 ('boo_manor','Petit manoir des Boos','manor','purple','Ghost Houses — Super Mario World',True),
 ('beanbean_market','Étal du Royaume Végésia','market','lime','Beanbean Castle Town — Mario & Luigi: Superstar Saga',False),
 ('delfino_fountain','Fontaine de la place Delfino','fountain','cyan','Delfino Plaza — Super Mario Sunshine',False),
 ('airship_wreck','Épave de vaisseau volant','ship','brown','Airships — Super Mario Bros. 3',False)],
'sonic':[
 ('green_hill_loop','Boucle de Green Hill','loop','orange','Green Hill Zone — Sonic the Hedgehog',False),
 ('tails_workshop','Atelier de Tails','workshop','yellow','Tails’s Workshop — Sonic Adventure',False),
 ('chemical_plant_station','Station Chemical Plant','plant','purple','Chemical Plant Zone — Sonic the Hedgehog 2',True),
 ('angel_island_altar','Autel d’Angel Island','altar','lime','Master Emerald altar — Sonic Adventure',False),
 ('casino_night_arcade','Arcade Casino Night','arcade','magenta','Casino Night Zone — Sonic the Hedgehog 2',False),
 ('hydrocity_aqueduct','Aqueduc de Hydrocity','aqueduct','cyan','Hydrocity Zone — Sonic the Hedgehog 3',False),
 ('stardust_speedway_gate','Portique Stardust Speedway','gate','purple','Stardust Speedway — Sonic CD',False),
 ('oil_ocean_refinery','Raffinerie Oil Ocean','refinery','orange','Oil Ocean Zone — Sonic the Hedgehog 2',False),
 ('ice_cap_shelter','Refuge d’Ice Cap','cabin','light_blue','Ice Cap Zone — Sonic the Hedgehog 3',False),
 ('death_egg_outpost','Avant-poste Death Egg','bunker','gray','Death Egg Zone — Sonic & Knuckles',True)],
'omori':[
 ('basil_greenhouse','Serre de Basil','greenhouse','lime','Basil’s House and flowers — OMORI',False),
 ('neighbor_room','Pavillon des voisins','playroom','yellow','Neighbor’s Room — OMORI',False),
 ('otherworld_campsite','Camp d’Otherworld','camp','purple','Otherworld Campsite — OMORI',False),
 ('spaceboy_observatory','Observatoire de Space Boyfriend','observatory','cyan','Space Boyfriend’s House — OMORI',False),
 ('sweetheart_keep','Petit château de Sweetheart','keep','pink','Sweetheart’s Castle — OMORI',True),
 ('pyrefly_lantern_walk','Promenade de Pyrefly','lantern_walk','purple','Pyrefly Forest — OMORI',False),
 ('orange_oasis_ruin','Ruine d’Orange Oasis','pyramid','orange','Dino’s Dig — OMORI',True),
 ('snowglobe_cottage','Chalet de Snowglobe','cabin','white','Snowglobe Mountain — OMORI',False),
 ('last_resort_kiosk','Kiosque du Last Resort','arcade','magenta','Last Resort — OMORI',False),
 ('deeper_well_shrine','Sanctuaire de Deeper Well','shrine','blue','Deeper Well — OMORI',False)],
'deltarune':[
 ('castle_town_bakery','Boulangerie de Castle Town','bakery','purple','Castle Town bakery — DELTARUNE Chapter 2',False),
 ('card_castle_keep','Donjon du château des cartes','keep','red','Card Castle — DELTARUNE Chapter 1',True),
 ('field_hopes_pavilion','Pavillon du Champ des Espoirs','pavilion','lime','Field of Hopes and Dreams — DELTARUNE Chapter 1',False),
 ('forest_checker_bridge','Passage damier de la forêt','bridge','black','Forest checkerboard paths — DELTARUNE Chapter 1',False),
 ('cyber_city_crossing','Carrefour de Cyber City','crossing','cyan','Cyber City — DELTARUNE Chapter 2',False),
 ('spamton_shop','Boutique de Spamton','shop','yellow','Spamton’s shop — DELTARUNE Chapter 2',False),
 ('queen_signal_tower','Tour-relais de Queen','signal','blue','Queen’s Mansion — DELTARUNE Chapter 2',False),
 ('mansion_basement','Annexe du sous-sol du manoir','bunker','purple','Queen’s Mansion basement — DELTARUNE Chapter 2',True),
 ('music_stage','Scène des musiciens','stage','magenta','Sweet Cap’n Cakes — DELTARUNE Chapter 2',False),
 ('hometown_bookshop','Bibliothèque de Hometown','library','brown','Hometown library — DELTARUNE',False)],
'genshin':[
 ('mondstadt_windmill','Moulin de Mondstadt','windmill','white','Mondstadt windmills — Genshin Impact',False),
 ('dawn_winery_lodge','Loge du Domaine de l’Aurore','manor','red','Dawn Winery — Genshin Impact',False),
 ('liyue_harbor_pavilion','Pavillon du port de Liyue','pavilion','red','Liyue Harbor — Genshin Impact',False),
 ('wangshu_waystation','Relais de Wangshu','stilt','orange','Wangshu Inn — Genshin Impact',False),
 ('inazuma_torii','Torii d’Inazuma','torii','red','Grand Narukami Shrine — Genshin Impact',False),
 ('sumeru_study','Salle d’étude de Sumeru','library','green','Sumeru Akademiya — Genshin Impact',False),
 ('fontaine_clockwork','Atelier mécanique de Fontaine','workshop','blue','Fontaine clockwork mechanisms — Genshin Impact',False),
 ('dragonspine_camp','Camp des Monts Dosdragon','camp','light_blue','Dragonspine adventurer camp — Genshin Impact',False),
 ('hilichurl_encampment','Camp fortifié inspiré des Hilichurls','fort','brown','Hilichurl camps — Genshin Impact',True),
 ('ruin_guard_hall','Salle des ruines anciennes','ruin','yellow','Ruin Guard ruins — Genshin Impact',True)],
'overwatch':[
 ('gibraltar_launchpad','Plateforme de Gibraltar','launchpad','blue','Watchpoint: Gibraltar — Overwatch',False),
 ('hanamura_gate','Porte de Hanamura','torii','red','Hanamura — Overwatch',False),
 ('kings_row_pub','Pub de King’s Row','shop','brown','King’s Row — Overwatch',False),
 ('route66_diner','Diner de Route 66','diner','red','Route 66 — Overwatch',False),
 ('ilios_bell_tower','Clocher d’Ilios','belltower','white','Ilios — Overwatch',False),
 ('lijiang_control','Poste de contrôle de Lijiang','signal','cyan','Lijiang Tower — Overwatch',False),
 ('numbani_transit','Station de transit de Numbani','transit','yellow','Numbani — Overwatch',False),
 ('eichenwalde_gatehouse','Fortin d’Eichenwalde','keep','gray','Eichenwalde — Overwatch',True),
 ('volskaya_machinehall','Halle industrielle de Volskaya','plant','red','Volskaya Industries — Overwatch',True),
 ('busan_music_square','Place musicale de Busan','stage','magenta','Busan — Overwatch',False)],
'lethal':[
 ('landing_shuttle','Navette de débarquement','shuttle','yellow','Company ship — Lethal Company',False),
 ('assurance_pump','Pompe extérieure d’Assurance','pump','orange','Assurance industrial exterior — Lethal Company',False),
 ('vow_dam','Petit barrage de Vow','dam','gray','Vow bridge and dam — Lethal Company',False),
 ('experimentation_rail','Quai ferroviaire d’Experimentation','rail','yellow','Experimentation railway — Lethal Company',False),
 ('rend_lampposts','Chemin des lampadaires de Rend','lantern_walk','white','Rend lamp route — Lethal Company',False),
 ('dine_checkpoint','Poste extérieur de Dine','checkpoint','gray','Dine entrance paths — Lethal Company',False),
 ('titan_stairway','Escalier industriel de Titan','stairs','yellow','Titan exterior stairs — Lethal Company',False),
 ('artifice_warehouse_yard','Cour de stockage d’Artifice','yard','orange','Artifice warehouses — Lethal Company',False),
 ('embrion_relay','Relais d’Embrion','dish','blue','Embrion machinery landscape — Lethal Company',False),
 ('company_loading_dock','Quai de livraison de la Compagnie','dock','red','Company building delivery counter — Lethal Company',False)]}
MATERIALS={f:[x['material'] for x in json.loads((ROOT/'expansion-minerals-0.14.json').read_text()) if x['family']==f] for f in FAMILIES}
def write(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
class Build:
 def __init__(self,f,c,i):
  self.f=f;self.c='minecraft:'+c+'_concrete';self.i=i;self.b={};self.chests=[];self.spawners=[]
  self.rock='hinaland:'+f+'_stone_bricks';self.wood='hinaland:'+f+'_oak_planks';self.brick='hinaland:'+f+'_bricks';self.size=(11,16,11)
 def put(self,x,y,z,block=None,props=None,nbt=None):self.b[(x,y,z)]=(block or self.rock,props or {},nbt or {})
 def box(self,x0,y0,z0,x1,y1,z1,block=None,props=None):
  for x in range(x0,x1+1):
   for y in range(y0,y1+1):
    for z in range(z0,z1+1):self.put(x,y,z,block,props)
 def clear(self,x0,y0,z0,x1,y1,z1):
  for x in range(x0,x1+1):
   for y in range(y0,y1+1):
    for z in range(z0,z1+1):self.b.pop((x,y,z),None)
 def foundation(self):
  # Octagonal 11x11 footprint: no unnatural solid platform corners.
  for x in range(11):
   for z in range(11):
    if (x in [0,10] and z in [0,1,9,10]) or (z in [0,10] and x in [0,1,9,10]):continue
    for y in range(3):self.put(x,y,z,'hinaland:'+self.f+('_stone' if y<2 else '_stone_bricks'))
 def chest(self,x,y,z,table):
  self.put(x,y,z,'minecraft:chest',{'facing':'south','type':'single','waterlogged':'false'},{'LootTable':n.String(table)});self.chests.append([x,y,z])
 def lamp(self,x,y,z,hanging=False):self.put(x,y,z,'minecraft:lantern',{'hanging':'true' if hanging else 'false','waterlogged':'false'})
 def flower(self,x,z):self.put(x,2,z,'hinaland:'+self.f+'_soil');self.put(x,3,z,'hinaland:'+self.f+'_poppy')
 def room(self,x0,z0,x1,z1,h=4,wall=None):
  wall=wall or self.brick
  for y in range(3,3+h):
   for x in range(x0,x1+1):
    for z in [z0,z1]:self.put(x,y,z,wall)
   for z in range(z0,z1+1):
    for x in [x0,x1]:self.put(x,y,z,wall)
  # South entrance, two blocks wide and three high. No iron-door lock or impassable threshold.
  for x in [5,6]:self.clear(x,3,z0,x,5,z0)
  for x in [x0,x1]:
   for z in range(z0+2,z1,3):self.put(x,4,z,'minecraft:glass_pane',{'north':'true','south':'true','east':'false','west':'false','waterlogged':'false'})
  self.box(x0,3+h,z0,x1,3+h,z1,self.wood)
 def pitched(self,x0,z0,x1,z1,y=7):
  for z in range(z0,z1+1):
   rise=min(z-z0,z1-z)
   self.box(x0,y+rise,z,x1,y+rise,z,self.c)
 def spawner(self,x,y,z,mob):
  # Custom light ranges deliberately bypass surface-only NATURAL predicates for this authored dungeon.
  rules=n.Compound({'block_light_limit':n.Compound({'min_inclusive':n.Int(0),'max_inclusive':n.Int(15)}),'sky_light_limit':n.Compound({'min_inclusive':n.Int(0),'max_inclusive':n.Int(15)})})
  spawn=n.Compound({'entity':n.Compound({'id':n.String(mob)}),'custom_spawn_rules':rules})
  self.put(x,y,z,'minecraft:spawner',nbt={'SpawnData':spawn,'SpawnPotentials':n.List[n.Compound]([n.Compound({'weight':n.Int(1),'data':spawn})]),'Delay':n.Short(80),'MinSpawnDelay':n.Short(240),'MaxSpawnDelay':n.Short(480),'SpawnCount':n.Short(1),'MaxNearbyEntities':n.Short(3),'RequiredPlayerRange':n.Short(12),'SpawnRange':n.Short(2)})
  self.spawners.append({'position':[x,y,z],'entity':mob})
 def build(self,kind):
  self.foundation()
  if kind in ['cabin','manor','shop','bakery','library','workshop','diner','playroom','greenhouse']:
   self.room(1,1,9,9,wall='minecraft:glass' if kind=='greenhouse' else self.brick);self.pitched(0,0,10,10)
   if kind=='greenhouse':
    for pos,(block,props,extra) in list(self.b.items()):
     if pos[1]>=7 and block in [self.wood,self.c]:self.put(*pos,'minecraft:glass')
   elif kind=='cabin':
    for pos,(block,props,extra) in list(self.b.items()):
     if pos[1]>=7 and block==self.c:self.put(*pos,'minecraft:snow_block')
   if kind=='manor':self.box(1,8,2,2,12,3,self.brick);self.lamp(1,13,2)
   if kind in ['shop','bakery','diner']:
    self.box(2,3,4,4,3,4,self.wood);self.box(7,3,4,8,3,4,self.wood);self.box(1,6,0,9,6,0,self.c)
    self.put(2,4,4,'minecraft:cake' if kind=='bakery' else 'minecraft:flower_pot')
    self.put(8,3,7,'minecraft:smoker',{'facing':'south','lit':'false'});self.put(7,3,7,'minecraft:crafting_table')
   elif kind=='library':
    self.box(2,3,8,8,5,8,'minecraft:bookshelf');self.box(2,3,5,2,5,7,'minecraft:bookshelf');self.put(5,3,7,'minecraft:lectern',{'facing':'south','has_book':'false','powered':'false'})
   elif kind=='workshop':
    self.put(2,3,7,'minecraft:anvil',{'facing':'north'});self.put(3,3,7,'minecraft:smithing_table');self.put(7,3,7,'minecraft:crafting_table');self.put(8,3,7,'minecraft:furnace',{'facing':'south','lit':'false'})
   elif kind=='greenhouse':
    for x in [2,4,7]:
     for z in [3,6,8]:self.flower(x,z)
   elif kind=='playroom':
    self.box(2,3,5,4,3,7,'minecraft:yellow_carpet');self.box(6,3,5,8,3,7,'minecraft:pink_carpet');self.put(2,3,8,'minecraft:note_block')
   else:
    self.put(2,3,7,'minecraft:crafting_table');self.put(8,3,7,'minecraft:barrel',{'facing':'up','open':'false'});self.box(2,3,4,3,3,4,'minecraft:oak_slab',{'type':'bottom','waterlogged':'false'})
   self.lamp(4,6,4,True)
  elif kind=='mushroom':
   for y in range(3,7):
    for x in range(2,9):
     for z in range(2,9):
      if x in [2,8] or z in [2,8]:self.put(x,y,z,'minecraft:white_concrete')
   self.clear(5,3,2,6,5,2)
   for y in range(7,11):
    width=[5,5,4,2][y-7]
    for x in range(5-width,6+width):
     for z in range(5-width,6+width):
      if (x-5)**2+(z-5)**2<=width**2+4:self.put(x,y,z,'minecraft:white_concrete' if (x+2*z+y)%7==0 else self.c)
   self.put(3,3,7,'minecraft:crafting_table');self.lamp(5,6,5,True)
  elif kind in ['tower','belltower','signal','observatory','windmill']:
   self.room(2,2,8,8,h=8,wall=self.wood if kind=='windmill' else ('minecraft:white_concrete' if kind=='belltower' else self.brick))
   self.clear(5,3,2,6,5,2)
   # Climbable tower: ladders attach to the north interior wall all the way to the upper hatch.
   for y in range(3,12):self.put(4,y,7,'minecraft:ladder',{'facing':'north','waterlogged':'false'})
   self.clear(4,11,7,4,11,7)
   if kind=='observatory':
    for y,w in [(12,4),(13,3),(14,2)]:
     for x in range(5-w,6+w):
      for z in range(5-w,6+w):
       if (x-5)**2+(z-5)**2<=w*w:self.put(x,y,z,self.c)
    self.put(5,12,5,'minecraft:lightning_rod',{'facing':'up','powered':'false','waterlogged':'false'})
   elif kind=='windmill':
    for k in range(-4,5):self.put(5+k,9+k,1,'minecraft:white_wool');self.put(5+k,9-k,1,'minecraft:white_wool')
   elif kind=='signal':
    self.box(5,12,5,5,14,5,'minecraft:iron_bars');self.box(2,13,5,8,13,5,self.c);self.put(5,15,5,'minecraft:redstone_lamp',{'lit':'false'})
   elif kind=='belltower':self.put(5,12,5,'minecraft:bell',{'facing':'south','attachment':'floor','powered':'false'});self.pitched(1,1,9,9,13)
   else:
    for x,z in [(2,2),(2,8),(8,2),(8,8)]:self.box(x,12,z,x,13,z,self.brick)
  elif kind in ['gate','torii','pavilion','shrine','altar']:
   height=7 if kind in ['gate','torii'] else 6
   for x in [2,8]:
    for z in ([3] if kind in ['gate','torii'] else [2,8]):self.box(x,3,z,x,height,z,self.c);self.lamp(x,height+1,z)
   if kind in ['gate','torii']:
    self.box(0,height,3,10,height,3,self.c);self.box(1,height+2,3,9,height+2,3,self.wood)
    if self.f=='mario':
     # Royal castle gate rather than a Japanese torii: stone towers and pink crenellations.
     self.clear(0,height,3,10,height+2,3)
     for x in [1,8]:
      self.box(x,3,2,x+1,9,4,self.rock)
      for xx in [x,x+1]:self.put(xx,10,2,self.c);self.put(xx,10,4,self.c)
     self.box(3,7,3,7,7,3,self.c);self.box(4,8,3,6,8,3,self.c);self.put(5,9,3,'minecraft:gold_block')
   else:self.pitched(1,1,9,9,height+1)
   if kind in ['shrine','altar']:self.box(4,3,5,6,3,7,self.rock);self.put(5,4,6,'hinaland:'+MATERIALS[self.f][2]+'_block')
   else:self.box(3,3,7,7,3,7,self.wood)
  elif kind in ['keep','bunker','plant','fort','ruin','pyramid']:
   if kind=='pyramid':
    for y in range(3,9):
     inset=(y-3)//2;lo=inset;hi=10-inset
     for x in range(lo,hi+1):
      for z in range(lo,hi+1):
       if x in [lo,hi] or z in [lo,hi] or y==8:self.put(x,y,z,'hinaland:'+self.f+'_sandstone')
    self.clear(5,3,0,6,5,3)
   else:
    self.room(1,1,9,9,h=5,wall='minecraft:polished_deepslate' if kind=='bunker' else self.brick)
    if kind in ['keep','fort']:
     for x,z in [(1,1),(1,9),(9,1),(9,9)]:self.box(x,8,z,x,10,z,self.c)
     self.box(1,9,1,9,9,1,self.brick);self.clear(4,9,1,6,9,1)
    elif kind=='plant':
     for x in [2,8]:self.box(x,8,7,x,13,7,'minecraft:iron_block');self.put(x,14,7,'minecraft:campfire',{'facing':'north','lit':'true','signal_fire':'false','waterlogged':'false'})
     self.box(1,8,3,9,8,3,self.c)
    elif kind=='ruin':
     self.clear(2,8,2,8,8,8);self.clear(1,5,4,1,7,7);self.box(7,3,7,8,3,8,'minecraft:mossy_cobblestone')
    else:self.box(2,9,2,8,9,8,self.c)
   # Two connected encounter spaces, clear 3-block-wide passage. Treasure in rear room.
   for x in [2,3,7,8]:self.box(x,3,5,x,5,5,self.rock)
  elif kind in ['tunnel','aqueduct','bridge','dam']:
   for x in [1,9]:self.box(x,3,1,x,6,9,self.brick)
   for z in [1,5,9]:
    self.box(1,7,z,9,7,z,self.c)
   if kind=='tunnel':
    self.box(1,7,1,9,7,9,self.c)
    for z in [3,7]:self.box(2,3,z,3,5,z,'minecraft:green_concrete')
   elif kind in ['aqueduct','dam']:
    self.box(2,5,1,8,5,9,self.rock);self.box(3,6,1,7,6,9,'minecraft:water',{'level':'0'})
    # Fully contained channel: never creates the world-flooding Nether issue.
    self.box(2,6,0,8,6,0,self.rock);self.box(2,6,10,8,6,10,self.rock)
    for x in [2,8]:self.box(x,6,1,x,6,9,self.rock)
   else:
    for x in range(2,9):
     for z in range(1,10):self.put(x,2,z,'minecraft:white_concrete' if (x+z)%2==0 else 'minecraft:black_concrete')
  elif kind=='loop':
   for x,y in [(1,5),(1,6),(2,4),(2,7),(3,3),(3,8),(4,3),(4,8),(5,3),(5,8),(6,3),(6,8),(7,4),(7,7),(8,5),(8,6)]:
    for z in [4,5]:self.put(x,y,z,'minecraft:orange_terracotta')
   for x in [0,9]:self.box(x,3,2,x,4,7,'minecraft:grass_block',{'snowy':'false'})
  elif kind in ['camp','stable','market','lantern_walk']:
   if kind=='lantern_walk':
    for z in [1,5,9]:
     for x in [1,9]:self.box(x,3,z,x,6,z,'minecraft:oak_fence');self.lamp(x,7,z)
    for z in range(11):self.put(5,2,z,self.c)
   else:
    for x,z in [(1,1),(1,8),(9,1),(9,8)]:self.box(x,3,z,x,5,z,'minecraft:oak_fence')
    for z in range(1,9):
     for x in range(1,10):self.put(x,6+min(x-1,9-x)//2,z,self.c if kind!='stable' else self.wood)
    if kind=='camp':self.put(5,3,5,'minecraft:campfire',{'facing':'north','lit':'true','signal_fire':'false','waterlogged':'false'});self.box(2,3,6,3,3,6,self.wood)
    elif kind=='stable':self.box(2,3,7,3,3,8,'minecraft:hay_block',{'axis':'y'});self.put(7,3,7,'minecraft:cauldron')
    else:self.box(2,3,5,8,3,5,self.wood);self.put(3,4,5,'minecraft:flower_pot');self.put(7,4,5,'minecraft:cake')
  elif kind=='fountain':
   for x in range(2,9):
    for z in range(2,9):
     self.put(x,3,z,self.rock if x in [2,8] or z in [2,8] else 'minecraft:water',{'level':'0'} if x not in [2,8] and z not in [2,8] else None)
   self.box(5,3,5,5,6,5,'minecraft:quartz_pillar',{'axis':'y'});self.put(5,7,5,'minecraft:sea_lantern')
  elif kind in ['ship','shuttle']:
   for x in range(1,10):
    for z in range(2,9):
     if abs(x-5)+abs(z-5)<7:self.put(x,3,z,self.wood if kind=='ship' else 'minecraft:iron_block')
   for z in range(3,8):
    for x in [1,9]:self.box(x,4,z,x,5,z,self.wood if kind=='ship' else self.c)
   if kind=='ship':
    self.box(5,4,5,5,12,5,'minecraft:oak_log',{'axis':'y'});self.box(6,8,5,9,11,5,'minecraft:white_wool');self.box(2,7,5,4,10,5,self.c)
   else:
    self.box(2,6,3,8,6,7,'minecraft:iron_block');self.box(2,4,2,4,5,2,'minecraft:glass');self.box(7,4,2,8,5,2,'minecraft:glass');self.put(3,4,6,'minecraft:crafting_table');self.put(7,4,6,'minecraft:lever',{'face':'floor','facing':'north','powered':'false'})
   self.put(5,3,1,'minecraft:oak_stairs',{'facing':'south','half':'bottom','shape':'straight','waterlogged':'false'})
  elif kind in ['arcade','stage','crossing','transit','launchpad']:
   if kind=='crossing':
    for x in range(11):
     for z in range(11):
      if x in [4,5,6] or z in [4,5,6]:self.put(x,2,z,'minecraft:black_concrete' if (x+z)%3 else 'minecraft:white_concrete')
    for x,z in [(1,1),(9,9)]:self.box(x,3,z,x,8,z,'minecraft:iron_bars');self.put(x,9,z,'minecraft:sea_lantern')
   elif kind=='launchpad':
    for x in range(2,9):
     for z in range(2,9):self.put(x,2,z,self.c if x in [2,8] or z in [2,8] else 'minecraft:white_concrete')
    self.box(1,3,8,2,6,9,'minecraft:iron_block');self.put(2,7,8,'minecraft:lightning_rod',{'facing':'up','powered':'false','waterlogged':'false'})
   else:
    self.box(1,3,5,9,3,9,self.wood);self.box(1,4,9,9,6,9,self.c)
    for x in [1,9]:self.box(x,3,2,x,6,8,self.brick)
    self.box(1,7,2,9,7,9,self.c)
    if kind=='stage':
     for x in [3,5,7]:self.put(x,4,8,'minecraft:note_block')
     self.put(2,4,7,'minecraft:jukebox')
    elif kind=='arcade':
     for x in [2,4,6,8]:self.box(x,4,8,x,5,8,'minecraft:note_block');self.put(x,6,8,'minecraft:redstone_lamp',{'lit':'false'})
    else:self.box(2,3,4,3,3,4,'minecraft:oak_slab',{'type':'bottom','waterlogged':'false'});self.put(8,3,4,'minecraft:cartography_table')
   # Steps to raised stage: visitors do not need to jump a full-block wall.
   if kind in ['stage','arcade','transit']:self.box(4,3,4,6,3,4,'minecraft:oak_stairs',{'facing':'south','half':'bottom','shape':'straight','waterlogged':'false'})
  elif kind in ['refinery','pump','dish','stairs','stilt','checkpoint','yard','dock','rail']:
   if kind in ['refinery','pump']:
    for x in [2,8]:
     self.box(x,3,3,x,9 if kind=='refinery' else 6,3,'minecraft:iron_block');self.box(x,3,7,x,7,7,self.c)
    self.box(2,7,3,8,7,3,'minecraft:iron_block');self.put(5,3,7,'minecraft:blast_furnace',{'facing':'south','lit':'false'})
   elif kind=='dish':
    self.box(5,3,5,5,8,5,'minecraft:iron_block')
    for x in range(2,9):
     for z in range(2,9):
      if (x-5)**2+(z-5)**2<=10:self.put(x,9 if abs(x-5)+abs(z-5)<3 else 10,z,'minecraft:white_concrete')
    self.box(5,10,5,5,12,5,'minecraft:iron_bars')
   elif kind in ['stairs','stilt']:
    self.box(3,8,7,8,8,9,self.wood if kind=='stilt' else 'minecraft:iron_block')
    for x,z in [(3,7),(3,9),(8,7),(8,9)]:self.box(x,3,z,x,7,z,self.brick)
    for step in range(6):
     for x in [5,6]:self.put(x,3+step,1+step,'minecraft:stone_brick_stairs',{'facing':'south','half':'bottom','shape':'straight','waterlogged':'false'})
    if kind=='stilt':
     for x in [3,8]:self.box(x,9,7,x,11,9,self.c)
     self.box(3,12,7,8,12,9,self.wood)
   elif kind=='checkpoint':
    self.box(1,3,5,3,6,8,'minecraft:iron_block');self.clear(2,3,5,2,5,7);self.box(1,7,4,4,7,9,self.c);self.box(6,4,5,9,4,5,'minecraft:oak_fence');self.put(7,5,5,'minecraft:redstone_lamp',{'lit':'false'})
   elif kind=='yard':
    for x,z in [(1,2),(7,3),(3,7)]:self.box(x,3,z,x+2,5+(x%2),z+2,self.c);self.put(x+1,3,z,'minecraft:barrel',{'facing':'south','open':'false'})
   elif kind=='rail':
    for z in [3,7]:
     for x in range(11):self.put(x,3,z,'minecraft:rail',{'shape':'east_west','waterlogged':'false'})
    self.box(2,3,5,8,3,5,self.c);self.box(2,4,5,3,5,5,'minecraft:iron_block');self.put(7,4,5,'minecraft:barrel',{'facing':'up','open':'false'})
   else:
    self.box(1,3,6,9,3,9,'minecraft:iron_block');self.box(1,4,9,9,6,9,self.c);self.put(5,4,8,'minecraft:barrel',{'facing':'south','open':'false'});self.box(4,3,5,6,3,5,'minecraft:stone_brick_stairs',{'facing':'south','half':'bottom','shape':'straight','waterlogged':'false'})
  else:raise ValueError(kind)
  # A small universe-specific emblem distinguishes repeated architectural programmes.
  if self.f=='mario':
   for x in [3,7]:self.put(x,6,0,'hinaland:mario_question_block')
  elif self.f=='sonic':self.put(0,3,5,'hinaland:ring_gold_block')
  elif self.f=='omori':self.flower(0,5)
  elif self.f=='deltarune':self.put(0,3,5,'hinaland:glowshard_block')
  elif self.f=='genshin':self.put(0,3,5,'hinaland:crystal_chunk_block')
  elif self.f=='overwatch':self.put(0,3,5,'hinaland:hardlight_crystal_block')
  else:self.put(0,3,5,'hinaland:company_alloy_block')
  # Small readable sign provides actual in-game identity, not just a differently named file.
 def save(self,name,label,dungeon):
  table='hinaland:chests/universe_'+self.f+('_dungeon' if dungeon else '_landmark')
  # Keep rewards on the ground floor; no teleport-dependent access to the top of towers.
  chestpos=[7,3,7]
  if name.endswith(('landing_shuttle','airship_wreck')):chestpos=[7,4,6]
  if name.endswith('artifice_warehouse_yard'):chestpos=[5,3,3]
  if name.endswith('company_loading_dock'):chestpos=[7,4,7]
  if name.endswith('titan_stairway'):chestpos=[7,9,8]
  self.chest(*chestpos,table)
  if dungeon:
   mob={'mario':'hinaland:dry_bones' if self.i==6 else 'hinaland:goomba','sonic':'hinaland:motobug','omori':'hinaland:sprout_mole','deltarune':'hinaland:rudinn','genshin':'minecraft:zombie','overwatch':'minecraft:skeleton'}[self.f]
   self.spawner(3,3,7,mob)
   # Spawner alcove is open to the main passage, two full air blocks above potential spawn floor.
   self.clear(2,4,6,4,6,8)
  words=label.split();lines=['']*4;line=0
  for word in words:
   if len(lines[line]+' '+word)>18 and line<3:line+=1
   lines[line]=(lines[line]+' '+word).strip()
  self.put(5,3,0,'minecraft:oak_sign',{'rotation':'8','waterlogged':'false'},{'front_text':n.Compound({'messages':n.List[n.String]([json.dumps({'text':v},ensure_ascii=False) for v in lines]),'color':n.String('black'),'has_glowing_text':n.Byte(0)})})
  palette=[];index={};blocks=[]
  for p,(block,props,extra) in sorted(self.b.items()):
   key=(block,tuple(sorted(props.items())))
   if key not in index:
    index[key]=len(palette);s=n.Compound({'Name':n.String(block)})
    if props:s['Properties']=n.Compound({k:n.String(v) for k,v in props.items()})
    palette.append(s)
   obj=n.Compound({'pos':n.List[n.Int](p),'state':n.Int(index[key])})
   if extra:obj['nbt']=n.Compound(extra)
   blocks.append(obj)
  size=[max(p[j] for p in self.b)+1 for j in range(3)]
  n.File({'DataVersion':n.Int(3465),'size':n.List[n.Int](size),'palette':n.List[n.Compound](palette),'blocks':n.List[n.Compound](blocks),'entities':n.List[n.Compound]([])},gzipped=True).save(DATA/f'structures/{name}.nbt')
  write(DATA/f'worldgen/structure/{name}.json',{'type':'hinaland:grounded','biomes':'#hinaland:has_structure/'+name,'step':'surface_structures','spawn_overrides':{},'terrain_adaptation':'none','template':'hinaland:'+name,'max_slope':4})
  write(DATA/f'tags/worldgen/biome/has_structure/{name}.json',{'values':['hinaland:'+self.f,'hinaland:'+self.f+'_forest']})
  return {'family':self.f,'structure':name,'name_fr':label,'size':size,'dungeon':dungeon,'chests':self.chests,'spawners':self.spawners,'block_count':len(blocks),'geometry_sha256':hashlib.sha256(str(sorted(self.b.items())).encode()).hexdigest()}

def loot(f,dungeon):
 def item(name,weight,count=1):return {'type':'minecraft:item','name':name,'weight':weight,'functions':[{'function':'minecraft:set_count','count':count}]}
 pools=[{'rolls':{'type':'minecraft:uniform','min':2,'max':4},'entries':[item('minecraft:bread',6,{'type':'minecraft:uniform','min':1,'max':3}),item('hinaland:'+f+'_essence',2),item('minecraft:torch',4,{'type':'minecraft:uniform','min':3,'max':8}),item('hinaland:'+MATERIALS[f][0],4,{'type':'minecraft:uniform','min':1,'max':3})]}]
 if dungeon:pools.append({'rolls':1,'entries':[item('hinaland:'+MATERIALS[f][1],7,{'type':'minecraft:uniform','min':1,'max':2}),item('hinaland:'+MATERIALS[f][2],2),item('minecraft:golden_apple',1)]})
 write(DATA/f'loot_tables/chests/universe_{f}_{"dungeon" if dungeon else "landmark"}.json',{'type':'minecraft:chest','pools':pools})
manifest=[]
for f,rows in CATALOG.items():
 assert len(rows)==10
 for dungeon in ([False] if f=='lethal' else [False,True]):loot(f,dungeon)
 for i,(slug,label,kind,colour,inspiration,dungeon) in enumerate(rows):
  b=Build(f,colour,i);b.build(kind);obj=b.save(f+'_'+slug,label,dungeon);obj.update({'architecture':kind,'inspiration':inspiration,'interpretation':'Compact Minecraft reinterpretation, not an exact map conversion.'});manifest.append(obj)
 p=DATA/f'worldgen/structure_set/{f}_settlements.json';sets=json.loads(p.read_text());ids={x['structure'] for x in manifest if x['family']==f}
 write(DATA/f'tags/worldgen/structure/{f}_new_landmarks.json',{'values':['hinaland:'+x['structure'] for x in manifest if x['family']==f]})
 sets['structures']=[v for v in sets['structures'] if v['structure'].split(':')[1] not in ids]
 # Preserve the single shared sparse grid. New dungeons have half the relative weight of new landmarks.
 sets['structures'] += [{'structure':'hinaland:'+v['structure'],'weight':1 if v['dungeon'] else 2} for v in manifest if v['family']==f]
 write(p,sets)
write(ROOT/'universe-structures-0.15.json',{'version':'0.15.0','new_count':70,'existing_count':21,'total_natural':91,'dungeons':12,'families':FAMILIES,'structures':manifest,'placement':{'spacing':48,'separation':24,'frequency':0.65,'shared_salt':137130}})
print('70 new structures, 12 surface dungeons, 10 outdoor Lethal landmarks; 91 naturally registered in seven shared sparse grids.')
