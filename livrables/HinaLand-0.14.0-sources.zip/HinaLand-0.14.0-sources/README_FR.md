# Hina Land 0.14.0 — Forge 1.20.1

Le mod compilé est `hinaland-0.14.0.jar`, à installer dans `mods` avec GeckoLib 4.4.9 et TerraBlender 3.0.1.7. Java 17 et Forge 47.3.0 sont la combinaison vérifiée. Les autres mods fournis sont regroupés dans le modpack de test 8.

Cette bêta ajoute trois minerais et trois niveaux d’équipement par chacun des sept univers générés, des blocs « ? » Mario interactifs, quatre petits modèles thématiques et sept portails du Nether complets. Les modèles et poses des créatures ont été peaufinés. Voir [le rapport détaillé](RAPPORT_PEAUFINAGE_0.14_FR.md) pour les preuves et limites ; la fidélité directe des deux robots Sonic reste partiellement vérifiée.

Pour compiler les sources générées :

```bash
./gradlew build --max-workers=2 --console=plain
./gradlew runGameTestServer --max-workers=2 --console=plain
python tools/check_assets.py
python tools/check_expansion_assets.py
```

La suite vérifiée exécute **40 GameTests Forge**. Exiger leur message de réussite, pas uniquement `BUILD SUCCESSFUL`. Les tests et leur modèle vide sont exclus du JAR de production. Les importateurs nécessitent les packs et mondes originaux ; leurs gros fichiers ne sont pas dans ce ZIP. Les ressources générées présentes permettent la compilation sans les réimporter.

Une copie de sauvegarde Normal 0.13 a été ouverte avec la mise à jour. Les nouveaux minerais et constructions nécessitent de nouveaux chunks. Les ruines anciennes ne sont pas reconstruites automatiquement. Les mondes antérieurs à 0.13 et les presets autres que Normal ne sont pas validés.
