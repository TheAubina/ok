# Hina Land 0.8.0 — modpack de test 2

Minecraft Java 1.20.1, Java 17, Forge 47.3.0.

Extraire `mods`, `config` et `resourcepacks` dans une nouvelle instance Minecraft. Le paquet contient 22 JAR. Remplacer Hina Land 0.7.0 par 0.8.0 ; ne pas conserver les deux JAR. Copier également `config/terrablender.toml` : taille des régions 5 et poids vanilla 6.

Activer `HinaLand-integration-textures.zip` dans Options → Packs de ressources. Créer un nouveau monde pour profiter des douze biomes, régions agrandies, arbres et sous-sol thématiques. Les chunks existants conservent leur ancienne génération.

Le carnet FTB est accessible par l’icône de livre de l’inventaire. Les chapitres fournis sont conservés. Lunaria Media 2.0.2 reste absent et trois succès de quête restent bloqués. Carry On et le transport de coffres par le Hoarding Bug ne sont pas inclus.

Sur serveur : mêmes 22 JAR et même configuration TerraBlender. Le pack de ressources est destiné au client. Les réglages hors ligne, délais de test et mondes de validation ne sont pas distribués.

Voir `RAPPORT_WORLDGEN_0.8_FR.md` pour les tests actuels ; les rapports 0.7 dans `docs` sont historiques.
