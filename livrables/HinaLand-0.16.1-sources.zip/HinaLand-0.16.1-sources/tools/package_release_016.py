"""Package the verified 0.16 JAR and clean 23-mod pack; preserve supplied Lunaria unchanged."""
from pathlib import Path
import json,shutil,zipfile,hashlib,struct
r=Path(__file__).resolve().parents[1];repo=Path('/workspace/ok');dest=repo/'livrables';audit=r/'audit-0.16';jar=r/'build/libs/hinaland-0.16.1.jar'
log=(r/'tests-build-0.16.log').read_text();assert 'All 59 required tests passed' in log and 'BUILD SUCCESSFUL' in log
proof=json.loads((audit/'production-verification.json').read_text());assert proof['jar_sha256']==hashlib.sha256(jar.read_bytes()).hexdigest()
assert proof['old_vanilla_removed'] and proof['spawner_migrated'] and proof['client_joined'] and len(proof['rendered_new_creatures'])==32
with zipfile.ZipFile(jar) as z:
 assert z.testzip() is None and 'META-INF/mods.toml' in z.namelist()
 assert struct.unpack('>H',z.read('fr/hinaland/HinaLand.class')[6:8])[0]==61
 assert not any(x.startswith('fr/hinaland/test/') for x in z.namelist())
 sets=[json.loads(z.read(x)) for x in z.namelist() if x.startswith('data/hinaland/worldgen/structure_set/') and x.endswith('.json')]
 assert len(sets)==7 and sum(len(x['structures']) for x in sets)==91
shutil.copy2(jar,dest/jar.name)
pack=r/'modpack-0.16.1';pack.mkdir(exist_ok=True)
for name in ['mods','config','resourcepacks']:shutil.copytree(r/'modpack-0.15.0'/name,pack/name,dirs_exist_ok=True)
for old in (pack/'mods').glob('hinaland-*.jar'):old.unlink()
for old in (pack/'mods').glob('lunariamedia-*.jar'):old.unlink()
shutil.copy2(jar,pack/'mods'/jar.name)
lunaria=r/'imported-mods/lunariamedia-2.1.0.jar';assert hashlib.sha256(lunaria.read_bytes()).hexdigest()=='6bf6eb890c37763b5d0bbf4e0056980098248111f8159696bfd1e894a13bd6ed';shutil.copy2(lunaria,pack/'mods'/lunaria.name)
assert len(list((pack/'mods').glob('*.jar')))==23
for p in (r/'modpack-0.15.0').glob('*.md'):shutil.copy2(p,pack/p.name)
for name in ['RAPPORT_CREATURES_0.16_FR.md','CATALOGUE_CREATURES_0.16_FR.md']:shutil.copy2(r/name,pack/name);shutil.copy2(r/name,repo/'docs'/name)
(pack/'INSTALLATION_FR.md').write_text('''# Hina Land — 0.16.1 / modpack de test 10

Minecraft Java 1.20.1, Forge 47.3.0, Java 17. Copier mods, config et resourcepacks dans une instance dédiée. GeckoLib et TerraBlender sont inclus. Remplacer les anciens JAR Hina Land et Lunaria ; conserver une seule version de chaque mod. Activer HinaLand-integration-textures.

32 créatures supplémentaires, 50 Hina au total. Les monstres vanilla sont bloqués dans l’Overworld, les passifs restent autorisés. Les anciens générateurs de monstres vanilla de l’Overworld sont convertis au chargement. La tenue bleue de Mario est affichée comme costume Pingouin ; la verte comme costume Grenouille. Lunaria Media 2.1.0 est inclus, inchangé.

Les 70 constructions ajoutées en 0.15 restent présentes, soit 91 choix de génération. Explorer de nouveaux chunks pour les nouveaux bâtiments ; les bâtiments enregistrés ne sont pas reconstruits. Conserver une sauvegarde avant mise à jour.

Lire RAPPORT_CREATURES_0.16_FR.md pour les vérifications et limites : 59 tests Forge, migration, rendu client. Certains ennemis sont des sprites 2D ; les autres modèles sont des réinterprétations voxel. Le compagnon de quêtes peut encore dupliquer des chapitres au redémarrage. La lecture audio/vidéo Lunaria n’est pas validée.
''')
pa=pack/'audit/0.16';pa.mkdir(parents=True,exist_ok=True)
for p in audit.iterdir():
 if p.is_file():shutil.copy2(p,pa/p.name)
for p in (audit/'references').glob('*.json'):shutil.copy2(p,pa/('references-'+p.name))
shutil.copy2(r/'tests-build-0.16.log',pa/'gametests-build.log');shutil.copy2(r/'creature-expansion-0.16.json',pa/'creature-manifest.json')
(pack/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(pack)) for p in sorted((pack/'mods').glob('*.jar')))+'\n')
def zipped(path,files,prefix):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,rel in files:z.write(p,prefix+'/'+str(rel))
source=[]
for folder in ['src','gradle','tools','reference_worldgen']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':source.append((p,p.relative_to(r)))
for p in r.iterdir():
 if p.is_file() and not p.name.startswith(('deliverables-','downloads-')) and (p.suffix in ['.md','.json'] or p.name in ['build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat']):source.append((p,p.name))
for p in audit.glob('*.json'):source.append((p,Path('audit-0.16')/p.name))
zipped(dest/'HinaLand-0.16.1-sources.zip',source,'HinaLand-0.16.1-sources')
zipped(dest/'HinaLand-0.16.1-modpack-test-10.zip',[(p,p.relative_to(pack)) for p in pack.rglob('*') if p.is_file()],'HinaLand-0.16.1-modpack-test-10')
files=[dest/jar.name,dest/'HinaLand-0.16.1-sources.zip',dest/'HinaLand-0.16.1-modpack-test-10.zip'];result=[]
for p in files:
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
 result.append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(r/'deliverables-0.16.1.json').write_text(json.dumps(result,indent=2)+'\n')
shutil.copy2(r/'creature-expansion-0.16.json',repo/'docs/CREATURES_0.16.json')
(repo/'docs/SHA256SUMS-0.16.1.txt').write_text('\n'.join(x['sha256']+'  livrables/'+x['file'] for x in result)+'\n')
print(json.dumps(result,indent=2))
