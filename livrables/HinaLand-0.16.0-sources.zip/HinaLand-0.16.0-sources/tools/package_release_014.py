"""Package verified 0.14 outputs without modifying retained user files in the delivery checkout."""
import pathlib,json,shutil,zipfile,hashlib,struct
r=pathlib.Path(__file__).resolve().parents[1];repo=pathlib.Path('/workspace/ok');dest=repo/'livrables';dest.mkdir(exist_ok=True);audit=r/'audit-0.14'
log=(r/'tests-build-0.14-delivery.log').read_text();assert 'All 40 required tests passed' in log and 'BUILD SUCCESSFUL' in log
jar=r/'build/libs/hinaland-0.14.0.jar'
with zipfile.ZipFile(jar) as z:
 assert 'META-INF/mods.toml' in z.namelist();assert 'fr/hinaland/HinaLand.class' in z.namelist();assert not any(n.startswith('fr/hinaland/test/') for n in z.namelist())
 assert struct.unpack('>H',z.read('fr/hinaland/HinaLand.class')[6:8])[0]==61
 for m in json.loads((r/'expansion-minerals-0.14.json').read_text()):
  for name in ['helmet','chestplate','leggings','boots','pickaxe','sword','axe']:assert 'data/hinaland/recipes/'+m['material']+'_'+name+'.json' in z.namelist()
 for f in ['mario','sonic','omori','deltarune','genshin','overwatch','lethal']:assert 'data/hinaland/structures/'+f+'_nether_gateway.nbt' in z.namelist()
shutil.copy2(jar,dest/jar.name)
pack=r/'modpack-0.14.0';pack.mkdir(exist_ok=True)
for section in ['mods','config','resourcepacks']:shutil.copytree(r/'modpack-0.13.0'/section,pack/section,dirs_exist_ok=True)
for p in (pack/'mods').glob('hinaland-*.jar'):p.unlink()
shutil.copy2(jar,pack/'mods'/jar.name);assert len(list((pack/'mods').glob('*.jar')))==22
for p in (r/'modpack-0.13.0').glob('*.md'):shutil.copy2(p,pack/p.name)
shutil.copy2(r/'RAPPORT_PEAUFINAGE_0.14_FR.md',pack/'RAPPORT_PEAUFINAGE_0.14_FR.md')
(pack/'INSTALLATION_FR.md').write_text('''# Hina Land — modpack de test 8 / 0.14.0

Minecraft Java 1.20.1, Forge 47.3.0 et Java 17. Copier `mods`, `config` et `resourcepacks` dans une instance dédiée. Activer HinaLand-integration-textures. GeckoLib et TerraBlender sont inclus. Ne pas garder un autre JAR Hina Land dans cette instance.

Avec une sauvegarde Normal 0.13, conserver une copie puis explorer de nouveaux chunks pour les nouveaux minerais et constructions. Une copie 0.13 a été testée ; pour des versions antérieures, un nouveau monde Normal reste la solution contrôlée. Les ruines déjà enregistrées restent inchangées.

Lire RAPPORT_PEAUFINAGE_0.14_FR.md pour les 40 tests, les observations en client et les limites. Le compagnon de quêtes peut dupliquer des chapitres au redémarrage. Lunaria Media n’est pas inclus et trois succès liés restent indisponibles.
''')
selected=['assets.log','equipment-assets.json','minerals-natural.json','upgrade-0.13.json','natural-landmarks.json','final-resource-comparison.json','server-pre-final.log','server-portal-food.log','server-release.log','server-upgrade-0.13.log','client-release.log','goomba-sprout-shipped.png','sonic-omori-models-first.png','delta-omochao-first.png','lethal-tall-models.png','lethal-small-models.png','ghost-model.png','equipment-final.png','delta-armor-and-poses.png','mario-grounded-poses.png','question-block-before.png','mario-bonus-garden-natural.png','portal-natural-frame.png','nether-portal-arrival.png','landmarks-final-flowers.png']
(pack/'audit').mkdir(exist_ok=True)
for name in selected:
 p=audit/name
 if p.exists():shutil.copy2(p,pack/'audit'/name)
for p,name in [(r/'tests-build-0.14-delivery.log','gametests-build.log'),(r/'build-0.14-release.log','build.log'),(r/'expansion-minerals-0.14.json','mineral-manifest.json'),(r/'polished-structures-0.14.json','structure-manifest.json'),(r/'mineral-sites-0.14.json','mineral-sites.json')]:shutil.copy2(p,pack/'audit'/name)
for p in [pathlib.Path('/workspace/hina-lethal-server/hinaland-worldgen-audit-overworld.csv'),pathlib.Path('/workspace/hina-upgrade-server/hinaland-worldgen-audit-overworld.csv')]:
 if p.exists():shutil.copy2(p,pack/'audit'/('upgrade-biomes.csv' if 'upgrade' in str(p) else 'biomes.csv'))
# Keep source provenance links and statuses, not downloaded publisher illustrations/web pages.
for name in ['fetch.json','game-renders.json','themed-game-art.json','more-references.json']:
 p=audit/'references'/name
 if p.exists():shutil.copy2(p,pack/'audit'/('references-'+name))
(pack/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(pack)) for p in sorted((pack/'mods').glob('*.jar')))+'\n')
def zipped(path,files,prefix):
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,relative in files:z.write(p,prefix+'/'+str(relative))
source_files=[]
for folder in ['src','gradle','tools','reference_worldgen']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':source_files.append((p,p.relative_to(r)))
for pattern in ['*.md','build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','CONTENT_MANIFEST.json','expansion-minerals-0.14.json','polished-structures-0.14.json','universe-minerals-0.12.json','lethal-maps-0.13.json','generation-revision-0.13.json']:
 for p in r.glob(pattern):source_files.append((p,p.name))
for name in ['mineral-manifest.json','structure-manifest.json','equipment-assets.json','minerals-natural.json','upgrade-0.13.json','natural-landmarks.json','final-resource-comparison.json']:
 p=pack/'audit'/name
 if p.exists():source_files.append((p,pathlib.Path('audit-0.14')/name))
zipped(dest/'HinaLand-0.14.0-sources.zip',source_files,'HinaLand-0.14.0-sources')
zipped(dest/'HinaLand-0.14.0-modpack-test-8.zip',[(p,p.relative_to(pack)) for p in pack.rglob('*') if p.is_file()],'HinaLand-0.14.0-modpack-test-8')
for p in dest.glob('*0.14.0*.zip'):
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
manifest=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [dest/jar.name,dest/'HinaLand-0.14.0-sources.zip',dest/'HinaLand-0.14.0-modpack-test-8.zip']]
(r/'deliverables-0.14.json').write_text(json.dumps(manifest,indent=2)+'\n');(repo/'docs').mkdir(exist_ok=True)
shutil.copy2(r/'RAPPORT_PEAUFINAGE_0.14_FR.md',repo/'docs/RAPPORT_PEAUFINAGE_0.14_FR.md')
shutil.copy2(r/'expansion-minerals-0.14.json',repo/'docs/MINERAIS_0.14.json');shutil.copy2(r/'polished-structures-0.14.json',repo/'docs/STRUCTURES_0.14.json')
(repo/'docs/SHA256SUMS-0.14.0.txt').write_text('\n'.join(x['sha256']+'  livrables/'+x['file'] for x in manifest)+'\n')
print(json.dumps(manifest,indent=2))
