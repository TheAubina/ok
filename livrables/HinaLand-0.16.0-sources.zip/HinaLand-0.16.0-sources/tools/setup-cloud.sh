#!/usr/bin/env bash
set -euo pipefail
task_tools=/workspace/tools
mkdir -p "$task_tools"
if [ ! -x "$task_tools/jdk-17.0.16+8/bin/java" ]; then
  curl -fsSL 'https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.16%2B8/OpenJDK17U-jdk_x64_linux_hotspot_17.0.16_8.tar.gz' -o "$task_tools/java17.tar.gz"
  curl -fsSL 'https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.16%2B8/OpenJDK17U-jdk_x64_linux_hotspot_17.0.16_8.tar.gz.sha256.txt' -o "$task_tools/java17.sha256"
  python3 - <<'PY'
import hashlib, pathlib, tarfile
p=pathlib.Path('/workspace/tools/java17.tar.gz')
assert hashlib.sha256(p.read_bytes()).hexdigest()==pathlib.Path('/workspace/tools/java17.sha256').read_text().split()[0]
with tarfile.open(p) as t: t.extractall('/workspace/tools',filter='data')
PY
fi
export JAVA_HOME="$task_tools/jdk-17.0.16+8"
export GRADLE_USER_HOME=/workspace/gradle-cache
export PATH="$JAVA_HOME/bin:$PATH"
mkdir -p "$GRADLE_USER_HOME"
python3 - <<'PY'
import os, pathlib, urllib.parse
p=pathlib.Path('/workspace/gradle-cache/gradle.properties')
lines=p.read_text().splitlines() if p.exists() else []
updates={}
u=urllib.parse.urlsplit(os.environ.get('HTTPS_PROXY',''))
if u.hostname:
    for protocol in ('http','https'):
        updates[f'systemProp.{protocol}.proxyHost']=u.hostname
        updates[f'systemProp.{protocol}.proxyPort']=str(u.port or 80)
trust=pathlib.Path('/etc/ssl/certs/java/cacerts')
if trust.is_file(): updates['systemProp.javax.net.ssl.trustStore']=str(trust)
lines=[l for l in lines if l.split('=',1)[0] not in updates]
p.write_text('\n'.join(lines+[k+'='+v for k,v in updates.items()])+'\n')
PY
cd /workspace/hinaland
test -f src/main/java/fr/hinaland/HinaLand.java
./gradlew build --max-workers=2 --console=plain
python3 tools/check_assets.py

