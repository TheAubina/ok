import urllib.request,urllib.parse,json,pathlib,concurrent.futures,xml.etree.ElementTree as ET
r=pathlib.Path(__file__).resolve().parents[1]/'audit-0.14/references'
queries={'motobug':'Motobug Sonic official render image','buzz_bomber':'Buzz Bomber Sonic official render image','sprout_mole':'OMORI Sprout Mole neutral official sprite'}
def f(row):
 name,q=row;u='https://www.bing.com/search?format=rss&q='+urllib.parse.quote(q)
 try:
  req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=20) as resp:body=resp.read()
  (r/(name+'-search.xml')).write_bytes(body);doc=ET.fromstring(body);return {'mob':name,'results':[{'title':x.findtext('title'),'url':x.findtext('link'),'description':x.findtext('description')} for x in doc.findall('.//item')[:6]]}
 except Exception as e:return {'mob':name,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:out=list(p.map(f,queries.items()))
(r/'reference-search-results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
