"""Fetch specific game sprites referenced by the audited wiki pages; preserve pixels through GIF/PNG codec conversion."""
from pathlib import Path
import re,html,urllib.request,urllib.parse,json,concurrent.futures
from PIL import Image
r=Path(__file__).resolve().parents[1];ref=r/'audit-0.16/references';dest=r/'research/creatures-0.16';dest.mkdir(parents=True,exist_ok=True)
names={'lost_sprout_mole':('omori','Lost_Sprout_Mole'),'harold':('omori','Harold'),'marsha':('omori','Marsha'),'space_bunny':('omori','Space_Bunny'),'something':('omori','SOMETHING_SPRITE'),'jigsawry':('deltarune','Jigsawry'),'rabbick':('deltarune','Rabbick'),'clover':('deltarune','Clover'),'tasque':('deltarune','Tasque'),'werewire':('deltarune','Werewire'),'virovirokun':('deltarune','Virovirokun')}
def fetch(pair):
 id,(family,name)=pair;s=(ref/(id+'.html')).read_text();urls=re.findall(r'<img[^>]+src="([^"]+)"',s);candidates=[u for u in urls if name in u and '/thumb/' not in u and (('neutral' in u) if family=='omori' and id!='something' else ('battle' in u))]
 if id=='something':candidates=['/images/5/58/SOMETHING_SPRITE.png']
 if not candidates:raise RuntimeError((id,'No identified original sprite'))
 u=html.unescape(candidates[0]);url=urllib.parse.urljoin('https://omori.wiki/' if family=='omori' else 'https://deltarune.wiki/',u)
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=25) as q:b=q.read()
 original=dest/(id+('.gif' if '.gif' in u else '.png'));original.write_bytes(b);im=Image.open(original);im.seek(0);frame=im.convert('RGBA');frame.save(dest/(id+'.png'))
 return {'id':id,'url':url,'frame':0,'width':frame.width,'height':frame.height,'frame_count':getattr(im,'n_frames',1),'conversion':'PNG codec only; original frame pixels unchanged'}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:rows=list(pool.map(fetch,names.items()))
(ref/'sprites.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
