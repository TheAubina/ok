from pathlib import Path
import sys,struct,zlib,io,collections
sys.path.insert(0,"/workspace/tools/pythonlibs")
import nbtlib

def chunks(world):
 for f in (Path(world)/"region").glob("r.*.*.mca"):
  raw=f.read_bytes()
  for i in range(1024):
   entry=int.from_bytes(raw[i*4:i*4+4],"big");offset=(entry>>8)*4096
   if not offset:continue
   length=int.from_bytes(raw[offset:offset+4],"big");kind=raw[offset+4];data=raw[offset+5:offset+4+length]
   if kind==2:data=zlib.decompress(data)
   elif kind==1:
    import gzip
    data=gzip.decompress(data)
   elif kind!=3:continue
   yield nbtlib.File.parse(io.BytesIO(data))

def audit(world):
 result=collections.defaultdict(collections.Counter);count=collections.Counter()
 for n in chunks(world):
  if str(n.get("Status")) not in {"minecraft:full","full"}:continue
  keys=set()
  for sec in n.get("sections",[]):
   keys.update(str(x) for x in sec.get("biomes",{}).get("palette",[]))
  for key in keys:
   if key.startswith("hinaland:"):
    count[key]+=1
    for sec in n.get("sections",[]):
     for state in sec.get("block_states",{}).get("palette",[]):result[key][str(state["Name"])]+=1
 for key in sorted(result):print(key,"chunks",count[key],"themed states",dict((k,v) for k,v in sorted(result[key].items()) if k.startswith("hinaland:")))
if __name__=="__main__":audit(sys.argv[1])
