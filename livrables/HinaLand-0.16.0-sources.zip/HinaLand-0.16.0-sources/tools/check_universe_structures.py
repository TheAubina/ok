"""Validate authored NBT bounds, structure/block/loot references, distinct designs and dungeon policy."""
import pathlib,json,sys,hashlib,collections
sys.path.insert(0,'/workspace/tools/pythonlibs');import nbtlib
r=pathlib.Path(__file__).resolve().parents[1];d=r/'src/main/resources/data/hinaland';a=r/'src/main/resources/assets/hinaland'
m=json.loads((r/'universe-structures-0.15.json').read_text());counts=collections.Counter();hashes=set()
for row in m['structures']:
 name=row['structure'];counts[row['family']]+=1;t=nbtlib.load(d/f'structures/{name}.nbt');size=list(map(int,t['size']));palette=t['palette'];positions=set()
 for b in t['blocks']:
  pos=tuple(map(int,b['pos']));assert pos not in positions;positions.add(pos);assert all(0<=pos[i]<size[i] for i in range(3)),(name,pos,size)
  state=palette[int(b['state'])];block=str(state['Name'])
  if block.startswith('hinaland:'):assert (a/'blockstates'/f'{block.split(":")[1]}.json').exists(),(name,block)
  if 'nbt' in b and 'LootTable' in b['nbt']:assert (d/'loot_tables'/f'{str(b["nbt"]["LootTable"]).split(":")[1]}.json').exists()
 assert row['geometry_sha256'] not in hashes;hashes.add(row['geometry_sha256'])
 obj=json.loads((d/f'worldgen/structure/{name}.json').read_text());assert obj['type']=='hinaland:grounded' and obj['max_slope']==4
 if row['family']=='lethal':assert not row['dungeon'] and not row['spawners'];assert not any(str(s['Name'])=='minecraft:spawner' for s in palette)
 assert len(row['chests'])==1 and len(row['spawners'])==int(row['dungeon'])
assert set(counts.values())=={10} and len(counts)==7
sets=[json.loads(p.read_text()) for p in (d/'worldgen/structure_set').glob('*.json')];assert len(sets)==7 and sum(len(x['structures']) for x in sets)==91
for s in sets:assert s['placement']=={'type':'minecraft:random_spread','spacing':48,'separation':24,'salt':137130,'frequency':.65}
result={'new_structures':70,'new_per_family':dict(counts),'total_natural':91,'unique_geometry_hashes':len(hashes),'dungeons':sum(x['dungeon'] for x in m['structures']),'lethal_new_dungeons':0,'validated':'NBT bounds, custom block references, loot references, grounded codecs and shared sparse grids'}
(r/'audit-0.15/structure-assets.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
