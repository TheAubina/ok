"""Download community-hosted original game art for visual comparison; never label wiki pages official."""
import pathlib,urllib.request,urllib.parse,json,concurrent.futures
from html.parser import HTMLParser
r=pathlib.Path(__file__).resolve().parents[1];out=r/'audit-0.14/references'
rows=[('goomba','https://www.mariowiki.com/Goomba'),('koopa','https://www.mariowiki.com/Koopa_Troopa'),('dry_bones','https://www.mariowiki.com/Dry_Bones'),('pokey','https://www.mariowiki.com/Pokey'),('motobug','https://sonicwiki.org/wiki/Motobug'),('buzz_bomber','https://sonicwiki.org/wiki/Buzz_Bomber'),('omochao','https://sonicwiki.org/wiki/Omochao'),('sprout_mole','https://omori.wiki/Sprout_Mole'),('forest_bunny','https://omori.wiki/Forest_Bunny')]
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.images=[]
 def handle_starttag(self,t,a):
  attrs=dict(a)
  if t=='img' and attrs.get('src') and not any(x in attrs['src'] for x in ['logo','icon','Icon','Flag','flag']):self.images.append(attrs)
def request(url):
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=25) as f:return f.read(),f.url,f.headers.get('Content-Type')
def fetch(row):
 name,url=row;result={'mob':name,'reference_page':url,'provenance':'Community page hosting game art; publisher origin must be distinguished from wiki host'}
 try:
  body,final,ct=request(url);(out/(name+'-page.html')).write_bytes(body);p=Parser();p.feed(body.decode('utf8',errors='replace'));result['candidate_images']=p.images[:8]
  if p.images:
   image_url=urllib.parse.urljoin(final,p.images[0]['src']);im,_,mime=request(image_url);suffix='.gif' if 'gif' in mime else '.webp' if 'webp' in mime else '.png';(out/(name+'-game'+suffix)).write_bytes(im);result.update(image_url=image_url,image_bytes=len(im))
 except Exception as e:result['error']=str(e)
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as p:results=list(p.map(fetch,rows))
(out/'themed-game-art.json').write_text(json.dumps(results,indent=2));print(json.dumps([{k:v for k,v in row.items() if k!='candidate_images'} for row in results],indent=2))
