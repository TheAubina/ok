"""Validate worn-armour UV layout and sprite-sheet metadata for all new materials."""
import json,pathlib
from PIL import Image
r=pathlib.Path(__file__).resolve().parents[1];a=r/'src/main/resources/assets/hinaland';manifest=json.loads((r/'expansion-minerals-0.14.json').read_text());armors=0;animated=[]
for m in manifest:
 for layer in [1,2]:
  p=a/f'textures/models/armor/{m["material"]}_layer_{layer}.png';w,h=Image.open(p).size;assert w==h*2,(p,w,h);armors+=1
for p in (a/'textures').rglob('*.png.mcmeta'):
 if not any(m['material'] in p.name for m in manifest):continue
 obj=json.loads(p.read_text());anim=obj.get('animation')
 if not anim:continue
 image=p.with_suffix('');w,h=Image.open(image).size;fw=anim.get('width',min(w,h));fh=anim.get('height',min(w,h));assert w%fw==0 and h%fh==0,(p,w,h,fw,fh);n=(w//fw)*(h//fh)
 for frame in anim.get('frames',list(range(n))):
  i=frame.get('index') if isinstance(frame,dict) else frame;assert 0<=i<n,(p,i,n)
 animated.append({'texture':str(image.relative_to(a)),'frames_available':n,'width':fw,'height':fh})
out={'armor_layers':armors,'materials':len(manifest),'animated_textures':animated};(r/'audit-0.14/equipment-assets.json').write_text(json.dumps(out,indent=2));print(f'{armors} valid worn-armour layers; {len(animated)} sprite animations preserved')
