"""Inspect saved FULL chunks at audit sites; requires nbtlib (pip install nbtlib)."""
from pathlib import Path
import sys,json,collections
from read_region import chunks
world=Path(sys.argv[1]);sites=json.loads(Path(sys.argv[2]).read_text())
wanted={(x//16,z//16):key for key,(x,z) in sites.items()};out={}
for n in chunks(world):
 pos=(int(n.get('xPos',0)),int(n.get('zPos',0)))
 if pos not in wanted or str(n.get('Status')) not in {'minecraft:full','full'}:continue
 c=collections.Counter();deep=collections.Counter();column=collections.Counter();actual=None
 for section in n.get('sections',[]):
  if int(section['Y'])==5:
   b=section['biomes'];palette=b['palette'];bits=max(1,(len(palette)-1).bit_length());index=(int(b.get('data',[0])[0])&((1<<bits)-1)) if len(palette)>1 else 0;actual=str(palette[index])
  bs=section.get('block_states',{});palette=[str(x['Name']) for x in bs.get('palette',[])];data=bs.get('data',[])
  if not palette:continue
  if len(palette)==1:
   c[palette[0]]+=4096
   if int(section['Y'])<0:deep[palette[0]]+=4096;column[palette[0]]+=16
   continue
  bits=max(4,(len(palette)-1).bit_length());per=64//bits;mask=(1<<bits)-1
  for index in range(4096):
   packed=int(data[index//per])&((1<<64)-1);state=(packed>>((index%per)*bits))&mask;c[palette[state]]+=1
   if int(section['Y'])<0:
    deep[palette[state]]+=1
    if index%256==0:column[palette[state]]+=1
 key=wanted[pos];assert actual==key,(key,actual);out[key]={'chunk':pos,'biome_at_y80':actual,'blocks':dict(sorted(c.items())),'below_y0':dict(sorted(deep.items())),'center_column_below_y0':dict(sorted(column.items()))}
for key,report in out.items():
 family=key.split(':')[1].split('_')[0];c=report['blocks'];assert c.get('hinaland:'+family+'_stone',0)>0,key
 assert report['below_y0'].get('hinaland:'+family+'_stone',0)>0,key
 assert report['below_y0'].get('hinaland:'+family+'_bedrock',0)>0,key
 assert report['center_column_below_y0'].get('minecraft:deepslate',0)==0,key
 if key.endswith('_forest'):assert c.get('hinaland:'+family+'_oak_log',0)>0 and c.get('hinaland:'+family+'_oak_leaves',0)>0,key
 if key.endswith('_dunes'):assert c.get('hinaland:'+family+'_sand',0)>0 and c.get('hinaland:'+family+'_sandstone',0)>0,key
assert len(out)==len(sites),(len(out),len(sites),set(sites)-set(out))
Path(sys.argv[3]).write_text(json.dumps(out,indent=2));print('Validated',len(out),'natural biome sites, themed rock everywhere, trees in forests, sand/sandstone in dunes')
