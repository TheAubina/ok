"""Generate the 0.13 exclusive Overworld, dry fractured Nether, curated structures and spawn tables."""
import json,pathlib
root=pathlib.Path(__file__).resolve().parents[1];data=root/'src/main/resources/data';hd=data/'hinaland'
families=['mario','sonic','omori','deltarune','genshin','overwatch','lethal'];variants=['','_forest','_highlands','_dunes']
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
biomes=['hinaland:'+f+v for f in families for v in variants]
write(data/'minecraft/dimension/overworld.json',{'type':'minecraft:overworld','generator':{'type':'minecraft:noise','settings':'hinaland:exclusive_overworld','biome_source':{'type':'hinaland:exclusive_overworld','biomes':biomes}}})
noise=json.loads((root/'reference_worldgen/worldgen_noise_settings_overworld.json').read_text())
def state(block):return {'type':'minecraft:block','result_state':{'Name':block}}
def condition(test,rule):return {'type':'minecraft:condition','if_true':test,'then_run':rule}
def seq(*rules):return {'type':'minecraft:sequence','sequence':list(rules)}
floor={'type':'minecraft:stone_depth','add_surface_depth':False,'offset':0,'secondary_depth_range':0,'surface_type':'floor'}
underfloor={'type':'minecraft:stone_depth','add_surface_depth':True,'offset':0,'secondary_depth_range':0,'surface_type':'floor'}
bedrock=condition({'type':'minecraft:vertical_gradient','random_name':'hinaland:bedrock_floor','true_at_and_below':{'above_bottom':0},'false_at_and_above':{'above_bottom':5}},None)
rules=[]
for f in families:
 for v in variants:
  top=state('hinaland:'+f+('_sand' if v=='_dunes' else '_soil'))
  if v=='_highlands':top=seq(condition({'type':'minecraft:y_above','anchor':{'absolute':120},'surface_depth_multiplier':0,'add_stone_depth':False},state('hinaland:'+f+'_snow')),condition({'type':'minecraft:steep'},state('hinaland:'+f+'_stone')),top)
  water=condition({'type':'minecraft:not','invert':{'type':'minecraft:water','offset':-1,'surface_depth_multiplier':0,'add_stone_depth':False}},state('hinaland:'+f+'_sand'))
  b=dict(bedrock);b['then_run']=state('hinaland:'+f+'_bedrock')
  rules.append(condition({'type':'minecraft:biome','biome_is':['hinaland:'+f+v]},seq(b,condition({'type':'minecraft:above_preliminary_surface'},seq(condition(floor,seq(water,top)),condition(underfloor,state('hinaland:'+f+('_sandstone' if v=='_dunes' else '_dirt'))))),state('hinaland:'+f+'_stone'))))
noise['surface_rule']=seq(*rules,state('minecraft:stone'));write(hd/'worldgen/noise_settings/exclusive_overworld.json',noise)
# Keep the same 63 biomes, sample their climates six times faster, and prevent sea-level surface flooding.
p=hd/'worldgen/noise_settings/mixed_nether.json';nether=json.loads(p.read_text());nether.update(sea_level=0,aquifers_enabled=False);write(p,nether)
p=data/'minecraft/dimension/the_nether.json';dim=json.loads(p.read_text());dim['generator']['biome_source'].update(type='hinaland:fractured_nether',coordinate_scale=6);write(p,dim)
# Admit one coherent construction from a family per shared grid, rather than 32 independent grids.
curated={'mario':['mario_tuyau_blocs','mario_chateau'],'sonic':['sonic_master_emerald'],'omori':['omori_jardin'],'genshin':['genshin_pavillon','genshin_statue'],'overwatch':['overwatch_point'],'lethal':['lethal_company_batiment']}
structuresets=hd/'worldgen/structure_set'
for p in structuresets.glob('*.json'):p.unlink()
for i,(f,names) in enumerate(curated.items()):
 entries=[]
 for name in names:
  write(hd/f'worldgen/structure/{name}.json',{'type':'hinaland:grounded','biomes':'#hinaland:has_structure/'+name,'step':'surface_structures','spawn_overrides':{},'terrain_adaptation':'none','template':'hinaland:'+name,'max_slope':4})
  # Builds belong to plains/forests; no prefabricated castles on dunes or steep highlands.
  write(hd/f'tags/worldgen/biome/has_structure/{name}.json',{'values':['hinaland:'+f,'hinaland:'+f+'_forest']})
  entries.append({'structure':'hinaland:'+name,'weight':1})
 # Each family uses the SAME placement salt: a given grid location can only select its own family.
 write(structuresets/f'{f}_settlements.json',{'structures':entries,'placement':{'type':'minecraft:random_spread','spacing':48,'separation':24,'salt':137130,'frequency':0.65}})
for f in families:
 for v in variants:
  p=hd/f'worldgen/biome/{f}{v}.json';b=json.loads(p.read_text());b['features'][4]=[x for x in b['features'][4] if not x.endswith('_facility')]
  creatures=[s for s in b['spawners']['creature'] if s['type'].startswith('hinaland:')]
  if v!='_dunes':creatures += [{'type':'minecraft:'+mob,'weight':weight,'minCount':2,'maxCount':4} for mob,weight in [('sheep',12),('pig',10),('chicken',10),('cow',8)]]
  b['spawners']['creature']=creatures
  if f in ['genshin','overwatch']:
   b['spawners']['monster']=[{'type':'minecraft:'+mob,'weight':weight,'minCount':1,'maxCount':3} for mob,weight in [('zombie',45),('skeleton',40),('spider',35)]]
  write(p,b)
for p in (hd/'worldgen/placed_feature').glob('*trees*.json'):
 d=json.loads(p.read_text());mod={'type':'hinaland:structure_tree_clearance'}
 if mod not in d['placement']:d['placement'].append(mod)
 write(p,d)
p=data/'minecraft/tags/blocks/animals_spawnable_on.json';d=json.loads(p.read_text()) if p.exists() else {'replace':False,'values':[]};d['values']=list(dict.fromkeys(d['values']+['hinaland:'+f+'_soil' for f in families]));write(p,d)
# Keep underground strongholds/mineshafts, but remove unrelated vanilla settlements from Hina biomes.
write(data/'minecraft/tags/worldgen/biome/has_structure/village_plains.json',{'replace':False,'values':[]})
write(root/'generation-revision-0.13.json',{'overworld_biomes':biomes,'nether_scale':6,'nether_sea_level':0,'nether_aquifers':False,'natural_structures':[n for ns in curated.values() for n in ns],'removed_natural_templates':24,'spacing':48,'separation':24,'frequency':0.65,'max_slope':4})
print('Exclusive 28-biome Overworld; dry 6x-fractured Nether; 8 curated ground-checked structures in 6 shared grids; animal habitat fixes')
