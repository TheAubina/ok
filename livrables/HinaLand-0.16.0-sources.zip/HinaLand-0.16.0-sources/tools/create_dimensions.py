from pathlib import Path
import json,copy
R=Path(__file__).resolve().parents[1];data=R/'src/main/resources/data';hd=data/'hinaland';ref=R/'reference_worldgen'
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
ov=json.loads((ref/'dimension_type_overworld.json').read_text());mix=copy.deepcopy(ov);mix.update(coordinate_scale=8.0,piglin_safe=True,respawn_anchor_works=True,has_raids=False)
write(hd/'dimension_type/mixed_nether.json',mix)
noise=json.loads((ref/'worldgen_noise_settings_overworld.json').read_text())
def surface(biomes,state):return {'type':'minecraft:condition','if_true':{'type':'minecraft:biome','biome_is':biomes},'then_run':{'type':'minecraft:block','result_state':{'Name':'minecraft:'+state}}}
nether=['nether_wastes','soul_sand_valley','crimson_forest','warped_forest','basalt_deltas'];end=['the_end','end_highlands','end_midlands','small_end_islands','end_barrens']
# Bedrock remains intact, then family-specific surface/underground host blocks.
def nylium(biome,block):
 return {'type':'minecraft:condition','if_true':{'type':'minecraft:biome','biome_is':['minecraft:'+biome]},'then_run':{'type':'minecraft:sequence','sequence':[{'type':'minecraft:condition','if_true':{'type':'minecraft:stone_depth','add_surface_depth':False,'offset':0,'secondary_depth_range':0,'surface_type':'floor'},'then_run':{'type':'minecraft:block','result_state':{'Name':'minecraft:'+block}}},{'type':'minecraft:block','result_state':{'Name':'minecraft:netherrack'}}]}}
rules=[nylium('crimson_forest','crimson_nylium'),nylium('warped_forest','warped_nylium'),surface(['minecraft:soul_sand_valley'],'soul_soil'),surface(['minecraft:basalt_deltas'],'basalt'),surface(['minecraft:'+n for n in nether],'netherrack'),surface(['minecraft:'+n for n in end],'end_stone'),noise['surface_rule']]
noise['surface_rule']={'type':'minecraft:sequence','sequence':[{'type':'minecraft:condition','if_true':{'type':'minecraft:vertical_gradient','random_name':'minecraft:bedrock_floor','true_at_and_below':{'above_bottom':0},'false_at_and_above':{'above_bottom':5}},'then_run':{'type':'minecraft:block','result_state':{'Name':'minecraft:bedrock'}}}]+rules}
write(hd/'worldgen/noise_settings/mixed_nether.json',noise)
overworld='badlands bamboo_jungle beach birch_forest cherry_grove cold_ocean dark_forest deep_cold_ocean deep_dark deep_frozen_ocean deep_lukewarm_ocean deep_ocean desert dripstone_caves eroded_badlands flower_forest forest frozen_ocean frozen_peaks frozen_river grove ice_spikes jagged_peaks jungle lukewarm_ocean lush_caves mangrove_swamp meadow mushroom_fields ocean old_growth_birch_forest old_growth_pine_taiga old_growth_spruce_taiga plains river savanna savanna_plateau snowy_beach snowy_plains snowy_slopes snowy_taiga sparse_jungle stony_peaks stony_shore sunflower_plains swamp taiga warm_ocean windswept_forest windswept_gravelly_hills windswept_hills windswept_savanna wooded_badlands'.split()
def params(t,h,c,e,d=[-1,1],w=[-1,1]):return {'temperature':t,'humidity':h,'continentalness':c,'erosion':e,'depth':d,'weirdness':w,'offset':0}
entries=[]
for family,erosion in [(nether,-0.7),(end,0.7)]:
 for i,n in enumerate(family):entries.append({'biome':'minecraft:'+n,'parameters':params(-1+i*.5,[-1,1],[-1,1],erosion)})
# The Overworld biome set is distributed on an explicit 2D climate grid.
for i,n in enumerate(overworld):
 c=-0.8 if 'ocean' in n else -0.45 if n in ['river','frozen_river','beach','snowy_beach','stony_shore'] else 0.3
 entries.append({'biome':'minecraft:'+n,'parameters':params(-.9+(i%8)*.257,-.9+(i//8)*.3,c,0)})
write(data/'minecraft/dimension/the_nether.json',{'type':'hinaland:mixed_nether','generator':{'type':'minecraft:noise','settings':'hinaland:mixed_nether','biome_source':{'type':'minecraft:multi_noise','biomes':entries}}})
print('Mixed Nether;',len(entries),'vanilla biomes (void excluded)')
