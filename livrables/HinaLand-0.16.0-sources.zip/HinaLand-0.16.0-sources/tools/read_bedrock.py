from pathlib import Path
import sys,io,struct,collections,json
sys.path[:0]=['/workspace/tools/bedrocklibs','/workspace/tools/pythonlibs']
import leveldb,nbtlib,numpy as np
ROOT=Path('/workspace/hinaland/imported-lethal-worlds/Lethal Company Add-on Test')
def blocks():
 db=leveldb.LevelDB(str(ROOT/'db'))
 try:
  for k,v in db.iterate():
   if len(k)!=10 or k[8]!=47:continue
   x,z=struct.unpack('<ii',k[:8]);st=io.BytesIO(v);version=st.read(1)[0];layers=st.read(1)[0] if version>=8 else 1;y=struct.unpack('b',st.read(1))[0] if version==9 else struct.unpack('b',k[9:])[0]
   for layer in range(layers):
    header=st.read(1)[0];bits=header>>1
    if bits:
     per=32//bits;words=np.frombuffer(st.read(((4096+per-1)//per)*4),dtype='<u4');indices=((words[:,None]>>np.arange(per,dtype=np.uint32)*bits)&((1<<bits)-1)).reshape(-1)[:4096];count=struct.unpack('<i',st.read(4))[0]
    else:indices=np.zeros(4096,dtype=np.uint8);count=1
    palette=[nbtlib.File.parse(st,byteorder='little') for _ in range(count)]
    if layer:continue
    for pi,state in enumerate(palette):
     name=str(state['name'])
     if name in {'minecraft:air','minecraft:dirt','minecraft:grass','minecraft:bedrock'}:continue
     for i in np.nonzero(indices==pi)[0]:yield (x*16+(int(i)>>8),y*16+(int(i)&15),z*16+((int(i)>>4)&15)),state
 finally:db.close()
if __name__=='__main__':
 data=[];counts=collections.Counter();box={}
 for pos,s in blocks():
  name=str(s['name']);counts[name]+=1;data.append([list(pos),name,{k:v.unpack() for k,v in s['states'].items()}]);b=box.setdefault(name,[list(pos),list(pos)])
  for j in range(3):b[0][j]=min(b[0][j],pos[j]);b[1][j]=max(b[1][j],pos[j])
 Path('/workspace/hinaland/bedrock-blocks.json').write_text(json.dumps(data));print(json.dumps({'counts':counts,'bounds':box},indent=2))
