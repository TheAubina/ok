"""Validate the shipped resources independently of Minecraft rendering."""
import json,pathlib,struct,sys
root=pathlib.Path(__file__).resolve().parents[1]/'src/main/resources';a=root/'assets/hinaland'
errors=[];count=0
atlas_prefixes=['block/','item/']
atlas=root/'assets/minecraft/atlases/blocks.json'
if atlas.exists():atlas_prefixes.extend(x.get('prefix','') for x in json.loads(atlas.read_text()).get('sources',[]) if x.get('type')=='minecraft:directory')
for p in root.rglob('*.json'):
 try:json.loads(p.read_text());count+=1
 except Exception as ex:errors.append(f'{p.relative_to(root)}: {ex}')
for p in (a/'models').rglob('*.json'):
 d=json.loads(p.read_text())
 for v in d.get('textures',{}).values():
  if v.startswith('hinaland:'):
   path=v.split(':',1)[1]
   if not (a/'textures'/f'{path}.png').exists():errors.append(f'Missing texture {v} in {p.name}')
   if not any(path.startswith(prefix) for prefix in atlas_prefixes):errors.append(f'Texture absent from blocks atlas {v} in {p.name}')
for p in (a/'geo').glob('*.json'):
 d=json.loads(p.read_text())['minecraft:geometry'][0];bones=d['bones'];names=[b['name'] for b in bones]
 if len(names)!=len(set(names)):errors.append(f'Duplicate bones {p.name}')
 for b in bones:
  if 'parent' in b and b['parent'] not in names:errors.append(f'Missing parent {p.name}:{b["name"]}')
 anim=a/'animations'/p.name.replace('.geo.','.animation.')
 for name,v in json.loads(anim.read_text())['animations'].items():
  if set(v.get('bones',{}))-set(names):errors.append(f'Unknown animation bones {name}')
 folder='lethal' if p.stem.replace('.geo','') in ['bracken','coil_head','hoarding_bug','barber','bunker_spider','ghost_girl','nutcracker'] else 'biome'
 texture=a/'textures/entity'/folder/p.name.replace('.geo.json','.png')
 w,h=struct.unpack('>II',texture.read_bytes()[16:24]);desc=d['description']
 if (w,h)!=(desc['texture_width'],desc['texture_height']):errors.append(f'Texture dimensions {texture.name}: {w}x{h} versus model {desc["texture_width"]}x{desc["texture_height"]}')
print(f'{count} JSON files parsed; {len(list((a/"geo").glob("*.json")))} models and animation hierarchies checked')
for e in errors:print(e)
sys.exit(bool(errors))
