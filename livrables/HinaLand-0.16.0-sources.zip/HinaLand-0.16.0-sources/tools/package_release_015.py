"""Package the tested 0.15 JAR, generated sources and clean 22-mod pack."""
import pathlib,json,shutil,zipfile,hashlib,struct
r=pathlib.Path(__file__).resolve().parents[1];repo=pathlib.Path('/workspace/ok');dest=repo/'livrables';audit=r/'audit-0.15';jar=r/'build/libs/hinaland-0.15.0.jar'
log=(r/'tests-build-0.15.log').read_text();assert 'All 49 required tests passed' in log and 'BUILD SUCCESSFUL' in log
manifest=json.loads((r/'universe-structures-0.15.json').read_text());assert len(manifest['structures'])==70
proof=json.loads((audit/'production-interactions.json').read_text());assert proof['jar_sha256']==hashlib.sha256(jar.read_bytes()).hexdigest()
with zipfile.ZipFile(jar) as z:
 assert z.testzip() is None and 'META-INF/mods.toml' in z.namelist()
 assert struct.unpack('>H',z.read('fr/hinaland/HinaLand.class')[6:8])[0]==61
 assert not any(x.startswith('fr/hinaland/test/') for x in z.namelist()) and 'data/hinaland/structures/test_empty.nbt' not in z.namelist()
 for row in manifest['structures']:assert 'data/hinaland/structures/'+row['structure']+'.nbt' in z.namelist()
 sets=[json.loads(z.read(x)) for x in z.namelist() if x.startswith('data/hinaland/worldgen/structure_set/') and x.endswith('.json')]
 assert len(sets)==7 and sum(len(x['structures']) for x in sets)==91
shutil.copy2(jar,dest/jar.name)
pack=r/'modpack-0.15.0';pack.mkdir(exist_ok=True)
for name in ['mods','config','resourcepacks']:shutil.copytree(r/'modpack-0.14.0'/name,pack/name,dirs_exist_ok=True)
for old in (pack/'mods').glob('hinaland-*.jar'):old.unlink()
shutil.copy2(jar,pack/'mods'/jar.name);assert len(list((pack/'mods').glob('*.jar')))==22
for p in (r/'modpack-0.14.0').glob('*.md'):shutil.copy2(p,pack/p.name)
for name in ['RAPPORT_STRUCTURES_0.15_FR.md','CATALOGUE_STRUCTURES_0.15_FR.md']:shutil.copy2(r/name,pack/name)
(pack/'INSTALLATION_FR.md').write_text('''# Hina Land — 0.15.0 / modpack de test 9

Minecraft Java 1.20.1, Forge 47.3.0, Java 17. Copier les dossiers mods, config et resourcepacks dans une instance dédiée. GeckoLib et TerraBlender sont inclus. Ne pas installer plusieurs versions de Hina Land. Activer HinaLand-integration-textures.

70 constructions nouvelles, dix par chacun des sept univers de l’Overworld, dont douze petits donjons hors Lethal. Les 21 anciennes constructions sont conservées. Explorer de nouveaux chunks : les bâtiments déjà enregistrés ne sont pas reconstruits. Conserver une sauvegarde avant la mise à jour.

Lire RAPPORT_STRUCTURES_0.15_FR.md et CATALOGUE_STRUCTURES_0.15_FR.md : 49 tests Forge, huit exemples générés naturellement, limites et inspirations. Le compagnon de quêtes peut dupliquer des chapitres au redémarrage ; Lunaria Media n’est pas inclus.
''')
pa=pack/'audit/0.15';pa.mkdir(parents=True,exist_ok=True)
selected=['assets.log','equipment-assets.log','structure-assets.json','natural-structures.json','production-interactions.json','server-production.log','client-production.log','mario-gate-natural-final.png','sonic-shelter-natural-final.png','omori-camp-natural.png','delta-crossing-natural.png','genshin-camp-natural.png','overwatch-tower-natural.png','lethal-dock-natural.png','mario-pyramid-natural.png','mario-dungeon-chest.png']
for name in selected:assert (audit/name).exists(),name;shutil.copy2(audit/name,pa/name)
shutil.copy2(r/'tests-build-0.15.log',pa/'gametests-build.log');shutil.copy2(r/'universe-structures-0.15.json',pa/'structure-manifest.json');shutil.copy2('/workspace/hina-lethal-server/hinaland-worldgen-audit-overworld.csv',pa/'biomes.csv')
# Retain the previous verification records without the runtime server's duplicated quest configuration.
shutil.copytree(r/'modpack-0.14.0/audit',pack/'audit/previous-0.14',dirs_exist_ok=True)
(pack/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(pack)) for p in sorted((pack/'mods').glob('*.jar')))+'\n')
def zipped(path,files,prefix):
 seen=set()
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,rel in files:
   name=prefix+'/'+str(rel)
   if name not in seen:z.write(p,name);seen.add(name)
source=[]
for folder in ['src','gradle','tools','reference_worldgen']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':source.append((p,p.relative_to(r)))
for pattern in ['*.md','build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','CONTENT_MANIFEST.json','expansion-minerals-0.14.json','polished-structures-0.14.json','universe-structures-0.15.json','universe-minerals-0.12.json','lethal-maps-0.13.json','generation-revision-0.13.json']:
 for p in r.glob(pattern):source.append((p,p.name))
for name in ['structure-assets.json','natural-structures.json','production-interactions.json']:source.append((audit/name,pathlib.Path('audit-0.15')/name))
zipped(dest/'HinaLand-0.15.0-sources.zip',source,'HinaLand-0.15.0-sources')
zipped(dest/'HinaLand-0.15.0-modpack-test-9.zip',[(p,p.relative_to(pack)) for p in pack.rglob('*') if p.is_file()],'HinaLand-0.15.0-modpack-test-9')
files=[dest/jar.name,dest/'HinaLand-0.15.0-sources.zip',dest/'HinaLand-0.15.0-modpack-test-9.zip'];result=[]
for p in files:
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
 result.append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(r/'deliverables-0.15.json').write_text(json.dumps(result,indent=2)+'\n')
for name in ['RAPPORT_STRUCTURES_0.15_FR.md','CATALOGUE_STRUCTURES_0.15_FR.md']:shutil.copy2(r/name,repo/'docs'/name)
shutil.copy2(r/'universe-structures-0.15.json',repo/'docs/STRUCTURES_0.15.json')
(repo/'docs/SHA256SUMS-0.15.0.txt').write_text('\n'.join(x['sha256']+'  livrables/'+x['file'] for x in result)+'\n')
print(json.dumps(result,indent=2))
