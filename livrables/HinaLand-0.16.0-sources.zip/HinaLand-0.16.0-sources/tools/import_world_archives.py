"""Convert supplied structure/texture data to Minecraft 1.20.1 resources."""
from pathlib import Path
import json,shutil,sys,hashlib
sys.path.insert(0,'/workspace/tools/pythonlibs')
import nbtlib
R=Path(__file__).resolve().parents[1];root=R/'src/main/resources';a=root/'assets/hinaland';data=root/'data/hinaland';archives=R/'imported-worlds'
new=['genshin','overwatch','lethal'];core=['bedrock','redstone_ore','iron_ore','gold_ore','obsidian','oak_leaves','bricks','snow','stone','cobblestone','gravel','coal_ore','sandstone','oak_log','dirt','oak_planks','sand','stone_bricks','diamond_ore','netherrack'];flowers=['dandelion','poppy','blue_orchid','oxeye_daisy']
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
report={'textures':{},'structures':[]}
for f in new:
 base=archives/'texture + structure'/(f.title()+'_Pack')/'assets/minecraft/textures/block'
 entries=[]
 for section in ['assets/hinaland/models/block','assets/hinaland/models/item','assets/hinaland/blockstates','data/hinaland/loot_tables/blocks','data/hinaland/recipes','data/hinaland/worldgen/configured_feature','data/hinaland/worldgen/placed_feature','data/hinaland/worldgen/biome']:
  for p in (root/section).glob('mario*.json'):
   d=json.loads(p.read_text().replace('mario',f))
   if '/biome' in section:
    d['spawners']['monster']=[];d['spawners']['creature']=[{'type':'minecraft:sheep','weight':8,'minCount':2,'maxCount':4}] if f!='lethal' else []
    d['effects'].update({'sky_color':{'genshin':7907327,'overwatch':11256278,'lethal':4145735}[f],'grass_color':{'genshin':8504965,'overwatch':10999170,'lethal':6773589}[f],'foliage_color':{'genshin':11173578,'overwatch':9870727,'lethal':5521479}[f]})
   write(p.with_name(p.name.replace('mario',f)),d)
 for p in base.glob('*.png'):
  out=a/'textures/block'/(f+'_'+p.name);shutil.copy2(p,out)
  entries.append({'file':str(out.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 for kind in core+['grass_block_top','grass_block_side','oak_log_top','sandstone_top']:
  dest=a/'textures/block'/f'{f}_{kind}.png'
  if not dest.exists():
   # Supplied packs omit these blocks: preserve vanilla appearance explicitly.
   for p in [a/'models/block'/f'{f}_{kind}.json']:
    if p.exists():p.write_text(p.read_text().replace('hinaland:block/'+f+'_'+kind,'minecraft:block/'+('snow' if kind=='snow' else kind)))
 # Vanilla-compatible additional terrain textures are real registered blocks.
 for kind in ['emerald_ore','lapis_ore','copper_ore','spruce_log','spruce_leaves','birch_log','birch_leaves','mossy_cobblestone','moss_block','packed_ice','blue_ice']:
  if not (base/(kind+'.png')).exists():continue
  id=f+'_'+kind;tex='hinaland:block/'+id
  model={'parent':'minecraft:block/cube_all','textures':{'all':tex}}
  if kind.endswith('_log'):model={'parent':'minecraft:block/cube_column','textures':{'side':tex,'end':tex+'_top'}}
  if kind.endswith('_leaves'):model['parent']='minecraft:block/leaves'
  write(a/'models/block'/f'{id}.json',model);write(a/'models/item'/f'{id}.json',{'parent':'hinaland:block/'+id});write(a/'blockstates'/f'{id}.json',{'variants':{'':{'model':'hinaland:block/'+id}}})
  write(data/'loot_tables/blocks'/f'{id}.json',{'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'hinaland:'+id}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]})
 report['textures'][f]=entries
# Extend real block tags using equivalent Mario entries and vanilla extra-block tags.
for p in (root/'data/minecraft/tags').rglob('*.json'):
 d=json.loads(p.read_text());v=d.get('values',[])
 for f in new:v+= [s.replace('mario',f) for s in list(v) if isinstance(s,str) and s.startswith('hinaland:mario')]
 d['values']=list(dict.fromkeys(v));write(p,d)
for f in new:
 for kind in ['emerald_ore','lapis_ore','copper_ore','spruce_log','spruce_leaves','birch_log','birch_leaves','mossy_cobblestone','moss_block','packed_ice','blue_ice']:
  if not (a/'blockstates'/f'{f}_{kind}.json').exists():continue
  tags=['blocks/mineable/pickaxe'] if kind.endswith('_ore') or kind in ['mossy_cobblestone','packed_ice','blue_ice'] else ['blocks/mineable/axe','blocks/logs','items/logs'] if kind.endswith('_log') else ['blocks/leaves','items/leaves'] if kind.endswith('_leaves') else ['blocks/mineable/hoe']
  if kind.endswith('_ore'):tags+=['blocks/needs_iron_tool'] if kind=='emerald_ore' else ['blocks/needs_stone_tool']
  for tag in tags:
   p=root/'data/minecraft/tags'/f'{tag}.json';d=json.loads(p.read_text()) if p.exists() else {'replace':False,'values':[]};d['values']=list(dict.fromkeys(d['values']+['hinaland:'+f+'_'+kind]));write(p,d)
# Use the supplied ore textures in underground generation and retain normal mineral drops.
for f in new:
 for kind,mineral,size in [('emerald','emerald',3),('lapis','lapis_lazuli',7),('copper','raw_copper',10)]:
  block=f+'_'+kind+'_ore'
  if not (a/'blockstates'/f'{block}.json').exists():continue
  d=json.loads((data/'worldgen/configured_feature'/f'{f}_coal_veins.json').read_text().replace(f+'_coal_ore',block));d['config']['size']=size
  write(data/'worldgen/configured_feature'/f'{f}_{kind}_veins.json',d)
  p=data/'worldgen/placed_feature'/f'{f}_ore_{kind}.json';d=json.loads(p.read_text());d['feature']='hinaland:'+f+'_'+kind+'_veins';write(p,d)
  d=json.loads((data/'loot_tables/blocks'/f'{f}_iron_ore.json').read_text().replace(f+'_iron_ore',block).replace('minecraft:raw_iron','minecraft:'+mineral));d.pop('random_sequence',None)
  write(data/'loot_tables/blocks'/f'{block}.json',d)
# Jigsaw templates: singular `structure` is a 1.21 path; 1.20.1 needs `structures`.
for base in [archives/'structure/Mondes_Nature',archives/'texture + structure/Mondes_Structures']:
 namespace='mondes_nature' if base.name=='Mondes_Nature' else 'mondes';nsroot=base/'data'/namespace
 for p in nsroot.rglob('*.json'):
  rel=Path(str(p.relative_to(nsroot)).replace('loot_table/','loot_tables/'));d=json.loads(p.read_text().replace(namespace+':','hinaland:'))
  if 'tags/worldgen/biome' in str(rel):
   f=p.stem.split('_')[0];d['values']=['hinaland:'+f+v for v in ['', '_forest','_highlands','_dunes']]
  write(data/rel,d)
 for p in nsroot.rglob('*.nbt'):
  n=nbtlib.load(p);f=p.stem.split('_')[0];changed=0
  for state in n['palette']:
   name=str(state['Name']).removeprefix('minecraft:');kind={'grass_block':'soil','snow_block':'snow'}.get(name,name)
   if (a/'blockstates'/f'{f}_{kind}.json').exists():
    state['Name']=nbtlib.String('hinaland:'+f+'_'+kind);changed+=1
    # Custom soil has no snowy property; preserve axis/leaves states when supported.
    if kind=='soil':state.pop('Properties',None)
  for b in n['blocks']:
   if 'nbt' in b and 'LootTable' in b['nbt']:
    table=str(b['nbt']['LootTable']).replace(namespace+':','hinaland:')
    if table=='hinaland:chests/lethal':table='hinaland:chests/lethal_facility'
    b['nbt']['LootTable']=nbtlib.String(table)
  out=data/'structures'/p.name;out.parent.mkdir(parents=True,exist_ok=True);n.save(out,gzipped=True)
  report['structures'].append({'id':'hinaland:'+p.stem,'size':list(map(int,n['size'])),'themed_palette_entries':changed,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
write(R/'imported-worlds-0.11.json',report)
print('Converted',len(report['structures']),'structures;', {f:len(v) for f,v in report['textures'].items()})
