"""Count actual fluid states in the nine saved FULL site chunks, not just configured sea level."""
import json,sys,collections
from pathlib import Path
import numpy as np
from read_region import chunks
world=Path(sys.argv[1]);sites=json.loads(Path(sys.argv[2]).read_text());wanted={(x//16,z//16):k for k,(x,z)in sites.items()};out={}
for n in chunks(world):
 pos=(int(n['xPos']),int(n['zPos']))
 if pos not in wanted or str(n['Status'])!='minecraft:full':continue
 high=below=0;columns=np.full(256,-999,dtype=int);topwater=np.zeros(256,dtype=bool)
 for sec in sorted(n['sections'],key=lambda s:int(s['Y'])):
  b=sec.get('block_states',{});p=[str(s['Name'])for s in b.get('palette',[])];y=int(sec['Y'])*16
  if not p:continue
  if len(p)==1:a=np.zeros(4096,dtype=np.uint16)
  else:
   bits=max(4,(len(p)-1).bit_length());per=64//bits;words=np.array([int(w)&((1<<64)-1)for w in b['data']],dtype=np.uint64);a=((words[:,None]>>np.arange(per,dtype=np.uint64)*bits)&((1<<bits)-1)).reshape(-1)[:4096]
  for idx,name in enumerate(p):
   if name=='minecraft:air' or name in {'minecraft:cave_air','minecraft:void_air'}:continue
   for i in np.nonzero(a==idx)[0]:
    height=y+(int(i)>>8);col=int(i)&255
    if height>columns[col]:columns[col]=height;topwater[col]=name=='minecraft:water'
    if name=='minecraft:water':
     if height>0:high+=1
     else:below+=1
  # Snow/plants count as surface, conservative water-top test.
 out[wanted[pos]]={'chunk':list(pos),'water_above_y0':high,'water_at_or_below_y0':below,'surface_water_columns':int(sum(topwater)),'columns':256,'surface_height_range':[int(min(columns)),int(max(columns))]}
assert len(out)==len(sites),(len(out),len(sites));Path(sys.argv[3]).write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
