"""Small ground-checked themed landmarks and complete lit Nether gateways for 0.14."""
import pathlib,json,sys
sys.path.insert(0,'/workspace/tools/pythonlibs')
import nbtlib as n
r=pathlib.Path(__file__).resolve().parents[1];res=r/'src/main/resources';d=res/'data/hinaland';families=['mario','sonic','omori','deltarune','genshin','overwatch','lethal']
def write(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,indent=2)+'\n')
def template(name,size,blocks):
 palette=[];indices={};out=[]
 for pos,(block,props,extra) in blocks.items():
  k=(block,tuple(sorted(props.items())))
  if k not in indices:
   indices[k]=len(palette);state=n.Compound({'Name':n.String(block)})
   if props:state['Properties']=n.Compound({k:n.String(v) for k,v in props.items()})
   palette.append(state)
  value=n.Compound({'pos':n.List[n.Int](pos),'state':n.Int(indices[k])})
  if extra:value['nbt']=n.Compound({k:n.String(v) for k,v in extra.items()})
  out.append(value)
 n.File({'DataVersion':n.Int(3465),'size':n.List[n.Int](size),'palette':n.List[n.Compound](palette),'blocks':n.List[n.Compound](out),'entities':n.List[n.Compound]([])},gzipped=True).save(d/f'structures/{name}.nbt')
def base(f,sx,sz):
 return {(x,y,z):('hinaland:'+f+('_stone' if y<2 else '_stone_bricks'),{}, {}) for x in range(sx) for z in range(sz) for y in range(3)}
def put(b,x,y,z,name,props=None,extra=None):b[(x,y,z)]=(name,props or {},extra or {})
added=[]
def register(f,name,blocks,size,weight=1):
 template(name,size,blocks)
 write(d/f'worldgen/structure/{name}.json',{'type':'hinaland:grounded','biomes':'#hinaland:has_structure/'+name,'step':'surface_structures','spawn_overrides':{},'terrain_adaptation':'none','template':'hinaland:'+name,'max_slope':4})
 write(d/f'tags/worldgen/biome/has_structure/{name}.json',{'values':['hinaland:'+f,'hinaland:'+f+'_forest']})
 p=d/f'worldgen/structure_set/{f}_settlements.json';obj=json.loads(p.read_text()) if p.exists() else {'structures':[],'placement':{'type':'minecraft:random_spread','spacing':48,'separation':24,'salt':137130,'frequency':.65}}
 obj['structures']=[x for x in obj['structures'] if x['structure']!='hinaland:'+name]+[{'structure':'hinaland:'+name,'weight':weight}];write(p,obj);added.append({'family':f,'structure':name,'size':size})
for f in families:
 b=base(f,9,9)
 # Full 4x5 obsidian frame. Interior pre-lit; vanilla travel code remains authoritative.
 for x in range(2,6):
  for y in range(3,8):
   if x in [2,5] or y in [3,7]:put(b,x,y,4,'minecraft:obsidian')
   else:put(b,x,y,4,'minecraft:nether_portal',{'axis':'x'})
 for x in [0,7]:
  for z in [1,7]:
   for y in range(3,6):put(b,x,y,z,'hinaland:'+f+'_bricks')
   put(b,x,6,z,'minecraft:lantern',{'hanging':'false','waterlogged':'false'})
 put(b,7,3,5,'minecraft:chest',{'facing':'south','type':'single','waterlogged':'false'},{'LootTable':'hinaland:chests/'+f})
 register(f,f+'_nether_gateway',b,[9,8,9])
b=base('mario',13,9)
for x in [2,6,10]:
 put(b,x,6,4,'hinaland:mario_question_block')
 for y in range(3,5):put(b,x, y,0,'hinaland:mario_bricks')
for x in range(13):
 for z in [0,8]:put(b,x,3,z,'hinaland:mario_oak_leaves',{'persistent':'true','distance':'1','waterlogged':'false'})
for z in range(1,8):
 for x in [0,12]:put(b,x,3,z,'hinaland:mario_oak_leaves',{'persistent':'true','distance':'1','waterlogged':'false'})
register('mario','mario_bonus_garden',b,[13,7,9])
b=base('sonic',9,9)
# Voxel hoop landmark, independent of texture-pack-only decorative ore.
for x,y in [(2,5),(2,6),(3,4),(3,7),(4,4),(4,7),(5,4),(5,7),(6,5),(6,6)]:put(b,x,y,4,'hinaland:ring_gold_block')
put(b,1,3,1,'minecraft:chest',{'facing':'south','type':'single','waterlogged':'false'},{'LootTable':'hinaland:chests/sonic'})
register('sonic','sonic_ring_shrine',b,[9,8,9])
b=base('omori',9,9)
for x in range(2,7):
 for z in range(2,7):put(b,x,3,z,'minecraft:pink_carpet')
for x,z in [(1,1),(7,1),(1,7),(7,7)]:
 put(b,x,2,z,'hinaland:omori_soil');put(b,x,3,z,'hinaland:omori_blue_orchid')
put(b,4,3,4,'minecraft:chest',{'facing':'south','type':'single','waterlogged':'false'},{'LootTable':'hinaland:chests/omori'})
register('omori','omori_picnic',b,[9,4,9])
b=base('deltarune',9,9)
for x in range(1,8):
 for z in range(1,8):put(b,x,2,z,'hinaland:deltarune_'+('obsidian' if (x+z)%2 else 'stone_bricks'))
for x,z in [(1,1),(7,1),(1,7),(7,7)]:
 for y in range(3,6):put(b,x,y,z,'hinaland:deltarune_bricks')
 put(b,x,6,z,'minecraft:lantern',{'hanging':'false','waterlogged':'false'})
put(b,4,3,4,'minecraft:chest',{'facing':'south','type':'single','waterlogged':'false'},{'LootTable':'hinaland:chests/deltarune'})
register('deltarune','deltarune_chess_court',b,[9,7,9])
# DELTARUNE lacked a chest pool. The starting shrine/gateway now rewards its own progression.
write(d/'loot_tables/chests/deltarune.json',{'type':'minecraft:chest','pools':[{'rolls':{'type':'minecraft:uniform','min':2,'max':4},'entries':[{'type':'minecraft:item','name':'hinaland:glowshard','weight':4,'functions':[{'function':'minecraft:set_count','count':{'type':'minecraft:uniform','min':1,'max':3}}]},{'type':'minecraft:item','name':'minecraft:bread','weight':4},{'type':'minecraft:item','name':'hinaland:deltarune_essence','weight':2}]}]})
# Do not generate a ruined portal in any of the exclusive Hina Overworld biomes.
# The original vanilla biome lists are retained for the fractured Nether and other dimension presets.
import zipfile
with zipfile.ZipFile('/workspace/hina-modpack-client/versions/1.20.1/1.20.1.jar') as vanilla:
 for name in vanilla.namelist():
  if 'data/minecraft/tags/worldgen/biome/has_structure/ruined_portal' in name and not name.endswith('_nether.json'):
   obj=json.loads(vanilla.read(name));obj['replace']=True;write(res/name,obj)
write(r/'polished-structures-0.14.json',{'new_structures':added,'portals':'Complete 4x5 vanilla obsidian frames, lit, seven family-themed grounded landmarks','shared_grid_spacing':48,'shared_grid_separation':24})
print('11 new grounded landmarks: seven lit Nether gateways, Mario bonus garden, Sonic hoop, OMORI picnic, DELTARUNE chess court')
