"""Convert supplied Java exteriors and Bedrock facility; never execute attached commands/scripts."""
import json,sys,math,shutil,collections
from pathlib import Path
sys.path.insert(0,'/workspace/tools/pythonlibs')
import nbtlib,numpy as np
R=Path(__file__).resolve().parents[1];res=R/'src/main/resources';assets=res/'assets/hinaland';data=res/'data/hinaland';src=R/'imported-lethal-worlds/Lethal Company Add-on Test'
def read(p):return json.loads('\n'.join(l for l in p.read_text().splitlines() if not l.lstrip().startswith('//')))
def write(p,j):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,indent=2)+'\n')
def bid(n):return 'lc_'+n.replace(':','_').replace('-','_')
def template(name,size,blocks):
 palette=[];ids={};out=[]
 for p,n,props in blocks:
  key=(n,tuple(sorted(props.items())))
  if key not in ids:
   ids[key]=len(palette);state=nbtlib.Compound({'Name':nbtlib.String(n)})
   if props:state['Properties']=nbtlib.Compound({k:nbtlib.String(str(v)) for k,v in props.items()})
   palette.append(state)
  out.append(nbtlib.Compound({'pos':nbtlib.List[nbtlib.Int](p),'state':nbtlib.Int(ids[key])}))
 t=nbtlib.File({'DataVersion':nbtlib.Int(3465),'size':nbtlib.List[nbtlib.Int](size),'palette':nbtlib.List[nbtlib.Compound](palette),'blocks':nbtlib.List[nbtlib.Compound](out),'entities':nbtlib.List[nbtlib.Compound]([])},gzipped=True)
 p=data/'structures'/f'{name}.nbt';p.parent.mkdir(parents=True,exist_ok=True);t.save(p);return len(out)
# Model all used industrial blocks, including original cube rotations, as Forge OBJ meshes.
raw=json.loads((R/'bedrock-blocks.json').read_text());used={n for p,n,s in raw if n.startswith(('lc:','ff:'))};geos={}
for p in (src/'resource_packs/Lethal Company Mod/models/blocks').rglob('*.json'):
 for g in read(p).get('minecraft:geometry',[]):geos[g['description']['identifier']]=g
terrain=read(src/'resource_packs/Lethal Company Mod/textures/terrain_texture.json')['texture_data'];spec=[]
def matrix(rot,pivot):
 a=np.radians(rot);x,y,z=a
 rx=np.array([[1,0,0],[0,math.cos(x),-math.sin(x)],[0,math.sin(x),math.cos(x)]])
 ry=np.array([[math.cos(y),0,math.sin(y)],[0,1,0],[-math.sin(y),0,math.cos(y)]])
 rz=np.array([[math.cos(z),-math.sin(z),0],[math.sin(z),math.cos(z),0],[0,0,1]])
 m=np.eye(4);m[:3,:3]=rz@ry@rx;p=np.array(pivot);m[:3,3]=p-m[:3,:3]@p;return m
faces={'north':[0,3,2,1],'south':[4,5,6,7],'west':[0,4,7,3],'east':[1,2,6,5],'up':[3,7,6,2],'down':[0,1,5,4]}
for p in (src/'behavior_packs/Lethal Company Mod/blocks').glob('*.json'):
 j=read(p)['minecraft:block'];n=j['description']['identifier']
 if n not in used:continue
 ident=bid(n);c=j['components'];geo=geos[c['minecraft:geometry']];tex=c['minecraft:material_instances']['*']['texture'];tex=tex if tex in terrain else 'textura_letal_1';tp=terrain[tex]['textures'];tp=tp[0] if isinstance(tp,list) else tp;tp=tp['path'] if isinstance(tp,dict) else tp
 source=(src/'resource_packs/Lethal Company Mod'/tp).with_suffix('.png');dest=assets/'textures/block'/('lc_import_'+tex+'.png');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
 texture='hinaland:block/lc_import_'+tex;desc=geo['description'];tw,th=desc['texture_width'],desc['texture_height'];bones={b['name']:b for b in geo['bones']};mat={}
 def bone(name):
  if name in mat:return mat[name]
  b=bones[name];m=matrix(b.get('rotation',[0,0,0]),b.get('pivot',[0,0,0]));mat[name]=bone(b['parent'])@m if b.get('parent') in bones else m;return mat[name]
 obj=[f'mtllib {ident}.mtl','usemtl industrial'];vi=ti=0
 for b in geo['bones']:
  for cube in b.get('cubes',[]):
   o=np.array(cube['origin'],float);s=np.array(cube['size'],float);inflate=cube.get('inflate',0);o-=inflate;s+=2*inflate
   vertices=np.array([[o[0],o[1],o[2]],[o[0]+s[0],o[1],o[2]],[o[0]+s[0],o[1]+s[1],o[2]],[o[0],o[1]+s[1],o[2]],[o[0],o[1],o[2]+s[2]],[o[0]+s[0],o[1],o[2]+s[2]],[o[0]+s[0],o[1]+s[1],o[2]+s[2]],[o[0],o[1]+s[1],o[2]+s[2]]])
   transform=bone(b['name'])@matrix(cube.get('rotation',[0,0,0]),cube.get('pivot',b.get('pivot',[0,0,0])))
   vertices=(transform@np.c_[vertices,np.ones(8)].T).T[:,:3];vertices=(vertices+np.array([8,0,8]))/16
   for v in vertices:obj.append('v '+' '.join(f'{x:.7f}' for x in v))
   uv=cube.get('uv',[0,0]);sx,sy,sz=cube['size']
   for face,indices in faces.items():
    if isinstance(uv,dict):
     if face not in uv:continue
     loc=uv[face]['uv'];szuv=uv[face].get('uv_size',[sx,sy]);u,v=loc;w,h=szuv
    else:
     u,v=uv;rect={'west':(u,v+sz,sz,sy),'north':(u+sz,v+sz,sx,sy),'east':(u+sz+sx,v+sz,sz,sy),'south':(u+sz*2+sx,v+sz,sx,sy),'up':(u+sz,v,sx,sz),'down':(u+sz+sx,v,sx,sz)};u,v,w,h=rect[face]
    points=[(u+w,v+h),(u,v+h),(u,v),(u+w,v)]
    for a,bb in points:obj.append(f'vt {a/tw:.7f} {bb/th:.7f}')
    obj.append('f '+' '.join(f'{vi+idx+1}/{ti+q+1}'for q,idx in enumerate(indices)));ti+=4
   vi+=8
 model=assets/'models/block'/ident;model.parent.mkdir(parents=True,exist_ok=True);model.with_suffix('.obj').write_text('\n'.join(obj)+'\n');model.with_suffix('.mtl').write_text(f'newmtl industrial\nKa 0 0 0\nKd 1 1 1\nmap_Kd {texture}\n')
 write(model.with_suffix('.json'),{'loader':'forge:obj','model':f'hinaland:models/block/{ident}.obj','automatic_culling':False,'flip_v':True,'emissive_ambient':False,'textures':{'particle':texture},'render_type':'minecraft:cutout'})
 write(assets/'blockstates'/f'{ident}.json',{'variants':{'facing='+f:{'model':'hinaland:block/'+ident,'y':angle}for f,angle in [('north',0),('east',90),('south',180),('west',270)]}})
 write(assets/'models/item'/f'{ident}.json',{'parent':'hinaland:block/'+ident})
 col=c.get('minecraft:entity_collision',True);shape=None
 if isinstance(col,dict):
  a=col.get('origin',[-8,0,-8]);sz=col.get('size',[16,16,16]);shape=[a[0]+8,a[1],a[2]+8,a[0]+8+sz[0],a[1]+sz[1],a[2]+8+sz[2]];shape=[min(shape[i],shape[i+3])for i in range(3)]+[max(shape[i],shape[i+3])for i in range(3)]
 elif col:shape=[0,0,0,16,16,16]
 spec.append({'source':n,'id':ident,'collision':shape,'light':8 if n=='lc:luzletal' else 0})
 write(data/'loot_tables/blocks'/f'{ident}.json',{'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'hinaland:'+ident}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]})
write(res/'data/hinaland/industrial_blocks.json',spec)
# Registry list generated in Java, no runtime dependence on Python/Bedrock libraries.
lines=[]
for s in spec:
 shape='net.minecraft.world.phys.shapes.Shapes.empty()' if s['collision'] is None else 'net.minecraft.world.level.block.Block.box('+','.join(str(x)for x in s['collision'])+')'
 lines.append(f'  add("{s["id"]}",{shape},{s["light"]});')
(R/'src/main/java/fr/hinaland/ImportedIndustrialBlocks.java').write_text('''package fr.hinaland;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.item.*;
public final class ImportedIndustrialBlocks {
 public static void register(){
'''+ '\n'.join(lines)+'''
 }
 private static void add(String id,VoxelShape shape,int light){net.minecraftforge.registries.RegistryObject<net.minecraft.world.level.block.Block> b=HinaLand.BLOCKS.register(id,()->new IndustrialBlock(shape,light));HinaLand.WORLD_BLOCKS.put(id,b);HinaLand.ALL.put(id,HinaLand.ITEMS.register(id,()->new BlockItem(b.get(),new Item.Properties())));}
}
''')
# Safe, explicit Bedrock-to-Java state translation. Attached command logic is removed.
unsupported=collections.Counter()
def convert(n,s):
 if n.startswith(('lc:','ff:')):return 'hinaland:'+bid(n),{'facing':{2:'south',3:'north',4:'west',5:'east'}.get(s.get('bridge:block_rotation'), 'north')}
 if 'command_block'in n or n in {'minecraft:structure_block','minecraft:redstone_wire','minecraft:powered_comparator','minecraft:unpowered_repeater','minecraft:powered_repeater'}:return 'minecraft:air',{}
 if 'door'in n:
  return ('minecraft:oak_door' if n=='minecraft:wooden_door' else n),{'facing':['east','south','west','north'][s.get('direction',0)%4],'half':'upper'if s.get('upper_block_bit')else'lower','hinge':'right'if s.get('door_hinge_bit')else'left','open':str(bool(s.get('open_bit'))).lower(),'powered':'false'}
 if n in {'minecraft:stone_block_slab2','minecraft:double_stone_block_slab2'}:return 'minecraft:red_sandstone_slab',{'type':'double'if'double'in n else'top'if s.get('top_slot_bit')else'bottom','waterlogged':'false'}
 if n=='minecraft:ladder':return n,{'facing':{2:'north',3:'south',4:'west',5:'east'}.get(s.get('facing_direction'), 'north')}
 if n.endswith('_stairs'):return n,{'facing':['east','west','south','north'][s.get('weirdo_direction',0)%4],'half':'top'if s.get('upside_down_bit')else'bottom','shape':'straight','waterlogged':'false'}
 if n in {'minecraft:redstone_torch','minecraft:unlit_redstone_torch'}:return 'minecraft:air',{}
 if n=='minecraft:rail':return n,{'shape':'north_south','waterlogged':'false'}
 if n=='minecraft:deadbush':return'minecraft:dead_bush',{}
 if n=='minecraft:polished_basalt':return n,{'axis':s.get('pillar_axis','y')}
 return n,{}
# Retain the complete industrial negative-X complex; exclude the desert, ship and isolated positive-X test props.
origin=[-136,-64,37];size=[133,26,116];tiles=collections.defaultdict(list);converted={}
for p,n,s in raw:
 if not all(origin[i]<=p[i]<origin[i]+size[i]for i in range(3)):continue
 name,props=convert(n,s)
 if name=='minecraft:air':continue
 rel=tuple(p[i]-origin[i]for i in range(3));converted[rel]=(name,props)
# Choose a real floor/roof/walled corridor for arrival, checking the same geometry as IndoorHabitat.
full={'hinaland:lc_lc_bloque1','hinaland:lc_lc_bloque2','hinaland:lc_lc_bloque3','minecraft:iron_block','minecraft:cobbled_deepslate'}
def solid(p):return converted.get(p,('minecraft:air',{}))[0] in full
candidates=[]
for x in range(20,120):
 for z in range(15,100):
  y=5;p=(x,y,z)
  if p in converted or(x,y+1,z)in converted or not solid((x,y-1,z)):continue
  if not any(solid((x,y+d,z))for d in range(2,17)):continue
  walls=sum(any(solid((x+dx*d,y+1,z+dz*d))for d in range(1,13))for dx,dz in [(1,0),(-1,0),(0,1),(0,-1)])
  if walls>=4:candidates.append((abs(x-81)+abs(z-44),p))
assert candidates,'No safe industrial room';arrival=min(candidates)[1]
# Return door adjacent to the arrival, placed against a real wall, never in the arrival's two-block clearance.
exitpos=None
for dx,dz in [(1,0),(-1,0),(0,1),(0,-1)]:
 for distance in range(2,7):
  p=(arrival[0]+dx*distance,arrival[1],arrival[2]+dz*distance)
  if solid(p) and solid((p[0],p[1]-1,p[2])):
   exitpos=p;break
 if exitpos:break
assert exitpos
for dy in [0,1]:converted[(exitpos[0],exitpos[1]+dy,exitpos[2])]=('hinaland:lethal_facility_door',{'facing':('west' if dx>0 else 'east' if dx<0 else 'north' if dz>0 else 'south'),'half':'upper'if dy else'lower','hinge':'left','open':'false','powered':'false'})
for rel,(n,s) in converted.items():
 tx,tz=rel[0]//32,rel[2]//32;tiles[tx,tz].append(([rel[0]%32,rel[1],rel[2]%32],n,s))
manifest=[]
for(tx,tz),blocks in sorted(tiles.items()):
 name=f'lethal_interior_{tx}_{tz}';sz=[min(32,size[0]-tx*32),size[1],min(32,size[2]-tz*32)];template(name,sz,blocks);manifest.append({'template':'hinaland:'+name,'offset':[tx*32,0,tz*32],'size':sz})
# Java factory entrance doors become the dimension access doors; trim the supplied flat worlds to the actual buildings.
exteriors=[]
for name,lo,hi in [('march',[54,-42,-77],[78,-25,-57]),('offense',[-78,-50,51],[-50,-31,74])]:
 rawjava=json.loads((R/f'{name}-blocks.json').read_text());lookup={tuple(p):(n,s)for p,n,s in rawjava};blocks=[];doors=[]
 terrain={'minecraft:rooted_dirt','minecraft:podzol','minecraft:grass','minecraft:tall_grass','minecraft:spruce_log','minecraft:spruce_leaves','minecraft:red_sand','minecraft:yellow_terracotta','minecraft:orange_terracotta','minecraft:terracotta','minecraft:white_terracotta','minecraft:dead_bush'}
 footprint={(p[0],p[2])for p,n,prop in rawjava if all(lo[i]<=p[i]<=hi[i]for i in range(3)) and n not in terrain and not n.endswith('_wall_sign')}
 # Small supported front landing for access to the original entrance.
 doorX=11 if name=='march' else 12;doorZ=18 if name=='march' else 19
 porch={(lo[0]+rx,lo[2]+rz)for rx in range(doorX-1,doorX+3)for rz in range(doorZ+1,hi[2]-lo[2]+1)}
 footprint|=porch
 for x in range(lo[0],hi[0]+1):
  for y in range(lo[1],hi[1]+1):
   for z in range(lo[2],hi[2]+1):
    n,s=lookup.get((x,y,z),('minecraft:air',{}));s=dict(s)
    if n in terrain:n='minecraft:air';s={}
    if y-lo[1]<3:
     n=('hinaland:lethal_stone'if y-lo[1]==0 else'hinaland:lethal_dirt')if(x,z)in footprint else'minecraft:air';s={}
    if y-lo[1]==3 and(x,z)in porch:n='minecraft:polished_andesite';s={}
    if y-lo[1]>=4 and(x,z)in porch:n='minecraft:air';s={}
    if n=='minecraft:oak_door':n='hinaland:lethal_facility_door';doors.append([x-lo[0],y-lo[1],z-lo[2]])
    if n=='minecraft:spawner' or 'command_block'in n:n='minecraft:air';s={}
    blocks.append(([x-lo[0],y-lo[1],z-lo[2]],n,s))
 sz=[hi[i]-lo[i]+1 for i in range(3)];id='lethal_'+name+'_entrance';template(id,sz,blocks);assert len(doors)==4,(name,doors)
 write(data/'worldgen/structure'/f'{id}.json',{'type':'hinaland:grounded','biomes':'#hinaland:has_structure/'+id,'step':'surface_structures','spawn_overrides':{},'terrain_adaptation':'none','template':'hinaland:'+id,'max_slope':4})
 write(data/'tags/worldgen/biome/has_structure'/f'{id}.json',{'values':['hinaland:lethal','hinaland:lethal_forest']});exteriors.append({'id':id,'source_origin':lo,'size':sz,'doors':doors})
ps=data/'worldgen/structure_set/lethal_settlements.json';j=read(ps);j['structures']=[{'structure':'hinaland:'+id,'weight':2}for id in ['lethal_march_entrance','lethal_offense_entrance']]+[{'structure':'hinaland:lethal_company_batiment','weight':1}];write(ps,j)
# Dedicated finite interior, deliberately no Overworld terrain/water/sky.
typ={'ambient_light':0.05,'bed_works':False,'coordinate_scale':1.0,'effects':'minecraft:the_end','fixed_time':18000,'has_ceiling':True,'has_raids':False,'has_skylight':False,'height':256,'infiniburn':'#minecraft:infiniburn_overworld','logical_height':256,'min_y':0,'monster_spawn_block_light_limit':15,'monster_spawn_light_level':15,'natural':False,'piglin_safe':True,'respawn_anchor_works':False,'ultrawarm':False};write(data/'dimension_type/lethal_interior.json',typ)
b=read(data/'worldgen/biome/lethal.json');b['has_precipitation']=False;b['carvers']={};b['features']=[[]for _ in range(11)];b['spawners']={k:[]for k in b['spawners']};b['spawners']['monster']=[{'type':'hinaland:lethal_'+n,'weight':w,'minCount':1,'maxCount':1}for n,w in [('bracken',15),('coil_head',15),('hoarding_bug',35),('bunker_spider',35),('barber',8),('nutcracker',20),('ghost_girl',5)]];b['spawn_costs']={entry['type']:{'energy_budget':0.25,'charge':1.0} for entry in b['spawners']['monster']};write(data/'worldgen/biome/lethal_interior.json',b)
write(data/'dimension/lethal_interior.json',{'type':'hinaland:lethal_interior','generator':{'type':'minecraft:flat','settings':{'biome':'hinaland:lethal_interior','features':False,'lakes':False,'layers':[],'structure_overrides':[]}}})
meta={'source_bedrock_origin':origin,'interior_size':size,'arrival':list(arrival),'return_door':list(exitpos),'tiles':manifest,'exteriors':exteriors,'industrial_block_count':len(spec),'converted_blocks':len(converted),'commands_removed':True};write(data/'lethal_interior_manifest.json',meta);write(R/'lethal-maps-0.13.json',meta)
for lang in ['fr_fr','en_us']:
 p=assets/'lang'/f'{lang}.json';j=read(p)
 j['block.hinaland.lethal_facility_door']='Entrée / sortie du complexe Lethal'if lang=='fr_fr'else'Lethal facility entrance / exit'
 for s in spec:j['block.hinaland.'+s['id']]='Lethal — '+s['source'].split(':')[1].replace('-',' ').replace('_',' ')
 write(p,j)
# Door reuses a standard iron-door shape and texture; state names match vanilla DoorBlock.
variants={}
for facing,angle in [('east',0),('south',90),('west',180),('north',270)]:
 for half in ['lower','upper']:
  for hinge in ['left','right']:
   for opened in [False,True]:
    part='bottom'if half=='lower'else'top';suffix=hinge+('_open'if opened else'');key=f'facing={facing},half={half},hinge={hinge},open={str(opened).lower()}'
    variants[key]={'model':f'minecraft:block/iron_door_{part}_{suffix}','y':(angle+(90 if hinge=='left' else 270) if opened else angle)%360}
write(assets/'blockstates/lethal_facility_door.json',{'variants':variants});write(assets/'models/item/lethal_facility_door.json',{'parent':'minecraft:item/iron_door'})
write(data/'loot_tables/blocks/lethal_facility_door.json',{'type':'minecraft:block','pools':[{'rolls':1,'conditions':[{'condition':'minecraft:block_state_property','block':'hinaland:lethal_facility_door','properties':{'half':'lower'}},{'condition':'minecraft:survives_explosion'}],'entries':[{'type':'minecraft:item','name':'hinaland:lethal_facility_door'}]}]})
write(data/'recipes/lethal_facility_door.json',{'type':'minecraft:crafting_shaped','pattern':['II','II','CC'],'key':{'I':{'item':'minecraft:iron_ingot'},'C':{'item':'hinaland:company_alloy'}},'result':{'item':'hinaland:lethal_facility_door','count':1}})
revision=R/'generation-revision-0.13.json'
if revision.exists():
 j=read(revision);j['natural_structures']=list(dict.fromkeys(j['natural_structures']+['lethal_march_entrance','lethal_offense_entrance']));write(revision,j)
print('Converted',len(spec),'industrial models;',len(converted),'blocks;',len(manifest),'room tiles;',exteriors,'arrival',arrival,'exit',exitpos)
