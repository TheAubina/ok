"""0.14 additions. Copy supplied artwork unchanged; generate equipment and worldgen data."""
import pathlib,json,shutil,zipfile,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
root=pathlib.Path(__file__).resolve().parents[1];res=root/'src/main/resources';a=res/'assets/hinaland';d=res/'data/hinaland'
rows={
'mario':[('superbell_bronze','Bronze Super Clochette'),('fireflower_amber','Ambre Fleur de Feu'),('grand_starite','Grande étoilite')],
'sonic':[('ring_gold','Or des anneaux'),('sol_emerald','Émeraude Sol'),('red_star_crystal','Cristal Anneau Rouge')],
'omori':[('picnic_quartz','Quartz du pique-nique'),('melon_jade','Jade pastèque'),('headspace_opal','Opale de Headspace')],
'deltarune':[('glowshard','Éclat lumineux'),('shadow_mithril','Mithril des Ténèbres'),('pipis_lazuli','Lazuli Pipis')],
'genshin':[('white_iron','Fer blanc'),('starsilver','Argent étoilé'),('condessence_crystal','Cristal de condensence')],
'overwatch':[('omnic_steel','Acier omniaque'),('helix_cobalt','Cobalt Helix'),('graviton_alloy','Alliage Graviton')],
'lethal':[('scrap_steel','Acier de récupération'),('vow_quartz','Quartz de Vow'),('titan_alloy','Alliage de Titan')]}
def write(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def tag(ns,name,values):
 p=res/f'data/{ns}/tags/{name}.json';obj=json.loads(p.read_text()) if p.exists() else {'replace':False,'values':[]};obj['values']=list(dict.fromkeys(obj['values']+values));write(p,obj)
def recipe(name,obj):
 write(d/f'recipes/{name}.json',obj)
 ings=list(obj.get('key',{}).values()) or obj.get('ingredients') or [obj['ingredient']]
 cs={f'has_{i}':{'trigger':'minecraft:inventory_changed','conditions':{'items':[{'items':[x['item']]}]}} for i,x in enumerate(ings) if 'item' in x}
 write(d/f'advancements/recipes/expansion/{name}.json',{'parent':'minecraft:recipes/root','criteria':cs,'requirements':[list(cs)],'rewards':{'recipes':['hinaland:'+name]}})
langs={x:json.loads((a/f'lang/{x}.json').read_text()) for x in ['fr_fr','en_us']};manifest=[]
material_art={'mario':[('copper_ingot','copper_block'),('gold_ingot','gold_block'),('nether_star','diamond_block')],'sonic':[('gold_nugget','gold_block'),('emerald','emerald_block'),('redstone','redstone_block')],'omori':[('quartz','quartz_block_side'),('emerald','emerald_block'),('amethyst_shard','amethyst_block')],'deltarune':[('glowstone_dust','glowstone'),('netherite_ingot','netherite_block'),('lapis_lazuli','lapis_block')],'genshin':[('iron_ingot','iron_block'),('iron_ingot','iron_block'),('diamond','diamond_block')],'overwatch':[('iron_ingot','iron_block'),('lapis_lazuli','lapis_block'),('netherite_ingot','netherite_block')],'lethal':[('iron_ingot','iron_block'),('quartz','quartz_block_side'),('netherite_ingot','netherite_block')]}
vanilla=zipfile.ZipFile('/workspace/hina-modpack-client/versions/1.20.1/1.20.1.jar')
packs={'mario':root/'imported-packs/Super Mario Mash-up','omori':next((root/'imported-packs/OMORI 1.20').rglob('OMORI_Pack_1.20')),'deltarune':root/'imported-packs/MINECRAFT-DELTARUNE'}
for f in ['genshin','overwatch','lethal']:packs[f]=root/'imported-worlds/texture + structure'/({'genshin':'Genshin_Pack','overwatch':'Overwatch_Pack','lethal':'Lethal_Pack'}[f])
packs['sonic']=root/'imported-packs/sonic-the-hedgehog'
def copy_art(f,relative,target):
 src=packs[f]/'assets/minecraft/textures'/relative
 if not src.exists() and relative.startswith('models/armor/'):
  material,layer=pathlib.Path(relative).stem.split('_layer_');src=packs[f]/'assets/minecraft/textures/entity/equipment'/('humanoid' if layer=='1' else 'humanoid_leggings')/(material+'.png')
 if not src.exists():
  candidates=sorted((packs[f]/'assets/minecraft/textures').rglob(pathlib.Path(relative).name));src=candidates[0] if candidates else src
 target.parent.mkdir(parents=True,exist_ok=True)
 if src.exists():
  shutil.copy2(src,target)
  meta=src.with_suffix('.png.mcmeta')
  if meta.exists():shutil.copy2(meta,target.with_suffix('.png.mcmeta'))
  return str(src.relative_to(root))
 # Legacy packs sometimes lack armour. Preserve known vanilla UV-compatible art.
 target.write_bytes(vanilla.read('assets/minecraft/textures/'+relative));return 'Minecraft 1.20.1 / '+relative
for f,minerals in rows.items():
 for grade,(m,fr) in enumerate(minerals):
  ore=m+'_ore';block=m+'_block';native=['iron','gold','diamond'][grade]
  ore_kind=['copper_ore','lapis_ore','emerald_ore'][grade]
  ore_source=copy_art(f,'block/'+ore_kind+'.png',a/f'textures/block/{ore}.png')
  icon_art,storage_art=material_art[f][grade]
  storage_source=copy_art(f,'block/'+storage_art+'.png',a/f'textures/block/{block}.png')
  for name,texture in [(ore,ore),(block,block)]:
   write(a/f'blockstates/{name}.json',{'variants':{'':{'model':'hinaland:block/'+name}}});write(a/f'models/block/{name}.json',{'parent':'minecraft:block/cube_all','textures':{'all':'hinaland:block/'+texture}});write(a/f'models/item/{name}.json',{'parent':'hinaland:block/'+name})
  icon_source=copy_art(f,'item/'+icon_art+'.png',a/f'textures/item/{m}.png')
  write(a/f'models/item/{m}.json',{'parent':'minecraft:item/generated','textures':{'layer0':'hinaland:item/'+m}})
  loot=json.loads((d/f'loot_tables/blocks/{f}_diamond_ore.json').read_text());children=loot['pools'][0]['entries'][0]['children'];children[0]['name']='hinaland:'+ore;children[1]['name']='hinaland:'+m;loot['random_sequence']='hinaland:blocks/'+ore;write(d/f'loot_tables/blocks/{ore}.json',loot)
  write(d/f'loot_tables/blocks/{block}.json',{'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'hinaland:'+block}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]})
  for path in ['blocks/mineable/pickaxe','blocks/needs_iron_tool']:tag('minecraft',path,['hinaland:'+ore,'hinaland:'+block])
  for path in ['blocks/ores','items/ores']:tag('forge',path,['hinaland:'+ore])
  for path in ['blocks/storage_blocks','items/storage_blocks']:tag('forge',path,['hinaland:'+block])
  tag('forge','items/materials',['hinaland:'+m]);write(d/f'tags/blocks/needs_{m}_tool.json',{'values':[]})
  minimum=[-32,-48,-60][grade];maximum=[80,32,0][grade];size=[8,6,4][grade];attempts=[6,4,2][grade];feature=m+'_veins'
  write(d/f'worldgen/configured_feature/{feature}.json',{'type':'minecraft:ore','config':{'size':size,'discard_chance_on_air_exposure':0.0,'targets':[{'target':{'predicate_type':'minecraft:block_match','block':host},'state':{'Name':'hinaland:'+ore}} for host in ['hinaland:'+f+'_stone','minecraft:stone','minecraft:deepslate']]}})
  write(d/f'worldgen/placed_feature/{feature}.json',{'feature':'hinaland:'+feature,'placement':[{'type':'minecraft:count','count':attempts},{'type':'minecraft:in_square'},{'type':'minecraft:height_range','height':{'type':'minecraft:uniform','min_inclusive':{'absolute':minimum},'max_inclusive':{'absolute':maximum}}},{'type':'minecraft:biome'}]})
  for suffix in ['', '_forest','_highlands','_dunes']:
   p=d/f'worldgen/biome/{f}{suffix}.json';obj=json.loads(p.read_text());ref='hinaland:'+feature
   if ref not in obj['features'][6]:obj['features'][6].append(ref)
   write(p,obj)
  recipe(block,{'type':'minecraft:crafting_shaped','pattern':['MMM','MMM','MMM'],'key':{'M':{'item':'hinaland:'+m}},'result':{'item':'hinaland:'+block}})
  recipe(m+'_from_block',{'type':'minecraft:crafting_shapeless','ingredients':[{'item':'hinaland:'+block}],'result':{'item':'hinaland:'+m,'count':9}})
  for kind,time in [('smelting',200),('blasting',100)]:recipe(m+'_'+kind,{'type':'minecraft:'+kind,'ingredient':{'item':'hinaland:'+ore},'result':'hinaland:'+m,'experience':0.5+grade*0.2,'cookingtime':time})
  patterns={'pickaxe':['MMM',' S ',' S '],'sword':[' M ',' M ',' S '],'axe':['MM ','MS ',' S '],'helmet':['MMM','M M'],'chestplate':['M M','MMM','MMM'],'leggings':['MMM','M M','M M'],'boots':['M M','M M']}
  labels={'pickaxe':'Pioche','sword':'Épée','axe':'Hache','helmet':'Casque','chestplate':'Plastron','leggings':'Jambières','boots':'Bottes'}
  textures=[]
  for piece,pattern in patterns.items():
   name=m+'_'+piece;keys={'M':{'item':'hinaland:'+m}}
   if piece in ['pickaxe','sword','axe']:keys['S']={'item':'minecraft:stick'}
   recipe(name,{'type':'minecraft:crafting_shaped','pattern':pattern,'key':keys,'result':{'item':'hinaland:'+name}})
   art_native=['iron','diamond','netherite'][grade];source=copy_art(f,f'item/{art_native}_{piece}.png',a/f'textures/item/{name}.png');textures.append(source)
   write(a/f'models/item/{name}.json',{'parent':'minecraft:item/'+('handheld' if piece in ['pickaxe','sword','axe'] else 'generated'),'textures':{'layer0':'hinaland:item/'+name}})
   langs['fr_fr']['item.hinaland.'+name]=labels[piece]+' — '+fr;langs['en_us']['item.hinaland.'+name]=m.replace('_',' ').title()+' '+piece
  for layer in [1,2]:textures.append(copy_art(f,f'models/armor/{["iron","diamond","netherite"][grade]}_layer_{layer}.png',a/f'textures/models/armor/{m}_layer_{layer}.png'))
  langs['fr_fr'].update({'item.hinaland.'+m:fr,'block.hinaland.'+ore:'Minerai — '+fr,'block.hinaland.'+block:'Bloc — '+fr});langs['en_us'].update({'item.hinaland.'+m:m.replace('_',' ').title(),'block.hinaland.'+ore:m.replace('_',' ').title()+' ore','block.hinaland.'+block:m.replace('_',' ').title()+' block'})
  manifest.append({'family':f,'material':m,'name_fr':fr,'grade':grade,'min_y':minimum,'max_y':maximum,'vein_size':size,'attempts':attempts,'item_source':icon_source,'ore_source':ore_source,'storage_source':storage_source,'equipment_sources':textures})
for locale,obj in langs.items():write(a/f'lang/{locale}.json',obj)
write(root/'expansion-minerals-0.14.json',manifest)
print('21 additional minerals, 21 storage blocks, 63 tools/weapons, 84 armour pieces, 231 recipes')
