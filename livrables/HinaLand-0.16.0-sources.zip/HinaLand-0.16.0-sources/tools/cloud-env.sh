# Source this file only in the prepared Codex cloud workspace.
export JAVA_HOME=/workspace/tools/jdk-17.0.16+8
export GRADLE_USER_HOME=/workspace/gradle-cache
export PATH="$JAVA_HOME/bin:$PATH"
