"""Validate stream declarations and decode the five supplied biome music tracks."""
from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parents[1]/'src/main/resources/assets/hinaland'
events=json.loads((root/'sounds.json').read_text());report={}
assert len(events)==5
for event,definition in events.items():
 s=definition['sounds'][0];assert s['stream'] is True
 file=root/'sounds'/(s['name'].split(':')[1]+'.ogg');assert file.exists()
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(file)]))
 stream=probe['streams'][0];assert stream['codec_name']=='vorbis' and int(stream['sample_rate'])==44100
 subprocess.run(['ffmpeg','-v','error','-i',str(file),'-f','null','-'],check=True)
 report[event]={'codec':'vorbis','channels':stream['channels'],'duration_seconds':float(probe['format']['duration']),'bytes':file.stat().st_size,'fully_decoded':True}
print(json.dumps(report,indent=2))
