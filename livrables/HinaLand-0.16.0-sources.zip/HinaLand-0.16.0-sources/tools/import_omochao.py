"""Port supplied Allay CEM geometry to a native Omochao mesh; retain cubes, UVs and hierarchy."""
from pathlib import Path
import json,shutil
R=Path(__file__).resolve().parents[1];a=R/'src/main/resources/assets/hinaland';base=R/'imported-packs/sonic-the-hedgehog/assets/minecraft';d=json.loads((base/'optifine/cem/allay.jem').read_text());bones=[];names=set()
def visit(node,parent,offset,top=False):
 name=node.get('id',node.get('part','part'));original=name;i=1
 while name in names:name=original+'_'+str(i);i+=1
 names.add(name);t=node.get('translate',[0,0,0]);p=[offset[0]+t[0],offset[1]+t[1],offset[2]-t[2]]
 b={'name':name,'parent':parent,'pivot':p};rot=node.get('rotate')
 if rot:b['rotation']=[-rot[0],-rot[1],rot[2]]
 cubes=[]
 for box in node.get('boxes',[]):
  x,y,z,w,h,depth=box['coordinates'];c={'origin':[p[0]+x,p[1]+y,p[2]-z-depth],'size':[w,h,depth],'uv':box['textureOffset']}
  if box.get('sizeAdd'):c['inflate']=box['sizeAdd']
  if node.get('mirrorTexture')=='u':c['mirror']=True
  cubes.append(c)
 b['cubes']=cubes;bones.append(b)
 for child in node.get('submodels',[]):visit(child,name,p)
for n in d['models']:visit(n,'root',[0,24,0],True)
minimum=min(c['origin'][1] for b in bones for c in b['cubes']);scale=.6
for b in bones:
 b['pivot']=[b['pivot'][0]*scale,(b['pivot'][1]-minimum)*scale,b['pivot'][2]*scale]
 for c in b['cubes']:c['origin']=[c['origin'][0]*scale,(c['origin'][1]-minimum)*scale,c['origin'][2]*scale];c['size']=[v*scale for v in c['size']];c['inflate']=c.get('inflate',0)*scale
# Per-face UVs must retain their original lengths when geometry is scaled.
for b in bones:
 for c in b['cubes']:
  u,v=c['uv'];w,h,z=[size/scale for size in c['size']]
  c['uv']={face:{'uv':start,'uv_size':size} for face,start,size in [('north',[u+z,v+z],[w,h]),('south',[u+2*z+w,v+z],[w,h]),('west',[u,v+z],[z,h]),('east',[u+z+w,v+z],[z,h]),('up',[u+z,v],[w,z]),('down',[u+z+w,v+z],[w,-z])]}
model={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.omochao','texture_width':64,'texture_height':64,'visible_bounds_width':3,'visible_bounds_height':3,'visible_bounds_offset':[0,1,0]},'bones':[{'name':'root','pivot':[0,0,0]}]+bones}]}
(a/'geo/omochao.geo.json').write_text(json.dumps(model,indent=2));shutil.copy2(base/'textures/entity/allay/allay.png',a/'textures/entity/biome/omochao.png')
idle={'root':{'position':[0,'math.sin(query.anim_time * 180) * 0.6',0]},'propeller':{'rotation':[0,'query.anim_time * 720',0]},'key':{'rotation':[0,0,'query.anim_time * 120']}}
(a/'animations/omochao.animation.json').write_text(json.dumps({'format_version':'1.8.0','animations':{'animation.omochao.idle':{'loop':True,'animation_length':1,'bones':idle},'animation.omochao.walk':{'loop':True,'animation_length':1,'bones':idle}}},indent=2))
print(len(bones),'Omochao CEM bones converted without OptiFine')
