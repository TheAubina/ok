"""Import selected assets without replacing vanilla resources globally."""
from pathlib import Path
import json,shutil,re,hashlib
R=Path(__file__).resolve().parents[1];root=R/'src/main/resources';a=root/'assets/hinaland';packs=R/'imported-packs'
bases={'mario':packs/'Super Mario Mash-up/assets/minecraft','sonic':packs/'sonic-the-hedgehog/assets/minecraft','omori':next((packs/'OMORI 1.20').rglob('OMORI_Pack_1.20'))/'assets/minecraft','deltarune':packs/'MINECRAFT-DELTARUNE/assets/minecraft'}
report={};kinds=['bedrock','redstone_ore','iron_ore','gold_ore','obsidian','oak_leaves','bricks','snow','stone','cobblestone','gravel','coal_ore','sandstone','oak_log','dirt','oak_planks','sand','stone_bricks','diamond_ore','netherrack','grass_block_top','grass_block_side','oak_log_top','sandstone_top']
flowers=['dandelion','poppy','blue_orchid','oxeye_daisy']
for family,base in bases.items():
 imported=[]
 # DELTARUNE shares vanilla block mechanics but has its own registered resources.
 if family=='deltarune':
  for section in ['assets/hinaland/models/block','assets/hinaland/models/item','assets/hinaland/blockstates','data/hinaland/loot_tables/blocks','data/hinaland/recipes','data/hinaland/worldgen/configured_feature','data/hinaland/worldgen/placed_feature','data/hinaland/worldgen/biome']:
   for p in (root/section).glob('mario*.json'):
    target=p.with_name(p.name.replace('mario','deltarune'))
    if section.endswith('/biome') and target.exists():continue
    target.write_text(p.read_text().replace('mario','deltarune'))
  for p in (root/'data/minecraft/tags').rglob('*.json'):
   d=json.loads(p.read_text());values=d.get('values',[]);extra=[v.replace('mario','deltarune') for v in values if isinstance(v,str) and v.startswith('hinaland:mario')];d['values']=list(dict.fromkeys(values+extra));p.write_text(json.dumps(d,indent=2))
 for kind in kinds:
  src=base/'textures/block'/f'{kind}.png'
  if not src.exists() and family=='sonic':
   matches=sorted((base/'textures/block').rglob(f'{kind}.png'));src=matches[0] if matches else src
  dest=a/'textures/block'/f'{family}_{kind}.png'
  if src.exists():
   shutil.copy2(src,dest);imported.append({'target':str(dest.relative_to(root)),'source':str(src.relative_to(packs)),'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
   meta=src.with_suffix('.png.mcmeta')
   if meta.exists():shutil.copy2(meta,dest.with_suffix('.png.mcmeta'))
  elif family=='deltarune':
   shutil.copy2(a/'textures/block'/f'mario_{kind}.png',dest)
 # Newly accessible flower textures are real blocks, not a global texture pack switch.
 for flower in flowers:
  src=base/'textures/block'/f'{flower}.png'
  if not src.exists():continue
  id=family+'_'+flower;shutil.copy2(src,a/'textures/block'/f'{id}.png')
  meta=src.with_suffix('.png.mcmeta')
  if meta.exists():shutil.copy2(meta,a/'textures/block'/f'{id}.png.mcmeta')
  imported.append({'target':id,'source':str(src.relative_to(packs)),'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
  (a/'models/block'/f'{id}.json').write_text(json.dumps({'parent':'minecraft:block/cross','textures':{'cross':'hinaland:block/'+id}}))
  (a/'models/item'/f'{id}.json').write_text(json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':'hinaland:block/'+id}}))
  (a/'blockstates'/f'{id}.json').write_text(json.dumps({'variants':{'':{'model':'hinaland:block/'+id}}}))
  (root/'data/hinaland/loot_tables/blocks'/f'{id}.json').write_text(json.dumps({'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'hinaland:'+id}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]}))
  wg=root/'data/hinaland/worldgen'
  (wg/'configured_feature'/f'{id}_patch.json').write_text(json.dumps({'type':'minecraft:random_patch','config':{'tries':32,'xz_spread':5,'y_spread':2,'feature':{'feature':{'type':'minecraft:simple_block','config':{'to_place':{'type':'minecraft:simple_state_provider','state':{'Name':'hinaland:'+id}}}},'placement':[{'type':'minecraft:block_predicate_filter','predicate':{'type':'minecraft:all_of','predicates':[{'type':'minecraft:matching_blocks','blocks':'minecraft:air'},{'type':'minecraft:would_survive','state':{'Name':'hinaland:'+id}}]}}]}}}))
  (wg/'placed_feature'/f'{id}_patch.json').write_text(json.dumps({'feature':'hinaland:'+id+'_patch','placement':[{'type':'minecraft:count','count':2},{'type':'minecraft:in_square'},{'type':'minecraft:heightmap','heightmap':'WORLD_SURFACE_WG'},{'type':'minecraft:biome'}]}))
  for v in ['', '_forest','_highlands']:
   p=wg/'biome'/f'{family}{v}.json';d=json.loads(p.read_text());entry='hinaland:'+id+'_patch'
   if entry not in d['features'][9]:d['features'][9].append(entry)
   p.write_text(json.dumps(d,indent=2))
 report[family]=imported
# Preserve weighted Sonic ground meshes and their references under our namespace.
base=bases['sonic'];seen=set()
def import_model(reference):
 path=reference.split(':')[-1];src=base/'models'/(path+'.json')
 if not src.exists():return reference if ':' in reference else 'minecraft:'+reference
 dest_ref='hinaland:imported/sonic/'+path
 if path in seen:return dest_ref
 seen.add(path);d=json.loads(src.read_text())
 if 'parent' in d:d['parent']=import_model(d['parent'])
 for key,value in d.get('textures',{}).items():
  if value.startswith('#'):continue
  tp=value.split(':')[-1];tex=base/'textures'/(tp+'.png')
  if tex.exists():
   out=a/'textures/imported/sonic'/(tp+'.png');out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(tex,out);d['textures'][key]='hinaland:imported/sonic/'+tp
  elif ':' not in value:d['textures'][key]='minecraft:'+value
 out=a/'models/imported/sonic'/(path+'.json');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(d,indent=2));return dest_ref
for block,original in [('soil','grass_block'),('dirt','dirt'),('stone','stone'),('snow','snow_block')]:
 src=base/'blockstates'/f'{original}.json'
 if not src.exists():continue
 d=json.loads(src.read_text());variant=d['variants'].get('snowy=false',d['variants'].get('',next(iter(d['variants'].values()))));arr=variant if isinstance(variant,list) else [variant]
 for item in arr:item['model']=import_model(item['model'])
 (a/'blockstates'/f'sonic_{block}.json').write_text(json.dumps({'variants':{'':arr}},indent=2))
 (a/'models/block'/f'sonic_{block}.json').write_text(json.dumps({'parent':arr[0]['model']}))
# Convert all usable CIT scrap models to registered item models; no OptiFine dependency.
scrap=packs/'MirRPLethalCompany/assets/minecraft/optifine/cit/mirrp/lethalcompany/scrap';names=[]
for p in sorted(scrap.glob('*.json')):
 d=json.loads(p.read_text());name=p.stem;names.append(name)
 for key,value in d.get('textures',{}).items():
  if value.startswith('#'):continue
  src=scrap/(value+'.png')
  if not src.exists():raise ValueError((p,value))
  out=a/'textures/lethal_scrap'/src.name;out.parent.mkdir(exist_ok=True);shutil.copy2(src,out);d['textures'][key]='hinaland:lethal_scrap/'+src.stem
 (a/'models/item'/f'lethal_scrap_{name}.json').write_text(json.dumps(d,indent=2))
report['lethal_scrap']=names
(R/'imported-assets-0.10.json').write_text(json.dumps(report,indent=2))
print('Imported',*[f'{k}: {len(v)}' for k,v in report.items()], 'Sonic models: '+str(len(seen)))
