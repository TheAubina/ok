"""Fetch identifiable references; distinguish publisher pages from community references."""
import urllib.request,json,pathlib,concurrent.futures,re
root=pathlib.Path(__file__).resolve().parents[1];out=root/'audit-0.14/references';out.mkdir(parents=True,exist_ok=True)
refs=[('mario_official','https://mario.nintendo.com/','Nintendo'),('sonic_official','https://sonic.sega.jp/SonicChannel/character/','SEGA'),('omori_official','https://www.omori-game.com/','OMOCAT'),('deltarune_official','https://deltarune.com/','Toby Fox'),('lethal_official','https://store.steampowered.com/app/1966720/Lethal_Company/','Zeekerss / Steam')]
def fetch(row):
 name,url,publisher=row
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=35) as f:body=f.read();status=f.status;final=f.url
  (out/(name+'.html')).write_bytes(body)
  return {'name':name,'url':url,'publisher':publisher,'status':status,'final_url':final,'bytes':len(body)}
 except Exception as e:return {'name':name,'url':url,'publisher':publisher,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:results=list(pool.map(fetch,refs))
(out/'fetch.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
