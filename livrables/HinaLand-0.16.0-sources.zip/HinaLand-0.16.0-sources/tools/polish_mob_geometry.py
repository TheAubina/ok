"""Refine silhouettes without repainting supplied textures. Box UVs retain native face lengths."""
import json,pathlib
from PIL import Image
r=pathlib.Path(__file__).resolve().parents[1];a=r/'src/main/resources/assets/hinaland'
def write(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def uvbox(uv,original):
 u,v=uv;w,h,z=original
 return {face:{'uv':start,'uv_size':size} for face,start,size in [('north',[u+z,v+z],[w,h]),('south',[u+2*z+w,v+z],[w,h]),('west',[u,v+z],[z,h]),('east',[u+z+w,v+z],[z,h]),('up',[u+z,v],[w,z]),('down',[u+z+w,v+z],[w,-z])]}
def cube(origin,size,uv,original=None):return {'origin':origin,'size':size,'uv':uvbox(uv,original or size)}
def solid(id,rgb):
 im=Image.open(a/f'textures/entity/biome/{id}.png').convert('RGBA');candidates=[(sum((c[i]-rgb[i])**2 for i in range(3)),x,y) for y in range(im.height) for x in range(im.width) if (c:=im.getpixel((x,y)))[3]>200];_,x,y=min(candidates)
 return {f:{'uv':[x,y],'uv_size':[1,1]} for f in ['north','south','west','east','up','down']}
def flatcube(o,s,uv):return {'origin':o,'size':s,'uv':uv}
def bone(name,cubes,pivot=None):return {'name':name,'parent':'root','pivot':pivot or [0,0,0],'cubes':cubes}
def model(id,bones,height):
 p=a/f'geo/{id}.geo.json';g=json.loads(p.read_text());g['minecraft:geometry'][0]['bones']=[{'name':'root','pivot':[0,0,0]}]+bones;g['minecraft:geometry'][0]['description'].update(texture_width=Image.open(a/f'textures/entity/biome/{id}.png').width,texture_height=Image.open(a/f'textures/entity/biome/{id}.png').height,visible_bounds_width=3,visible_bounds_height=height,visible_bounds_offset=[0,height/2,0]);write(p,g)
def animate(id,legs,extras=None):
 p=a/f'animations/{id}.animation.json';anim=json.loads(p.read_text())
 anim['animations'][f'animation.{id}.walk']['bones']={name:{'rotation':[f'math.sin(query.anim_time * 360 + {i%2*180}) * 20',0,0]} for i,name in enumerate(legs)}
 if extras:anim['animations'][f'animation.{id}.walk']['bones'].update(extras)
 write(p,anim)
goomba_face=solid('goomba',(205,114,62));goomba_face['north']={'uv':[6,9],'uv_size':[6,6]}
model('goomba',[bone('head',[flatcube([-5,5,-4],[10,7,8],goomba_face)],[0,5,0]),bone('body',[flatcube([-2,2,-2],[4,4,4],solid('goomba',(201,165,114)))]),bone('leg_left',[flatcube([.5,0,-3],[4,2,5],solid('goomba',(105,71,40)))],[2.5,2,0]),bone('leg_right',[flatcube([-4.5,0,-3],[4,2,5],solid('goomba',(105,71,40)))],[-2.5,2,0])],1.5)
animate('goomba',['leg_left','leg_right'])
model('koopa',[bone('head',[cube([-3,13,-5],[6,6,6],[0,0],[6,6,8]),flatcube([-2.5,13,-7],[5,2,2],solid('koopa',(255,230,34)))],[0,13,-2]),bone('body',[cube([-4,4,0],[8,10,5],[28,8],[8,12,6])],[0,8,2]),bone('belly',[flatcube([-3.5,5,-2],[7,8,3],solid('koopa',(250,245,220)))]),bone('arm_left',[flatcube([3.5,5,-2],[2,7,2],solid('koopa',(255,230,34)))],[4,12,0]),bone('arm_right',[flatcube([-5.5,5,-2],[2,7,2],solid('koopa',(255,230,34)))],[-4,12,0]),bone('leg_left',[cube([.5,0,-3],[3,4,5],[0,16],[4,6,4])],[2,4,0]),bone('leg_right',[cube([-3.5,0,-3],[3,4,5],[0,16],[4,6,4])],[-2,4,0])],2)
animate('koopa',['leg_left','leg_right','arm_right','arm_left'])
p=a/'animations/koopa.animation.json';anim=json.loads(p.read_text());anim['animations']['animation.koopa.shell']['bones']={name:{'scale':[.001,.001,.001]} for name in ['head','belly','leg_left','leg_right','arm_left','arm_right']};anim['animations']['animation.koopa.shell']['bones']['body']={'position':[0,-5.6,0],'scale':[1,.6,1]};write(p,anim)
model('dry_bones',[bone('head',[cube([-4,14,-4],[8,6,6],[0,0],[8,8,8]),flatcube([-3,14,-6],[6,2,2],solid('dry_bones',(240,243,237)))],[0,14,0]),bone('body',[cube([-3,5,-1],[6,9,3],[16,16],[8,12,4])]),bone('shell',[flatcube([-4,5,2],[8,8,3],solid('dry_bones',(123,130,125))),flatcube([-3,6,5],[6,6,1],solid('dry_bones',(70,73,66)))]),bone('arm_left',[cube([3,6,-1],[2,7,2],[40,16],[2,12,2])],[4,13,0]),bone('arm_right',[cube([-5,6,-1],[2,7,2],[40,16],[2,12,2])],[-4,13,0]),bone('leg_left',[cube([1,0,-2],[2,5,3],[0,16],[2,12,2])],[2,5,0]),bone('leg_right',[cube([-3,0,-2],[2,5,3],[0,16],[2,12,2])],[-2,5,0])],2)
animate('dry_bones',['leg_left','leg_right','arm_right','arm_left'])
p=a/'animations/dry_bones.animation.json';anim=json.loads(p.read_text());anim['animations']['animation.dry_bones.collapsed']['bones']={'root':{'rotation':[90,0,0],'position':[0,2.7,0],'scale':[1,1,.45]}};write(p,anim)
green=solid('pokey',(76,153,10));yellow=solid('pokey',(210,195,42));bones=[bone('head',[cube([-3,20,-3],[6,6,6],[0,0],[8,8,8])],[0,20,0])]
for i in range(4):
 y=i*5;bones.append(bone('segment_'+str(i),[flatcube([-3,y,-3],[6,5,6],green),flatcube([-4,y+2,-.5],[8,1,1],yellow),flatcube([-.5,y+2,-4],[1,1,8],yellow)],[0,y,0]))
model('pokey',bones,2);animate('pokey',[],{b['name']:{'rotation':[0,0,f'math.sin(query.anim_time * 180 + {i*35}) * 4']} for i,b in enumerate(bones)})
model('sprout_mole',[bone('body',[flatcube([-4,2,-3],[8,8,6],solid('sprout_mole',(180,140,100))),flatcube([-3,6,-3.1],[2,2,.2],solid('sprout_mole',(250,250,245))),flatcube([1,6,-3.1],[2,2,.2],solid('sprout_mole',(250,250,245))),flatcube([-2.3,6.3,-3.3],[.7,1.2,.2],solid('sprout_mole',(119,63,35))),flatcube([1.6,6.3,-3.3],[.7,1.2,.2],solid('sprout_mole',(119,63,35))),flatcube([-.7,4.2,-3.1],[1.4,.4,.2],solid('sprout_mole',(119,63,35)))]),bone('head',[flatcube([-1,10,-.5],[2,4,1],solid('sprout_mole',(137,223,115))),flatcube([-4,12,-.5],[4,2,1],solid('sprout_mole',(137,223,115))),flatcube([0,13,-.5],[4,2,1],solid('sprout_mole',(137,223,115)))],[0,10,0]),bone('leg_left',[flatcube([1,0,-2],[2,2,3],solid('sprout_mole',(117,75,47)))],[2,2,0]),bone('leg_right',[flatcube([-3,0,-2],[2,2,3],solid('sprout_mole',(117,75,47)))],[-2,2,0])],1.5)
animate('sprout_mole',['leg_left','leg_right'],{'head':{'rotation':[0,0,'math.sin(query.anim_time * 180) * 8']}})
# Bunny ears and rear feet: preserve rabbit UV regions but improve readability.
p=a/'geo/forest_bunny.geo.json';g=json.loads(p.read_text());head=next(b for b in g['minecraft:geometry'][0]['bones'] if b['name']=='head');head['cubes'][1]['size'][1]=7;head['cubes'][2]['size'][1]=7
for c in head['cubes'][1:]:c['uv']=uvbox([52,0],[2,5,1])
write(p,g);animate('forest_bunny',['foot_left','foot_right'])
# Correct the stretched DELTARUNE planes to the actual sprite aspect ratio.
for id in ['rudinn','hathy']:
 p=a/f'geo/{id}.geo.json';g=json.loads(p.read_text());desc=g['minecraft:geometry'][0]['description'];height=20;width=height*desc['texture_width']/desc['texture_height'];c=g['minecraft:geometry'][0]['bones'][1]['cubes'][0];c['origin']=[-width/2,0,-.02];c['size']=[width,height,.04];write(p,g)
print('Eight silhouettes/UV proportions refined; supplied pixels retained')
# Replace the old three-colour badnik placeholders with detailed geometry using actual supplied Sonic art.
import shutil
base=r/'imported-packs/sonic-the-hedgehog/assets/minecraft'
shutil.copy2(base/'optifine/cem/skeleton.png',a/'textures/entity/biome/motobug.png')
red=solid('motobug',(215,25,24));metal=solid('motobug',(156,166,180));black=solid('motobug',(17,17,24));white=solid('motobug',(241,241,241))
model('motobug',[bone('body',[flatcube([-5,4,-3],[10,4,7],red),flatcube([-4,8,-2],[8,2,5],red),flatcube([-.25,4,-3.05],[.5,6,8],black),flatcube([-4,4,-5],[8,3,2],metal)]),bone('head',[flatcube([-3.7,6,-5.2],[3,2,1],white),flatcube([.7,6,-5.2],[3,2,1],white),flatcube([-2.1,6.5,-5.8],[1,1,1],black),flatcube([1.1,6.5,-5.8],[1,1,1],black),flatcube([-3,9,-1],[.7,3,.7],black),flatcube([2.3,9,-1],[.7,3,.7],black)]),bone('wheel',[flatcube([-2,0,-2.5],[4,5,5],black),flatcube([-2.2,1,-1.5],[.3,3,3],metal),flatcube([1.9,1,-1.5],[.3,3,3],metal)],[0,2.5,0])],1.5)
animate('motobug',[],{'wheel':{'rotation':['query.anim_time * 720',0,0]},'body':{'position':[0,'math.sin(query.anim_time * 720) * .2',0]}})
shutil.copy2(base/'textures/entity/allay/allay.png',a/'textures/entity/biome/buzz_bomber.png')
blue=solid('buzz_bomber',(34,104,198));yellow=solid('buzz_bomber',(243,221,32));metal=solid('buzz_bomber',(160,168,180));white=solid('buzz_bomber',(245,245,245));black=solid('buzz_bomber',(10,20,28))
model('buzz_bomber',[bone('body',[flatcube([-3,3,-3],[6,5,7],blue),flatcube([-3.1,3,1],[6.2,5.2,1.2],yellow),flatcube([-2,4,4],[4,3,2],blue),flatcube([-.6,5,6],[1.2,1,2],yellow)]),bone('head',[flatcube([-3,4,-5],[6,4,2],blue),flatcube([-2.6,6,-5.5],[2.2,1.5,1],white),flatcube([.4,6,-5.5],[2.2,1.5,1],white),flatcube([-1.7,6,-6],[.8,1,.4],black),flatcube([.9,6,-6],[.8,1,.4],black),flatcube([-2.2,8,-4],[.5,2,.5],yellow),flatcube([1.7,8,-4],[.5,2,.5],yellow)]),bone('cannon',[flatcube([-1,1,-6],[2,2,4],metal),flatcube([-.65,1.3,-6.1],[1.3,1.3,.3],black)]),bone('wing_left',[flatcube([2.8,7,-1],[6,.4,4],white)],[3,7,0]),bone('wing_right',[flatcube([-8.8,7,-1],[6,.4,4],white)],[-3,7,0])],1.5)
p=a/'animations/buzz_bomber.animation.json';anim=json.loads(p.read_text());wing_anim={'wing_left':{'rotation':[0,0,'math.sin(query.anim_time * 1440) * 35']},'wing_right':{'rotation':[0,0,'-math.sin(query.anim_time * 1440) * 35']},'root':{'position':[0,'math.sin(query.anim_time * 180) * .5',0]}}
for name in anim['animations']:anim['animations'][name]['bones']=wing_anim
write(p,anim)
print('Sonic placeholder models replaced: red Motobug carapace/single wheel and blue Buzz Bomber with wings/cannon')
