"""Native GeckoLib meshes with vanilla-compatible UVs; never require OptiFine."""
from pathlib import Path
import json,shutil
from PIL import Image
R=Path(__file__).resolve().parents[1];a=R/'src/main/resources/assets/hinaland';packs=R/'imported-packs';mario=packs/'Super Mario Mash-up/assets/minecraft/textures/entity';omori=next((packs/'OMORI 1.20').rglob('OMORI_Pack_1.20'))/'assets/minecraft/textures/entity'
def cube(o,size,uv):return {'origin':o,'size':size,'uv':uv}
def bone(name,cubes,pivot=[0,0,0],parent='root'):return {'name':name,'parent':parent,'pivot':pivot,'cubes':cubes}
def write(id,src,bones):
 dest=a/'textures/entity/biome'/f'{id}.png';shutil.copy2(src,dest);im=Image.open(dest);w,h=im.size
 model={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.'+id,'texture_width':w,'texture_height':h,'visible_bounds_width':4,'visible_bounds_height':4,'visible_bounds_offset':[0,1,0]},'bones':[{'name':'root','pivot':[0,0,0]}]+bones}]};(a/'geo'/f'{id}.geo.json').write_text(json.dumps(model,indent=2))
 move={b['name']:{'rotation':["math.sin(query.anim_time * 360) * 16",0,0]} for b in bones if any(k in b['name'] for k in ['leg','foot'])}
 anim={'format_version':'1.8.0','animations':{'animation.'+id+'.idle':{'loop':True,'animation_length':1},'animation.'+id+'.walk':{'loop':True,'animation_length':1,'bones':move}}}
 if id=='dry_bones':anim['animations']['animation.dry_bones.collapsed']={'loop':True,'animation_length':1,'bones':{'root':{'rotation':[90,0,0],'position':[0,2,0]}}}
 if id in ['rudinn','hathy']:anim['animations']['animation.'+id+'.walk']['bones']={'root':{'position':[0,'math.abs(math.sin(query.anim_time * 360)) * 1.5',0]}}
 (a/'animations'/f'{id}.animation.json').write_text(json.dumps(anim,indent=2))
write('goomba',mario/'chicken.png',[bone('head',[cube([-2,13,-6],[4,6,3],[0,0])],[0,13,-4]),bone('body',[cube([-3,6,-3],[6,7,6],[0,9])]),bone('leg_left',[cube([0,0,-1],[2,6,2],[26,0])],[1,6,0]),bone('leg_right',[cube([-2,0,-1],[2,6,2],[26,0])],[-1,6,0])])
write('koopa',mario/'sheep/sheep.png',[bone('head',[cube([-3,12,-10],[6,6,8],[0,0])],[0,12,-4]),bone('body',[cube([-4,6,-4],[8,12,6],[28,8])]),*[bone('leg_'+str(i),[cube([x,0,z],[4,6,4],[0,16])],[x+2,6,z+2]) for i,(x,z) in enumerate([(-4,-4),(0,-4),(-4,2),(0,2)])]])
write('pokey',mario/'creeper/creeper.png',[bone('head',[cube([-4,18,-4],[8,8,8],[0,0])],[0,18,0]),bone('body',[cube([-4,6,-2],[8,12,4],[16,16])]),*[bone('leg_'+str(i),[cube([x,0,z],[4,6,4],[0,16])],[x+2,6,z+2]) for i,(x,z) in enumerate([(-4,-4),(0,-4),(-4,0),(0,0)])]])
write('dry_bones',mario/'skeleton/skeleton.png',[bone('head',[cube([-4,24,-4],[8,8,8],[0,0])],[0,24,0]),bone('body',[cube([-4,12,-2],[8,12,4],[16,16])]),bone('arm_left',[cube([4,12,-1],[2,12,2],[40,16])],[5,22,0]),bone('arm_right',[cube([-6,12,-1],[2,12,2],[40,16])],[-5,22,0]),bone('leg_left',[cube([1,0,-1],[2,12,2],[0,16])],[2,12,0]),bone('leg_right',[cube([-3,0,-1],[2,12,2],[0,16])],[-2,12,0])])
write('sprout_mole',omori/'villager/villager.png',[bone('head',[cube([-4,20,-4],[8,10,8],[0,0]),cube([-1,19,-6],[2,4,2],[24,0])],[0,20,0]),bone('body',[cube([-4,8,-3],[8,12,6],[16,20])]),bone('leg_left',[cube([0,0,-2],[4,8,4],[0,22])],[2,8,0]),bone('leg_right',[cube([-4,0,-2],[4,8,4],[0,22])],[-2,8,0])])
write('forest_bunny',omori/'rabbit/brown.png',[bone('body',[cube([-3,3,-2],[6,5,10],[0,0])]),bone('head',[cube([-2.5,7,-6],[5,4,5],[32,0]),cube([-2.5,11,-4],[2,5,1],[52,0]),cube([.5,11,-4],[2,5,1],[52,0])],[0,7,-2]),bone('foot_left',[cube([1,0,2],[2,3,7],[26,24])],[2,3,3]),bone('foot_right',[cube([-3,0,2],[2,3,7],[26,24])],[-2,3,3])])
for id,name in [('rudinn','Rudinn'),('hathy','Hathy')]:
 # Codec conversion of reference game sprites; preserve original pixels and transparency.
 src=R/'research'/f'{name}.gif';im=Image.open(src).convert('RGBA');dest=R/'research'/f'{id}.png';im.save(dest);w,h=im.size
 uv={face:{'uv':[0,0],'uv_size':[w,h]} for face in ['north','south']};uv.update({face:{'uv':[0,0],'uv_size':[0,0]} for face in ['up','down','east','west']})
 write(id,dest,[bone('sprite',[cube([-6,0,-.02],[12,20,.04],uv)])])
print('Eight creature meshes imported; Mario/OMORI pack textures and referenced DELTARUNE sprites')
