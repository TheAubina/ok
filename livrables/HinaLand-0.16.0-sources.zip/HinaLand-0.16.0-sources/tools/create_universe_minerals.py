"""Generate 1.20.1 resources for the registered universe minerals; no original packs required."""
import json,pathlib,re
root=pathlib.Path(__file__).resolve().parents[1];res=root/'src/main/resources';assets=res/'assets/hinaland';data=res/'data/hinaland'
rows=[
 ('mario','star_fragment','moon_shard','Fragment d’étoile','Éclat de lune','Star fragment','Moon shard','gold_ore','diamond_ore','mario_relic','cosmic_crystal'),
 ('sonic','chaos_emerald','phantom_ruby','Émeraude du Chaos','Rubis Fantôme','Chaos Emerald','Phantom Ruby','diamond_ore','redstone_ore','sonic_relic','scarlet_gem'),
 ('omori','dream_glass','heart_stone','Verre de rêve','Pierre du cœur','Dream glass','Heart stone','diamond_ore','redstone_ore','cosmic_crystal','darkner_heart'),
 ('deltarune','dark_crystal','light_shard','Cristal des Ténèbres','Éclat de Lumière','Dark crystal','Light shard','diamond_ore','gold_ore','deltarune_relic','darkner_diamond'),
 ('genshin','crystal_chunk','amethyst_lump','Morceau de cristal','Morceau d’améthyste','Crystal chunk','Amethyst lump','diamond_ore','emerald_ore','cosmic_crystal','genshin_relic'),
 ('overwatch','hardlight_crystal','talon_alloy','Cristal de lumière solide','Alliage de la Griffe','Hard-light crystal','Talon alloy','diamond_ore','iron_ore','cosmic_crystal','rift_ingot'),
 ('lethal','apparatus_core','company_alloy','Noyau d’appareil','Alliage de la Compagnie','Apparatus core','Company alloy','gold_ore','iron_ore','mechanical_core','rift_ingot')]
def write(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def tag(namespace,name,values):
 p=res/f'data/{namespace}/tags/{name}.json';d=json.loads(p.read_text()) if p.exists() else {'replace':False,'values':[]}
 d['values']=list(dict.fromkeys(d['values']+values));write(p,d)
def recipe(name,d):
 write(data/f'recipes/{name}.json',d)
 ingredients=list(d.get('key',{}).values()) or d.get('ingredients') or [d['ingredient']]
 criteria={f'ingredient_{i}':{'trigger':'minecraft:inventory_changed','conditions':{'items':[{'items':[ing['item']]}]}} for i,ing in enumerate(ingredients) if 'item' in ing}
 write(data/f'advancements/recipes/minerals/{name}.json',{'parent':'minecraft:recipes/root','criteria':criteria,'requirements':[list(criteria)],'rewards':{'recipes':['hinaland:'+name]}})
langs={locale:json.loads((assets/f'lang/{locale}.json').read_text()) for locale in ['fr_fr','en_us']};manifest=[]
for f,a,b,afr,bfr,aen,ben,atex,btex,aicon,bicon in rows:
 write(data/f'tags/blocks/needs_{f}_mineral_tool.json', {'replace':False,'values':[]})
 for i,(m,fr,en,tex,icon) in enumerate([(a,afr,aen,atex,aicon),(b,bfr,ben,btex,bicon)]):
  if (assets/f'textures/item/{m}.png').exists():icon=m
  ore=m+'_ore';block=m+'_block';texture='hinaland:block/'+f+'_'+tex
  for name,t in [(ore,texture),(block,'hinaland:block/'+f+('_obsidian' if i==0 else '_bricks'))]:
   write(assets/f'blockstates/{name}.json',{'variants':{'':{'model':'hinaland:block/'+name}}})
   write(assets/f'models/block/{name}.json',{'parent':'minecraft:block/cube_all','textures':{'all':t}})
   write(assets/f'models/item/{name}.json',{'parent':'hinaland:block/'+name})
  write(assets/f'models/item/{m}.json',{'parent':'minecraft:item/generated','textures':{'layer0':'hinaland:item/'+icon}})
  loot=json.loads((data/f'loot_tables/blocks/{f}_diamond_ore.json').read_text())
  children=loot['pools'][0]['entries'][0]['children'];children[0]['name']='hinaland:'+ore;children[1]['name']='hinaland:'+m
  loot['random_sequence']='hinaland:blocks/'+ore;write(data/f'loot_tables/blocks/{ore}.json',loot)
  write(data/f'loot_tables/blocks/{block}.json',{'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'hinaland:'+block}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]})
  tag('minecraft','blocks/mineable/pickaxe',['hinaland:'+ore,'hinaland:'+block]);tag('minecraft','blocks/needs_iron_tool',['hinaland:'+ore,'hinaland:'+block])
  tag('forge','blocks/ores',['hinaland:'+ore]);tag('forge','blocks/ores/'+m,['hinaland:'+ore]);tag('forge','items/ores',['hinaland:'+ore]);tag('forge','items/ores/'+m,['hinaland:'+ore])
  tag('forge','blocks/storage_blocks',['hinaland:'+block]);tag('forge','items/storage_blocks',['hinaland:'+block]);tag('forge','items/gems' if i==0 else 'items/materials',['hinaland:'+m])
  feature=m+'_veins';targets=[{'target':{'predicate_type':'minecraft:block_match','block':host},'state':{'Name':'hinaland:'+ore}} for host in ['hinaland:'+f+'_stone','minecraft:stone','minecraft:deepslate']]
  write(data/f'worldgen/configured_feature/{feature}.json',{'type':'minecraft:ore','config':{'size':5 if i==0 else 7,'discard_chance_on_air_exposure':0.0,'targets':targets}})
  write(data/f'worldgen/placed_feature/{feature}.json',{'feature':'hinaland:'+feature,'placement':[{'type':'minecraft:count','count':3 if i==0 else 5},{'type':'minecraft:in_square'},{'type':'minecraft:height_range','height':{'type':'minecraft:uniform','min_inclusive':{'absolute':-60 if i==0 else -48},'max_inclusive':{'absolute':16 if i==0 else 64}}},{'type':'minecraft:biome'}]})
  for suffix in ['', '_forest','_highlands','_dunes']:
   p=data/f'worldgen/biome/{f}{suffix}.json';biome=json.loads(p.read_text());step=biome['features'][6];ref='hinaland:'+feature
   if ref not in step:step.append(ref)
   write(p,biome)
  recipe(block,{'type':'minecraft:crafting_shaped','pattern':['MMM','MMM','MMM'],'key':{'M':{'item':'hinaland:'+m}},'result':{'item':'hinaland:'+block}})
  recipe(m+'_from_block',{'type':'minecraft:crafting_shapeless','ingredients':[{'item':'hinaland:'+block}],'result':{'item':'hinaland:'+m,'count':9}})
  for kind,time in [('smelting',200),('blasting',100)]:recipe(m+'_'+kind,{'type':'minecraft:'+kind,'ingredient':{'item':'hinaland:'+ore},'result':'hinaland:'+m,'experience':0.7,'cookingtime':time})
  langs['fr_fr'].update({'item.hinaland.'+m:fr,'block.hinaland.'+ore:'Minerai — '+fr,'block.hinaland.'+block:'Bloc — '+fr})
  langs['en_us'].update({'item.hinaland.'+m:en,'block.hinaland.'+ore:en+' ore','block.hinaland.'+block:en+' block'})
  manifest.append({'family':f,'material':m,'name_fr':fr,'ore_texture':texture,'item_texture':'hinaland:item/'+icon,'size':5 if i==0 else 7,'attempts_per_chunk':3 if i==0 else 5,'min_y':-60 if i==0 else -48,'max_y':16 if i==0 else 64})
 for tool,pattern in [('pickaxe',['AAA',' B ',' S ']),('sword',[' B ',' B ',' A '])]:
  name=f+'_mineral_'+tool;keys={'A':{'item':'hinaland:'+a},'B':{'item':'hinaland:'+b}}
  if tool=='pickaxe':keys['S']={'item':'minecraft:stick'}
  recipe(name,{'type':'minecraft:crafting_shaped','pattern':pattern,'key':keys,'result':{'item':'hinaland:'+name}})
  icon=name if (assets/f'textures/item/{name}.png').exists() else ('rift_pickaxe' if tool=='pickaxe' else 'rift_blade');write(assets/f'models/item/{name}.json',{'parent':'minecraft:item/handheld','textures':{'layer0':'hinaland:item/'+icon}})
  langs['fr_fr']['item.hinaland.'+name]=('Pioche' if tool=='pickaxe' else 'Épée')+' — '+afr
  langs['en_us']['item.hinaland.'+name]=aen+(' pickaxe' if tool=='pickaxe' else ' sword')
 recipe(f+'_essence_from_minerals',{'type':'minecraft:crafting_shapeless','ingredients':[{'item':'hinaland:'+a},{'item':'hinaland:'+b}],'result':{'item':'hinaland:'+f+'_essence','count':2}})
for locale,d in langs.items():write(assets/f'lang/{locale}.json',d)
write(root/'universe-minerals-0.12.json',manifest)
print('14 minerals, 14 storage blocks, 14 tools, 77 recipes and unlock advancements; 28 biomes updated')
