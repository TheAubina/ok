"""Question glyphs are model geometry: supplied low-resolution block art stays on the atlas."""
import pathlib,json,shutil
r=pathlib.Path(__file__).resolve().parents[1];a=r/'src/main/resources/assets/hinaland';native=r/'imported-packs/Super Mario Mash-up/assets/minecraft/textures'
shutil.copy2(native/'block/gold_block.png',a/'textures/block/mario_bonus_gold.png')
def faces(tex):return {f:{'texture':tex,'uv':[0,0,16,16]} for f in ['north','south','east','west','up','down']}
elements=[{'from':[0,0,0],'to':[16,16,16],'faces':{f:{**v,'cullface':f} for f,v in faces('#gold').items()}}]
glyph=['.###.','#...#','....#','..##.','..#..','.....','..#..']
for row,line in enumerate(glyph):
 for col,char in enumerate(line):
  if char!='#':continue
  x=5+col*1.2;y=12-row*1.2
  for lo,hi in [([x,y,-.02],[x+1.2,y+1.2,.08]),([16-x-1.2,y,15.92],[16-x,y+1.2,16.02]),([-.02,y,16-x-1.2],[.08,y+1.2,16-x]),([15.92,y,x],[16.02,y+1.2,x+1.2])]:elements.append({'from':lo,'to':hi,'faces':faces('#mark')})
model={'textures':{'gold':'hinaland:block/mario_bonus_gold','mark':'minecraft:block/quartz_block_top','particle':'hinaland:block/mario_bonus_gold'},'elements':elements}
(a/'models/block/mario_question_block.json').write_text(json.dumps(model,indent=2)+'\n')
# The generated illustration is retained in /workspace/generated_images; it is not needed on the game atlas.
p=a/'textures/block/mario_question.png'
if p.exists():p.unlink()
for name,relative in [('mario_coin','item/gold_nugget.png'),('mario_super_mushroom','block/red_mushroom.png')]:
 p=native/relative
 if p.exists():
  shutil.copy2(p,a/f'textures/item/{name}.png');(a/f'models/item/{name}.json').write_text(json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':'hinaland:item/'+name}},indent=2)+'\n')
print('Low-resolution supplied Mario textures; readable four-sided question glyph; no large texture atlas penalty')
