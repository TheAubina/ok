"""Inspect saved FULL chunks: actual new structures, template blocks, chests and supported foundations."""
import pathlib,json,sys,collections
from read_region import chunks
import nbtlib
r=pathlib.Path(__file__).resolve().parents[1];manifest=json.loads((r/'universe-structures-0.15.json').read_text());wanted={x['structure']:x for x in manifest['structures']}
world=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);cache={(int(c['xPos']),int(c['zPos'])):c for c in chunks(world) if str(c.get('Status')) in ['minecraft:full','full']}
def state(x,y,z):
 c=cache.get((x//16,z//16));assert c is not None,('missing FULL chunk',x,y,z)
 section=next((s for s in c['sections'] if int(s['Y'])==y//16),None)
 if section is None or 'block_states' not in section:return 'minecraft:air'
 bs=section['block_states'];palette=bs['palette']
 if len(palette)==1:return str(palette[0]['Name'])
 bits=max(4,(len(palette)-1).bit_length());per=64//bits;index=(y%16)*256+(z%16)*16+x%16;packed=int(bs['data'][index//per])&((1<<64)-1);return str(palette[(packed>>((index%per)*bits))&((1<<bits)-1)]['Name'])
def rotate(p,rotation):
 x,y,z=p
 return {'NONE':(x,y,z),'CLOCKWISE_90':(-z,y,x),'CLOCKWISE_180':(-x,y,-z),'COUNTERCLOCKWISE_90':(z,y,-x)}[rotation]
rows=[]
for c in cache.values():
 for identifier,start in c.get('structures',{}).get('starts',{}).items():
  name=identifier.split(':')[-1]
  if name not in wanted or str(start.get('id'))=='INVALID':continue
  for piece in start['Children']:
   anchor=tuple(int(piece[k]) for k in ['TPX','TPY','TPZ']);rotation=str(piece['HinaRotation']);template=nbtlib.load(r/f'src/main/resources/data/hinaland/structures/{name}.nbt');palette=template['palette'];checked=0;support=0
   for block in template['blocks']:
    local=tuple(map(int,block['pos']));rx,ry,rz=rotate(local,rotation);pos=(anchor[0]+rx,anchor[1]+ry,anchor[2]+rz);expected=str(palette[int(block['state'])]['Name']);actual=state(*pos)
    # Ore decoration runs after surface structures and can replace their buried native-rock layers.
    ore_in_basal_rock=local[1]<2 and expected=='hinaland:'+wanted[name]['family']+'_stone' and (actual.endswith('_ore') or actual=='hinaland:'+wanted[name]['family']+'_gravel')
    assert actual==expected or ore_in_basal_rock,(name,pos,expected,actual);checked+=1
    if local[1]==0:
     below=state(pos[0],pos[1]-1,pos[2]);assert below not in ['minecraft:air','minecraft:cave_air','minecraft:water','minecraft:lava'],(name,'floating foundation',pos,below);support+=1
   rows.append({'structure':identifier,'family':wanted[name]['family'],'owner_chunk':[int(c['xPos']),int(c['zPos'])],'anchor':anchor,'rotation':rotation,'bounding_box':list(map(int,piece['BB'])),'matched_template_blocks':checked,'supported_foundation_columns':support,'natural':True})
result={'seed':20261015,'full_chunks_read':len(cache),'natural_structures_checked':len(rows),'families_checked':sorted(set(x['family'] for x in rows)),'structures':rows}
assert len(result['families_checked'])==7,result
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
