"""Read public download bodies completely and compare against the local delivery manifest."""
import json,pathlib,sys,hashlib,urllib.request,urllib.parse,concurrent.futures
r=pathlib.Path(__file__).resolve().parents[1];version=sys.argv[1] if len(sys.argv)>1 else '0.14';manifest=json.loads((r/f'deliverables-{version}.json').read_text())
def verify(entry):
 url='https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/'+urllib.parse.quote(entry['file']);h=hashlib.sha256();size=0
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'HinaLand-Release-Verification'}),timeout=45) as resp:
  status=resp.status;final=resp.url
  while data:=resp.read(1024*1024):h.update(data);size+=len(data)
 result={'file':entry['file'],'url':url,'final_url':final,'http_status':status,'bytes':size,'sha256':h.hexdigest(),'matches':size==entry['bytes'] and h.hexdigest()==entry['sha256']}
 assert status==200 and result['matches'],result
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(verify,manifest))
(r/f'downloads-{version}-verified.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
