"""Generate 32 additional native GeckoLib creatures from supplied palette art and audited game sprites.
No supplied archive scripts are run; PNGs are copied unchanged or converted losslessly from source GIF frames.
"""
import pathlib,json,re,shutil,sys
from PIL import Image
r=pathlib.Path(__file__).resolve().parents[1];a=r/'src/main/resources/assets/hinaland';d=r/'src/main/resources/data/hinaland'
specs=[dict(id=m[0],family=m[1],name_fr=m[2],behavior=m[3],health=float(m[4]),width=float(m[5]),height=float(m[6])) for m in re.findall(r'new Spec\("([^"]+)","([^"]+)","([^"]+)","([^"]+)",([\d.]+),([\d.]+)f,([\d.]+)f\)',(r/'src/main/java/fr/hinaland/CreatureExpansion.java').read_text())];assert len(specs)==32
packs=r/'imported-packs';mario=packs/'Super Mario Mash-up/assets/minecraft';sonic=packs/'sonic-the-hedgehog/assets/minecraft';omori=packs/'OMORI 1.20/OMORI 1.20/OMORI_Pack_1.20/assets/minecraft'
textures={'bobomb':mario/'textures/entity/blaze.png','boo':mario/'textures/entity/ghast/ghast.png','shy_guy':mario/'textures/entity/enderman/enderman.png','magikoopa':mario/'textures/entity/witch.png','hammer_bro':mario/'textures/entity/zombie/zombie.png','piranha_plant':mario/'textures/entity/cow/red_mooshroom.png','monty_mole':mario/'textures/entity/wolf/wolf.png','spiny':mario/'textures/entity/turtle/big_sea_turtle.png','crabmeat':sonic/'optifine/cem/skeleton.png','caterkiller':sonic/'optifine/cem/vex.png','newtron':sonic/'optifine/cem/creeper.png','egg_pawn':sonic/'textures/entity/iron_golem/iron_golem.png','ye_old_sprout':omori/'textures/entity/villager/villager.png'}
sprites=json.loads((r/'audit-0.16/references/sprites.json').read_text());spriteids={x['id'] for x in sprites};frames={}
def write(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def nearest(path,rgb):
 im=Image.open(path).convert('RGBA');options=[(sum((c[j]-rgb[j])**2 for j in range(3)),x,y) for y in range(im.height) for x in range(im.width) if (c:=im.getpixel((x,y)))[3]>200];_,x,y=min(options)
 return {f:{'uv':[x,y],'uv_size':[1,1]} for f in ['north','south','west','east','up','down']}
def c(o,s,uv):return {'origin':o,'size':s,'uv':uv}
def bone(name,cubes,pivot=None):return {'name':name,'parent':'root','pivot':pivot or [0,0,0],'cubes':cubes}
manifest=[]
for row in specs:
 id=row['id'];family=row['family'];target=a/f'textures/entity/biome/{id}.png';materials={}
 if id in spriteids:
  src=r/f'research/creatures-0.16/{id}.gif';src=src if src.exists() else r/f'research/creatures-0.16/{id}.png';im=Image.open(src);count=getattr(im,'n_frames',1);frames[id]=count
  for i in range(count):im.seek(i);im.convert('RGBA').save(a/f'textures/entity/biome/{id}_frame_{i}.png')
  shutil.copy2(a/f'textures/entity/biome/{id}_frame_0.png',target);w,h=Image.open(target).size;height=row['height']*16;width=height*w/h;uv={face:{'uv':[0,0],'uv_size':[w,h]} for face in ['north','south']};uv.update({face:{'uv':[0,0],'uv_size':[0,0]} for face in ['west','east','up','down']});bones=[bone('sprite',[c([-width/2,0,-.04],[width,height,.08],uv)])];source=str(src.relative_to(r));mode='Animated original game sprite plane; complete GIF frames retained'
 else:
  if family in ['genshin','overwatch']:
   palette={'wood':a/f'textures/block/{family}_oak_log.png','white':a/f'textures/block/{"white_iron" if family=="genshin" else "omnic_steel"}_block.png','black':a/f'textures/block/{family}_obsidian.png','red':a/f'textures/block/{family}_netherrack.png','blue':a/f'textures/block/{family}_diamond_ore.png','metal':a/f'textures/block/{"white_iron" if family=="genshin" else "omnic_steel"}_block.png','orange':a/f'textures/block/{family}_pumpkin_side.png'}
   for style,p in palette.items():shutil.copy2(p,a/f'textures/entity/biome/{id}_{style}.png');materials[style]=str(p.relative_to(r))
   src=palette['metal'];shutil.copy2(src,target)
  else:src=textures[id];shutil.copy2(src,target)
  source=str(src.relative_to(r));mode='Original voxel mesh; colours sampled from unchanged supplied art'
  def uv(rgb,style=None):return nearest(a/f'textures/entity/biome/{id}_{style}.png' if style else target,rgb)
  black=uv((15,15,20),'black' if materials else None);white=uv((245,245,240),'white' if materials else None);red=uv((210,32,35),'red' if materials else None);blue=uv((50,125,215),'blue' if materials else None);yellow=uv((232,185,45),'orange' if materials else None);brown=uv((112,73,44),'wood' if materials else None);metal=uv((150,154,160),'metal' if materials else None);green=uv((40,160,35));bones=[]
  def add(name,cubes,pivot=None):bones.append(bone(name,cubes,pivot))
  if id=='bobomb':
   add('body',[c([-4,3,-4],[8,8,8],black)]);add('eyes',[c([-2.5,7,-4.2],[1.5,3,.4],white),c([1,7,-4.2],[1.5,3,.4],white)]);add('fuse',[c([-.5,11,-.5],[1,3,1],white)]);add('key',[c([-.5,6,4],[1,4,2],yellow)]);add('leg_left',[c([.3,0,-3],[3,3,5],blue)],[2,3,0]);add('leg_right',[c([-3.3,0,-3],[3,3,5],blue)],[-2,3,0])
  elif id=='boo':
   add('body',[c([-6,2,-5],[12,11,10],white),c([-2,1,4],[4,3,3],white)]);add('eyes',[c([-3,8,-5.2],[1,2,.3],black),c([2,8,-5.2],[1,2,.3],black)]);add('mouth',[c([-2.5,4,-5.2],[5,3,.3],black),c([-.8,3,-5.5],[1.6,2,.5],red)]);add('arm_left',[c([6,5,-1],[3,3,2],white)],[6,6,0]);add('arm_right',[c([-9,5,-1],[3,3,2],white)],[-6,6,0])
  elif id in ['shy_guy','magikoopa','hammer_bro','hilichurl','egg_pawn','null_trooper','null_eradicator','ruin_guard']:
   h=row['height']*16;legs=h*.32;torso=h*.4;top=legs+torso;colour=red if id in ['shy_guy','egg_pawn'] else blue if id=='magikoopa' else brown if id in ['hilichurl','ruin_guard'] else green if id=='hammer_bro' else metal
   style='_wood' if id in ['hilichurl','ruin_guard'] else '_metal' if materials else ''
   add('body'+style,[c([-4,legs,-2.5],[8,torso,5],colour)]);add('head'+('_wood' if id=='hilichurl' else '_metal' if materials else ''),[c([-4,top,-3],[8,h-top,6],colour)],[0,top,0])
   add('leg_left'+style,[c([.5,0,-2],[3,legs,4],colour)],[2,legs,0]);add('leg_right'+style,[c([-3.5,0,-2],[3,legs,4],colour)],[-2,legs,0]);add('arm_left'+style,[c([4,legs+1,-1.5],[2.5,torso-1,3],colour)],[5,top-1,0]);add('arm_right'+style,[c([-6.5,legs+1,-1.5],[2.5,torso-1,3],colour)],[-5,top-1,0])
   if id in ['shy_guy','hilichurl']:
    add('mask'+('_white' if materials else ''),[c([-3.5,top+.5,-3.3],[7,h-top-1,.5],white)]);add('eyes'+('_black' if materials else ''),[c([-2.2,top+2,-3.9],[1.3,1.5,.3],black),c([.9,top+2,-3.9],[1.3,1.5,.3],black),c([-.5,top+.7,-3.9],[1,.6,.3],black)])
   else:add('eyes'+('_orange' if materials else ''),[c([-2.5,top+2,-3.3],[2,1.5,.4],yellow),c([.5,top+2,-3.3],[2,1.5,.4],yellow)])
   if id=='hilichurl':add('horns_white',[c([-5,top+3,-1],[1.5,3,2],white),c([3.5,top+3,-1],[1.5,3,2],white)]);add('club_wood',[c([-7,legs,-1],[1,7,1],brown),c([-8.5,legs+5,-2.5],[4,5,4],brown)])
   if id=='magikoopa':add('hat',[c([-5,h-1,-4],[10,1,8],blue),c([-3,h,-2],[6,3,4],blue),c([-1.5,h+3,-1],[3,2,2],blue)]);add('wand',[c([-7,legs,-2],[1,7,1],brown),c([-8,legs+6,-3],[3,3,3],yellow)])
   if id=='hammer_bro':add('shell',[c([-5,legs,2],[10,torso,3],green)]);add('hammer',[c([-8,legs,-2],[1,7,1],brown),c([-10,legs+6,-3],[5,3,3],metal)])
   if id=='ruin_guard':add('core_orange',[c([-1.5,top+1,-3.7],[3,2,1],yellow)]);add('shoulders_metal',[c([-8,top-5,-2],[5,5,5],metal),c([3,top-5,-2],[5,5,5],metal)]);add('back_wood',[c([-5,legs+3,2],[10,10,4],brown)])
   if id=='null_eradicator':add('shield_metal',[c([4,legs,-3],[5,torso,3],metal)])
   if id in ['egg_pawn','null_trooper']:add('gun'+('_black' if materials else ''),[c([-7,legs+3,-6],[3,3,6],black)])
  elif id=='piranha_plant':
   add('stem',[c([-1.5,0,-1.5],[3,11,3],green),c([-6,4,-.5],[5,2,1],green),c([1,6,-.5],[5,2,1],green)]);add('head',[c([-5,11,-4],[10,8,8],red),c([-5,12,-4.2],[10,3,.4],white),c([-4,13,-4.7],[8,1,.5],black),c([-3,16,-4.3],[2,1.5,.2],white),c([1,17,-4.3],[2,1,.2],white)],[0,11,0])
  elif id in ['monty_mole','spiny','ye_old_sprout','pyro_slime','cryo_slime','null_detonator']:
   h=row['height']*16;style='_red' if id=='pyro_slime' else '_blue' if id=='cryo_slime' else '_metal' if materials else '';col=red if id in ['spiny','pyro_slime'] else blue if id=='cryo_slime' else metal if id=='null_detonator' else brown
   add('body'+style,[c([-5,2,-4],[10,h-2,8],col)]);add('eyes'+('_black' if materials else ''),[c([-3,6,-4.3],[2,2,.4],black),c([1,6,-4.3],[2,2,.4],black)])
   if id in ['monty_mole','ye_old_sprout']:add('belly',[c([-4,2,-4.2],[8,4,.3],white)]);add('nose',[c([-1,5,-5],[2,2,1],black)])
   if id=='ye_old_sprout':add('leaf',[c([-1,h,-.5],[2,3,1],green),c([-4,h+2,-.5],[8,1,1],green)]);add('beard',[c([-3.5,4,-4.8],[7,3,.5],white)])
   if id=='spiny':
    for x,z in [(-4,-3),(4,-3),(-4,3),(4,3),(0,0)]:add('spike_'+str(x)+'_'+str(z),[c([x-.5,h-1,z-.5],[1,3,1],white)])
   if id=='null_detonator':add('fuse_orange',[c([-2,h,-2],[4,2,4],yellow)])
   for i,x in enumerate([-3.5,1]):add('leg_'+str(i)+style,[c([x,0,-3],[2.5,2,5],col)],[x+1,2,0])
  elif id in ['crabmeat','caterkiller','newtron','null_slicer']:
   col=red if id=='crabmeat' else blue if id=='caterkiller' else green if id=='newtron' else metal;style='_metal' if materials else ''
   if id=='caterkiller':
    for i in range(4):add('segment_'+str(i),[c([-3,1,i*4-6],[6,6,4],col),c([-3.3,6,i*4-6],[6.6,1,4],yellow)],[0,2,i*4-4])
    add('head',[c([-3,4,-9],[6,5,3],col),c([-2.5,6,-9.2],[2,2,.4],white),c([.5,6,-9.2],[2,2,.4],white)])
   else:
    add('body'+style,[c([-4,3,-3],[8,5,7],col)]);add('head'+style,[c([-3,6,-5],[6,4,3],col)]);add('eyes'+('_orange' if materials else ''),[c([-2.5,8,-5.3],[2,2,.4],yellow if materials else white),c([.5,8,-5.3],[2,2,.4],yellow if materials else white)])
    for i,(x,z) in enumerate([(-5,-1),(3,-1),(-5,4),(3,4)]):add('leg_'+str(i)+style,[c([x,0,z],[2,4,2],col)],[x+1,4,z+1])
    if id=='crabmeat':
     for x in [-9,6]:add('claw_'+str(x),[c([x,4,-4],[3,5,3],red),c([x,8,-5],[1,3,4],red),c([x+2,8,-5],[1,3,4],red)])
    if id=='newtron':add('tail',[c([-1,3,4],[2,2,5],green)])
  else:raise ValueError(id)
  # Fit supplied reinterpretations to the registered creature's intended height, preserving sampled UVs.
  highest=max(v['origin'][1]+v['size'][1] for b in bones for v in b['cubes']);scale=row['height']*16/highest
  for b in bones:
   b['pivot']=[v*scale for v in b['pivot']]
   for cube in b['cubes']:cube['origin']=[v*scale for v in cube['origin']];cube['size']=[v*scale for v in cube['size']]
 w,h=Image.open(target).size;description={'identifier':'geometry.'+id,'texture_width':w,'texture_height':h,'visible_bounds_width':4,'visible_bounds_height':max(3,row['height']+1),'visible_bounds_offset':[0,row['height']/2,0]}
 write(a/f'geo/{id}.geo.json',{'format_version':'1.12.0','minecraft:geometry':[{'description':description,'bones':[{'name':'root','pivot':[0,0,0]}]+bones}]})
 legs=[b['name'] for b in bones if any(s in b['name'] for s in ['leg','arm'])];walk={name:{'rotation':[f'math.sin(query.anim_time * 360 + {i%2*180}) * 20',0,0]} for i,name in enumerate(legs)}
 if id in spriteids:walk['root']={'position':[0,'math.abs(math.sin(query.anim_time * 360)) * 1',0]}
 if id=='caterkiller':walk.update({b['name']:{'rotation':[0,'math.sin(query.anim_time * 180) * 8',0]} for b in bones if b['name'].startswith('segment')})
 animations={f'animation.{id}.{state}':{'loop':True,'animation_length':1,'bones':{'root':{'rotation':[0,0,'math.sin(query.anim_time * 180) * 1.5']}}} for state in ['idle','armed','stunned','frozen','burrowed']};animations[f'animation.{id}.walk']={'loop':True,'animation_length':1,'bones':walk};animations[f'animation.{id}.armed']['bones']={'root':{'scale':['1 + math.sin(query.anim_time * 720) * .05',1,1]}};animations[f'animation.{id}.stunned']['bones']={'root':{'rotation':[0,0,12]}};animations[f'animation.{id}.burrowed']['bones']={'root':{'scale':[.01,.01,.01]}}
 if id=='boo':animations['animation.boo.frozen']['bones']={'arm_left':{'rotation':[0,0,70]},'arm_right':{'rotation':[0,0,-70]}}
 write(a/f'animations/{id}.animation.json',{'format_version':'1.8.0','animations':animations})
 write(a/f'models/item/spawn_{id}.json',{'parent':'minecraft:item/template_spawn_egg'})
 write(d/f'loot_tables/entities/{id}.json',{'type':'minecraft:entity','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'hinaland:'+family+'_essence','functions':[{'function':'minecraft:set_count','count':{'type':'minecraft:uniform','min':1,'max':2}}]}]}]})
 row.update({'source':source,'model_kind':mode,'palette_materials':materials,'frames':frames.get(id,1)});manifest.append(row)
# Explicit natural tables contain only mod-owned monsters; passive vanilla animals are preserved.
for f in ['mario','sonic','omori','deltarune','genshin','overwatch','lethal']:
 for suffix in ['', '_forest','_highlands','_dunes']:
  p=d/f'worldgen/biome/{f}{suffix}.json';obj=json.loads(p.read_text());old=[x for x in obj['spawners']['monster'] if not x['type'].startswith('minecraft:') and x['type'].split(':')[1] not in {x['id'] for x in specs}]
  obj['spawners']['monster']=old+[{'type':'hinaland:'+x['id'],'weight':3 if x['id'] in ['something','ruin_guard','null_eradicator','null_detonator'] else 9,'minCount':1,'maxCount':1 if x['id'] in ['something','ruin_guard','null_eradicator','null_detonator'] else 2} for x in specs if x['family']==f];write(p,obj)
# Rename visible Mario costumes independently from the mineral used to craft/repair them.
for locale in ['fr_fr','en_us']:
 p=a/f'lang/{locale}.json';lang=json.loads(p.read_text());parts={'helmet':'Capuche','chestplate':'Combinaison','leggings':'Pantalon','boots':'Bottes'} if locale=='fr_fr' else {'helmet':'Hood','chestplate':'Suit','leggings':'Trousers','boots':'Boots'}
 for material,fr,en in [('superbell_bronze','costume Grenouille','Frog Suit'),('fireflower_amber','costume Pingouin','Penguin Suit')]:
  for piece,label in parts.items():lang['item.hinaland.'+material+'_'+piece]=label+' — '+(fr if locale=='fr_fr' else en)
 for row in specs:lang['entity.hinaland.'+row['id']]=row['name_fr'] if locale=='fr_fr' else row['id'].replace('_',' ').title();lang['item.hinaland.spawn_'+row['id']]=('Œuf — ' if locale=='fr_fr' else 'Spawn ')+(row['name_fr'] if locale=='fr_fr' else row['id'].replace('_',' ').title())
 lang['item.hinaland.mario_hammer']='Marteau à lancer' if locale=='fr_fr' else 'Throwable hammer';write(p,lang)
# A real throwable/craftable hammer; native block textures provide its shaft and metal head.
faces={side:{'uv':[0,0,16,16],'texture':'#shaft'} for side in ['north','south','east','west','up','down']};headfaces={side:{'uv':[0,0,16,16],'texture':'#head'} for side in faces}
write(a/'models/item/mario_hammer.json',{'parent':'minecraft:item/handheld','textures':{'shaft':'hinaland:block/mario_oak_planks','head':'hinaland:block/mario_stone_bricks'},'elements':[{'from':[7,0,7],'to':[9,11,9],'faces':faces},{'from':[3,10,5],'to':[13,14,11],'faces':headfaces}]})
write(d/'recipes/mario_hammer.json',{'type':'minecraft:crafting_shaped','pattern':['III',' S ',' S '],'key':{'I':{'item':'minecraft:iron_ingot'},'S':{'item':'minecraft:stick'}},'result':{'item':'hinaland:mario_hammer','count':2}})
# Texture frame counts drive native renderer animation, not OptiFine.
p=r/'src/main/java/fr/hinaland/CreatureExpansion.java';text=p.read_text();line=' public static final Map<String,Integer> SPRITE_FRAMES=Map.ofEntries('+','.join('Map.entry("'+k+'",'+str(v)+')' for k,v in frames.items())+');'
text=re.sub(r' public static final Map<String,Integer> SPRITE_FRAMES=.*?;\n','',text);text=text.replace(' public record Spec(',line+'\n public record Spec(');p.write_text(text)
write(r/'creature-expansion-0.16.json',{'new_creatures':manifest,'count':32,'total_hinaland_creatures':50,'costume_corrections':{'superbell_bronze':'Frog Suit / costume Grenouille','fireflower_amber':'Penguin Suit / costume Pingouin'},'passive_vanilla_preserved':True})
print('32 new creatures, 50 total; 11 animated original game sprite planes; voxel interpretations and supplied palette textures; vanilla hostile tables removed.')
