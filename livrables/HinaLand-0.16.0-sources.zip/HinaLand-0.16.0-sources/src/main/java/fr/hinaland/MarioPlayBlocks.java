package fr.hinaland;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.effect.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.RegistryObject;

/** Server-owned one-shot reward blocks: click, punch, or bump them while jumping. */
@Mod.EventBusSubscriber(modid=HinaLand.ID)
public final class MarioPlayBlocks {
 public static RegistryObject<Block> QUESTION,USED;
 private record Jump(double y,long ascending){}
 private static final Map<UUID,Jump> JUMPS=new HashMap<>();
 public static void register(){
  USED=HinaLand.BLOCKS.register("mario_used_bonus_block",()->new Block(BlockBehaviour.Properties.copy(Blocks.BRICKS)));
  QUESTION=HinaLand.BLOCKS.register("mario_question_block",()->new QuestionBlock());
  for(var entry:Map.of("mario_question_block",QUESTION,"mario_used_bonus_block",USED).entrySet()){
   HinaLand.WORLD_BLOCKS.put(entry.getKey(),entry.getValue());HinaLand.ALL.put(entry.getKey(),HinaLand.ITEMS.register(entry.getKey(),()->new BlockItem(entry.getValue().get(),new Item.Properties())));
  }
  HinaLand.ALL.put("mario_coin",HinaLand.ITEMS.register("mario_coin",()->new Item(new Item.Properties())));
  HinaLand.ALL.put("mario_super_mushroom",HinaLand.ITEMS.register("mario_super_mushroom",()->new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(6).saturationMod(.8f).alwaysEat().effect(()->new MobEffectInstance(MobEffects.ABSORPTION,600,0),1).build()))));
 }
 public static boolean activate(Level level,BlockPos pos){
  if(level.isClientSide||!level.getBlockState(pos).is(QUESTION.get()))return false;
  // Replace before emitting rewards: repeated clicks, save/reload and breaking cannot duplicate them.
  level.setBlock(pos,USED.get().defaultBlockState(),3);
  var reward=switch(level.random.nextInt(4)){case 0->new ItemStack(HinaLand.item("mario_super_mushroom"));case 1->new ItemStack(HinaLand.item("superbell_bronze"));default->new ItemStack(HinaLand.item("mario_coin"),1+level.random.nextInt(3));};
  Block.popResource(level,pos.below(),reward);level.playSound(null,pos,SoundEvents.EXPERIENCE_ORB_PICKUP,SoundSource.BLOCKS,.8f,1.3f);
  ((ServerLevel)level).sendParticles(ParticleTypes.END_ROD,pos.getX()+.5,pos.getY()+1.2,pos.getZ()+.5,8,.2,.2,.2,.02);return true;
 }
 public static final class QuestionBlock extends Block {
  public QuestionBlock(){super(BlockBehaviour.Properties.copy(Blocks.BRICKS).lightLevel(s->5));}
  @Override public InteractionResult use(BlockState state,Level level,BlockPos pos,Player player,InteractionHand hand,BlockHitResult hit){
   if(hand!=InteractionHand.MAIN_HAND)return InteractionResult.PASS;
   if(!level.isClientSide)activate(level,pos);return InteractionResult.sidedSuccess(level.isClientSide);
  }
  @Override public void attack(BlockState state,Level level,BlockPos pos,Player player){activate(level,pos);}
 }
 @SubscribeEvent public static void bump(TickEvent.PlayerTickEvent event){
  if(event.phase!=TickEvent.Phase.END||event.player.level().isClientSide)return;
  var player=event.player;long now=player.level().getGameTime();var last=JUMPS.get(player.getUUID());
  long ascending=last!=null&&player.getY()>last.y()+.001?now:last==null?now-100:last.ascending();
  if(last!=null&&!player.onGround()&&now-ascending<=3){
   var head=BlockPos.containing(player.getX(),player.getBoundingBox().maxY+.05,player.getZ());activate(player.level(),head);
  }
  JUMPS.put(player.getUUID(),new Jump(player.getY(),ascending));
 }
 @SubscribeEvent public static void logout(net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent event){JUMPS.remove(event.getEntity().getUUID());}
}
