package fr.hinaland.test;
import fr.hinaland.*;
import java.util.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.portal.PortalShape;
import net.minecraft.world.level.levelgen.structure.templatesystem.*;
import net.minecraftforge.gametest.*;

@GameTestHolder("hinaland") @PrefixGameTestTemplate(false)
public class PolishGameTests {
 private static TransientCraftingContainer grid(){return new TransientCraftingContainer(new AbstractContainerMenu(null,-1){
  @Override public ItemStack quickMoveStack(net.minecraft.world.entity.player.Player p,int slot){return ItemStack.EMPTY;}
  @Override public boolean stillValid(net.minecraft.world.entity.player.Player p){return true;}
 },3,3);}
 private static void craft(GameTestHelper h,CraftingContainer grid,String id,int count){
  var recipe=h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,grid,h.getLevel()).orElseThrow();var out=recipe.assemble(grid,h.getLevel().registryAccess());h.assertTrue(out.is(HinaLand.item(id))&&out.getCount()==count,"Actual grid crafts "+id);
 }
 @GameTest(template="test_empty",timeoutTicks=100)
 public static void allExpandedEquipmentRecipes(GameTestHelper h){
  var patterns=Map.of("pickaxe",List.of("MMM"," S "," S "),"sword",List.of(" M "," M "," S "),"axe",List.of("MM ","MS "," S "),"helmet",List.of("MMM","M M"),"chestplate",List.of("M M","MMM","MMM"),"leggings",List.of("MMM","M M","M M"),"boots",List.of("M M","M M"));var grid=grid();
  h.assertTrue(ExpandedMinerals.MATERIALS.size()==21,"Three additional materials per seven families");
  for(var m:ExpandedMinerals.MATERIALS){
   for(var pattern:patterns.entrySet()){
    grid.clearContent();for(int y=0;y<pattern.getValue().size();y++)for(int x=0;x<3;x++){char c=pattern.getValue().get(y).charAt(x);if(c!=' ')grid.setItem(y*3+x,new ItemStack(c=='M'?HinaLand.item(m.id()):Items.STICK));}
    craft(h,grid,m.id()+"_"+pattern.getKey(),1);
   }
   grid.clearContent();for(int i=0;i<9;i++)grid.setItem(i,new ItemStack(HinaLand.item(m.id())));craft(h,grid,m.id()+"_block",1);
   grid.clearContent();grid.setItem(0,new ItemStack(HinaLand.item(m.id()+"_block")));craft(h,grid,m.id(),9);
   var input=new net.minecraft.world.SimpleContainer(new ItemStack(HinaLand.item(m.id()+"_ore")));
   for(var type:List.of(RecipeType.SMELTING,RecipeType.BLASTING)){
    var recipe=h.getLevel().getRecipeManager().getRecipeFor(type,input,h.getLevel()).orElseThrow();h.assertTrue(recipe.assemble(input,h.getLevel().registryAccess()).is(HinaLand.item(m.id())),"Furnace produces correct universe resource");
   }
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=100)
 public static void equipmentGradesRepairAndHarvest(GameTestHelper h){
  for(var m:ExpandedMinerals.MATERIALS){
   var pick=new ItemStack(HinaLand.item(m.id()+"_pickaxe"));var ore=HinaLand.WORLD_BLOCKS.get(m.id()+"_ore").get().defaultBlockState();
   h.assertTrue(pick.isCorrectToolForDrops(ore),"New pick harvests new ore");h.assertTrue(pick.isCorrectToolForDrops(Blocks.OBSIDIAN.defaultBlockState())==(m.grade()>0),"Obsidian requires the second/third grade");
   h.assertFalse(new ItemStack(Items.STONE_PICKAXE).isCorrectToolForDrops(ore),"Stone cannot harvest new ores");
   h.assertTrue(pick.getItem().isValidRepairItem(pick,new ItemStack(HinaLand.item(m.id()))),"Pick repair requires its own material");
   h.assertFalse(pick.getItem().isValidRepairItem(pick,new ItemStack(Items.DIAMOND)),"Vanilla diamond does not repair new pick");
   int defense=0;for(var type:ArmorItem.Type.values()){
    var stack=new ItemStack(HinaLand.item(m.id()+"_"+type.getName()));var armor=(ArmorItem)stack.getItem();defense+=armor.getDefense();
    h.assertTrue(armor.getType()==type&&armor.getToughness()==m.grade(),"Armor slot and increasing toughness");h.assertTrue(armor.isValidRepairItem(stack,new ItemStack(HinaLand.item(m.id()))),"Armor repairs with matching material");
    h.assertTrue(stack.getAttributeModifiers(type.getSlot()).containsKey(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR),"Equipped armor grants protection attributes");
   }h.assertTrue(defense==(m.grade()==0?15:20),"Balanced total armor defense");
   var pos=h.absolutePos(new BlockPos(2,2,2));var normal=Block.getDrops(ore,h.getLevel(),pos,null,null,pick);h.assertTrue(normal.size()==1&&normal.get(0).is(HinaLand.item(m.id())),"Ore drops its new mineral");
   var silk=new ItemStack(Items.DIAMOND_PICKAXE);silk.enchant(net.minecraft.world.item.enchantment.Enchantments.SILK_TOUCH,1);var intact=Block.getDrops(ore,h.getLevel(),pos,null,null,silk);h.assertTrue(intact.size()==1&&intact.get(0).is(ore.getBlock().asItem()),"Silk Touch preserves ore");
  }
  h.assertTrue(new ItemStack(Items.DIAMOND_PICKAXE).isCorrectToolForDrops(Blocks.OBSIDIAN.defaultBlockState()),"Vanilla diamond tier preserved");h.assertFalse(new ItemStack(Items.IRON_PICKAXE).isCorrectToolForDrops(Blocks.OBSIDIAN.defaultBlockState()),"Vanilla iron tier preserved");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=100)
 public static void newVeinsOnlyInTheirUniverse(GameTestHelper h){
  var configured=h.getLevel().registryAccess().registryOrThrow(Registries.CONFIGURED_FEATURE);var biomes=h.getLevel().registryAccess().registryOrThrow(Registries.BIOME);
  for(var m:ExpandedMinerals.MATERIALS){var id=new ResourceLocation(HinaLand.ID,m.id()+"_veins");var feature=configured.get(id);var conf=(net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration)feature.config();
   h.assertTrue(conf.targetStates.stream().anyMatch(t->t.target.test(HinaLand.WORLD_BLOCKS.get(m.family()+"_stone").get().defaultBlockState(),net.minecraft.util.RandomSource.create(1))),"Ore targets its family's deep rock");
   for(String family:HinaWorldgen.FAMILIES)for(String suffix:HinaWorldgen.VARIANTS){var biome=biomes.getOrThrow(HinaWorldgen.biome(family+suffix));boolean present=biome.getGenerationSettings().features().get(6).stream().anyMatch(f->f.unwrapKey().orElseThrow().location().equals(id));h.assertTrue(present==family.equals(m.family()),"Veins isolated to family: "+m.id()+" / "+family+suffix);}
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=60)
 public static void marioQuestionRewardsOnlyOnce(GameTestHelper h){
  h.killAllEntities();var rel=new BlockPos(2,3,2);var pos=h.absolutePos(rel);h.setBlock(rel,MarioPlayBlocks.QUESTION.get());var player=h.makeMockSurvivalPlayer();
  var block=(MarioPlayBlocks.QuestionBlock)MarioPlayBlocks.QUESTION.get();var hit=new net.minecraft.world.phys.BlockHitResult(net.minecraft.world.phys.Vec3.atCenterOf(pos),Direction.DOWN,pos,false);
  block.use(h.getLevel().getBlockState(pos),h.getLevel(),pos,player,net.minecraft.world.InteractionHand.MAIN_HAND,hit);
  h.assertBlockPresent(MarioPlayBlocks.USED.get(),rel);
  var area=new net.minecraft.world.phys.AABB(pos).inflate(3);var items=h.getLevel().getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,area);h.assertTrue(items.size()==1&&!items.get(0).getItem().isEmpty(),"Actual use emits one reward stack");
  h.assertFalse(MarioPlayBlocks.activate(h.getLevel(),pos),"Repeated activation gives no reward");h.assertTrue(h.getLevel().getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,area).size()==1,"No duplicate drop");
  var loot=Block.getDrops(MarioPlayBlocks.USED.get().defaultBlockState(),h.getLevel(),pos,null,null,new ItemStack(Items.IRON_PICKAXE));h.assertTrue(loot.size()==1&&loot.get(0).is(HinaLand.item("mario_used_bonus_block")),"Breaking spent blocks cannot reset a reward");
  h.setBlock(rel,MarioPlayBlocks.QUESTION.get());block.attack(h.getLevel().getBlockState(pos),h.getLevel(),pos,player);h.assertBlockPresent(MarioPlayBlocks.USED.get(),rel);h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=200)
 public static void completeLitGatewaysAllRotations(GameTestHelper h){
  var level=h.getLevel();int familyIndex=0;
  for(String family:HinaWorldgen.FAMILIES){
   var template=level.getStructureManager().get(new ResourceLocation(HinaLand.ID,family+"_nether_gateway")).orElseThrow();int rotIndex=0;
   for(var rotation:Rotation.values()){
    var settings=new StructurePlaceSettings().setRotation(rotation);var anchor=h.absolutePos(new BlockPos(25+familyIndex*20,120,25+rotIndex*20));level.getChunk(anchor);level.getChunk(anchor.offset(-16,0,-16));
    h.assertTrue(template.placeInWorld(level,anchor,anchor,settings,level.random,2),"Complete gateway placed: "+family+" / "+rotation);
    var inside=anchor.offset(StructureTemplate.calculateRelativePosition(settings,new BlockPos(3,4,4)));var state=level.getBlockState(inside);h.assertTrue(state.is(Blocks.NETHER_PORTAL),"Portal pre-lit after rotation");
    var shape=new PortalShape(level,inside,state.getValue(NetherPortalBlock.AXIS));h.assertTrue(shape.isValid()&&shape.isComplete(),"Vanilla recognizes full obsidian frame and all six portal blocks");rotIndex++;
   }familyIndex++;
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=100)
 public static void bonusBlocksAndThemedLandmarksLoaded(GameTestHelper h){
  var level=h.getLevel();var structures=level.registryAccess().registryOrThrow(Registries.STRUCTURE);
  for(String id:List.of("mario_bonus_garden","sonic_ring_shrine","omori_picnic","deltarune_chess_court"))h.assertTrue(structures.get(new ResourceLocation(HinaLand.ID,id)) instanceof GroundedStructure,"New landmark uses slope/ground verification");
  var template=level.getStructureManager().get(new ResourceLocation(HinaLand.ID,"mario_bonus_garden")).orElseThrow();var anchor=h.absolutePos(new BlockPos(2,100,2));h.assertTrue(template.placeInWorld(level,anchor,anchor,new StructurePlaceSettings(),level.random,2),"Mario bonus garden placed");
  for(int x:new int[]{2,6,10})h.assertTrue(level.getBlockState(anchor.offset(x,6,4)).is(MarioPlayBlocks.QUESTION.get()),"Three real interactive blocks in generated garden");
  var picnic=level.getStructureManager().get(new ResourceLocation(HinaLand.ID,"omori_picnic")).orElseThrow();var garden=anchor.offset(20,0,0);h.assertTrue(picnic.placeInWorld(level,garden,garden,new StructurePlaceSettings(),level.random,2),"OMORI picnic template placed");
  for(int x:new int[]{1,7})for(int z:new int[]{1,7}){var p=garden.offset(x,3,z);var flower=level.getBlockState(p);h.assertTrue(flower.is(HinaLand.WORLD_BLOCKS.get("omori_blue_orchid").get())&&flower.canSurvive(level,p),"Picnic flowers have real plantable soil");}
  var registry=level.registryAccess().registryOrThrow(Registries.BIOME);
  for(String family:HinaWorldgen.FAMILIES)for(String suffix:HinaWorldgen.VARIANTS)for(String variant:List.of("standard","desert","jungle","mountain","ocean","swamp"))h.assertFalse(registry.getHolderOrThrow(HinaWorldgen.biome(family+suffix)).is(net.minecraft.tags.TagKey.create(Registries.BIOME,new ResourceLocation("minecraft","has_structure/ruined_portal_"+variant))),"No vanilla ruined portals in exclusive Overworld");
  h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=60)
 public static void marioHeadBumpRequiresAscent(GameTestHelper h){
  var pos=h.absolutePos(new BlockPos(2,4,2));var falling=h.makeMockSurvivalPlayer();var rising=h.makeMockSurvivalPlayer();
  h.setBlock(new BlockPos(2,4,2),MarioPlayBlocks.QUESTION.get());
  falling.setOnGround(false);falling.setPos(pos.getX()+.5,pos.getY()-1.58,pos.getZ()+.5);
  MarioPlayBlocks.bump(new net.minecraftforge.event.TickEvent.PlayerTickEvent(net.minecraftforge.event.TickEvent.Phase.END,falling));
  falling.setPos(falling.getX(),falling.getY()-.01,falling.getZ());MarioPlayBlocks.bump(new net.minecraftforge.event.TickEvent.PlayerTickEvent(net.minecraftforge.event.TickEvent.Phase.END,falling));
  h.assertTrue(h.getLevel().getBlockState(pos).is(MarioPlayBlocks.QUESTION.get()),"Falling near ceiling cannot collect question reward");
  rising.setOnGround(false);rising.setPos(pos.getX()+.5,pos.getY()-2.1,pos.getZ()+.5);MarioPlayBlocks.bump(new net.minecraftforge.event.TickEvent.PlayerTickEvent(net.minecraftforge.event.TickEvent.Phase.END,rising));
  rising.setPos(rising.getX(),pos.getY()-1.78,rising.getZ());MarioPlayBlocks.bump(new net.minecraftforge.event.TickEvent.PlayerTickEvent(net.minecraftforge.event.TickEvent.Phase.END,rising));
  h.assertTrue(h.getLevel().getBlockState(pos).is(MarioPlayBlocks.USED.get()),"Rising head contact activates real reward block");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=60)
 public static void marioCraftExchangeAndMushroomEffect(GameTestHelper h){
  var grid=grid();for(int i=0;i<9;i++)grid.setItem(i,new ItemStack(i==4?Items.CHEST:Items.GOLD_INGOT));craft(h,grid,"mario_question_block",1);
  grid.clearContent();for(int i:new int[]{0,1,3,4})grid.setItem(i,new ItemStack(HinaLand.item("mario_coin")));
  var recipe=h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,grid,h.getLevel()).orElseThrow();h.assertTrue(recipe.assemble(grid,h.getLevel().registryAccess()).is(Items.GOLD_INGOT),"Four Mario coins exchange for one gold ingot");
  var player=h.makeMockSurvivalPlayer();var food=new ItemStack(HinaLand.item("mario_super_mushroom"));player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,food);
  h.assertTrue(food.use(h.getLevel(),player,net.minecraft.world.InteractionHand.MAIN_HAND).getResult().consumesAction(),"Power-up can be consumed with a full hunger bar");player.stopUsingItem();player.getFoodData().setFoodLevel(10);food.finishUsingItem(h.getLevel(),player);
  h.assertTrue(player.getFoodData().getFoodLevel()==16,"Super mushroom restores six hunger");h.assertTrue(player.hasEffect(net.minecraft.world.effect.MobEffects.ABSORPTION),"Super mushroom grants temporary absorption");h.succeed();
 }

}
