package fr.hinaland;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EndPortalFrameBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.*;

@Mod.EventBusSubscriber(modid=HinaLand.ID)
public class GameEvents {
 @SubscribeEvent public static void interact(PlayerInteractEvent.RightClickBlock event){
  if(!(event.getEntity() instanceof ServerPlayer player))return;
  ServerLevel level=player.serverLevel();ItemStack held=event.getItemStack();BlockPos pos=event.getPos();
  if(level.getBlockState(pos).is(Blocks.END_PORTAL_FRAME)){
   if(held.is(Items.ENDER_EYE)){event.setCanceled(true);player.displayClientMessage(Component.literal("Seuls les 12 Yeux de Boss distincts activent ce portail."),true);return;}
   String boss=HinaLand.bossFromEye(held.getItem());if(boss==null)return;
   event.setCanceled(true);BlockState frame=level.getBlockState(pos);if(frame.getValue(EndPortalFrameBlock.HAS_EYE)){player.displayClientMessage(Component.literal("Ce cadre contient déjà un œil."),true);return;}
   RiftState state=RiftState.get(level);String prefix=level.dimension().location()+":";
   for(var e:state.eyes.entrySet())if(e.getKey().startsWith(prefix) && e.getValue().equals(boss)){
    // Only reject a duplicate if its recorded frame is within the same stronghold vicinity.
    try{String[] coords=e.getKey().substring(prefix.length()).split(",");BlockPos other=new BlockPos(Integer.parseInt(coords[0]),Integer.parseInt(coords[1]),Integer.parseInt(coords[2]));if(other.distSqr(pos)<1024){player.displayClientMessage(Component.literal("Cet œil est déjà présent dans ce portail."),true);return;}}catch(Exception ignored){}
   }
   String key=prefix+pos.getX()+","+pos.getY()+","+pos.getZ();state.eyes.put(key,boss);state.setDirty();level.setBlock(pos,frame.setValue(EndPortalFrameBlock.HAS_EYE,true),3);if(!player.isCreative())held.shrink(1);
   player.displayClientMessage(Component.literal("Œil de "+boss+" placé."),true);
   activateIfReady(level,pos,state);return;
  }
  for(String boss:HinaLand.BOSSES)if(held.is(HinaLand.item("sigil_"+boss))){
   event.setCanceled(true);BlockPos spawn=pos.above();if(!level.getBlockState(spawn).getCollisionShape(level,spawn).isEmpty())return;
   Zombie z=EntityType.ZOMBIE.create(level);if(z==null)return;z.moveTo(spawn.getX()+.5,spawn.getY(),spawn.getZ()+.5,player.getYRot(),0);z.setCustomName(Component.literal("[ÉCHO] "+boss.replace('_',' ').toUpperCase(Locale.ROOT)));z.setCustomNameVisible(true);z.getPersistentData().putString("HinaLandBoss",boss);z.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH).setBaseValue(120);z.setHealth(120);z.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE).setBaseValue(9);z.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,999999,0));z.setPersistenceRequired();level.addFreshEntity(z);if(!player.isCreative())held.shrink(1);player.displayClientMessage(Component.literal("Écho de boss invoqué : "+boss),true);return;
  }
  if(held.is(HinaLand.item("anemo_wand"))){event.setCanceled(true);player.push(player.getLookAngle().x*1.5,0.6,player.getLookAngle().z*1.5);player.hurtMarked=true;held.hurtAndBreak(1,player,p->p.broadcastBreakEvent(event.getHand()));}
 }
 private static void activateIfReady(ServerLevel level,BlockPos touched,RiftState state){
  // Find the center of a 5x5 portal ring around the touched frame; ignore corners.
  for(int dx=-4;dx<=4;dx++)for(int dz=-4;dz<=4;dz++){
   BlockPos corner=touched.offset(dx,0,dz);Set<String> found=new HashSet<>();boolean valid=true;
   for(int x=0;x<5;x++)for(int z=0;z<5;z++)if((x==0||x==4||z==0||z==4)&&!((x==0||x==4)&&(z==0||z==4))){
    BlockPos p=corner.offset(x,0,z);BlockState b=level.getBlockState(p);String key=level.dimension().location()+":"+p.getX()+","+p.getY()+","+p.getZ();String eye=state.eyes.get(key);
    if(!b.is(Blocks.END_PORTAL_FRAME)||!b.getValue(EndPortalFrameBlock.HAS_EYE)||eye==null||!found.add(eye))valid=false;
   }
   if(valid&&found.size()==12){for(int x=1;x<=3;x++)for(int z=1;z<=3;z++)level.setBlock(corner.offset(x,0,z),Blocks.END_PORTAL.defaultBlockState(),3);state.dragonPowers.clear();state.dragonPowers.addAll(found);state.setDirty();level.players().forEach(p->p.displayClientMessage(Component.literal("§dLes douze échos ouvrent l'End !"),false));return;}
  }
 }
 @SubscribeEvent public static void death(LivingDeathEvent event){
  if(!(event.getEntity().level() instanceof ServerLevel level))return;
  LivingEntity mob=event.getEntity();String boss=mob.getPersistentData().getString("HinaLandBoss");
  if(!boss.isEmpty() && HinaLand.ALL.containsKey("eye_"+boss))mob.spawnAtLocation(new ItemStack(HinaLand.item("eye_"+boss)));
  if(mob instanceof EnderDragon){RiftState state=RiftState.get(level);state.unlocked=true;state.setDirty();for(ServerPlayer p:level.players())if(p.distanceToSqr(mob)<220*220){p.addItem(new ItemStack(HinaLand.item("dragon_scale"),12));p.addItem(new ItemStack(HinaLand.item("echo_fragment"),2));p.addItem(new ItemStack(HinaLand.item("multiverse_core")));}}
 }
 @SubscribeEvent public static void tick(LivingEvent.LivingTickEvent event){
  if(!(event.getEntity() instanceof EnderDragon dragon)||!(dragon.level() instanceof ServerLevel level)||level.getGameTime()%120!=0)return;
  RiftState state=RiftState.get(level);if(state.dragonPowers.isEmpty())return;
  int index=(int)((level.getGameTime()/120)%state.dragonPowers.size());String power=state.dragonPowers.get(index);
  for(ServerPlayer player:level.players())if(player.distanceToSqr(dragon)<100*100 && !player.isCreative()&&!player.isSpectator()){
   if(power.equals("andrius"))player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,60,0));
   else if(power.equals("something")||power.equals("king_boo"))player.addEffect(new MobEffectInstance(MobEffects.DARKNESS,45,0));
   else if(power.equals("bowser")||power.equals("flandre"))player.setSecondsOnFire(2);
   else if(power.equals("dvalin"))player.push(0,0.5,0);
   else if(power.equals("mewtwo"))player.addEffect(new MobEffectInstance(MobEffects.LEVITATION,25,0));
  }
  level.sendParticles(ParticleTypes.DRAGON_BREATH,dragon.getX(),dragon.getY(),dragon.getZ(),25,3,2,3,0.1);
 }
}
