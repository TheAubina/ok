package fr.hinaland;

import java.util.*;
import net.minecraft.sounds.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.common.*;

/** Three additional, craftable equipment grades in each of the seven generated universes. */
public final class ExpandedMinerals {
 public record Mineral(String family,String id,int grade) {}
 public static final List<Mineral> MATERIALS=new ArrayList<>();
 public static final Map<String,Tier> TIERS=new LinkedHashMap<>();
 public static final Map<String,ArmorMaterial> ARMORS=new LinkedHashMap<>();
 static {
  String[][] rows={{"mario","superbell_bronze","fireflower_amber","grand_starite"},{"sonic","ring_gold","sol_emerald","red_star_crystal"},{"omori","picnic_quartz","melon_jade","headspace_opal"},{"deltarune","glowshard","shadow_mithril","pipis_lazuli"},{"genshin","white_iron","starsilver","condessence_crystal"},{"overwatch","omnic_steel","helix_cobalt","graviton_alloy"},{"lethal","scrap_steel","vow_quartz","titan_alloy"}};
  for(var row:rows)for(int grade=0;grade<3;grade++)MATERIALS.add(new Mineral(row[0],row[grade+1],grade));
 }
 private ExpandedMinerals(){}
 public static void register(){for(var m:MATERIALS){
  HinaLand.ALL.put(m.id(),HinaLand.ITEMS.register(m.id(),()->new Item(new Item.Properties().rarity(m.grade()==2?Rarity.RARE:Rarity.COMMON))));
  for(String suffix:List.of("_ore","_block")){
   String id=m.id()+suffix;var block=HinaLand.BLOCKS.register(id,()->suffix.equals("_ore")?new DropExperienceBlock(BlockBehaviour.Properties.copy(Blocks.DIAMOND_ORE),UniformInt.of(1,4)):new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
   HinaLand.WORLD_BLOCKS.put(id,block);HinaLand.ALL.put(id,HinaLand.ITEMS.register(id,()->new BlockItem(block.get(),new Item.Properties())));
  }
  int grade=m.grade();Tier tier=new ForgeTier(grade==0?2:3,new int[]{480,1100,1900}[grade],new float[]{6,8,9}[grade],new int[]{2,3,4}[grade],new int[]{14,18,22}[grade],TagKey.create(Registries.BLOCK,new ResourceLocation(HinaLand.ID,"needs_"+m.id()+"_tool")),()->Ingredient.of(HinaLand.item(m.id())));
  TierSortingRegistry.registerTier(tier,new ResourceLocation(HinaLand.ID,m.id()),List.of(grade==0?Tiers.IRON:Tiers.DIAMOND),List.of(grade==0?Tiers.DIAMOND:Tiers.NETHERITE));TIERS.put(m.id(),tier);
  var armor=new MineralArmor(m.id(),grade);ARMORS.put(m.id(),armor);
  HinaLand.ALL.put(m.id()+"_pickaxe",HinaLand.ITEMS.register(m.id()+"_pickaxe",()->new PickaxeItem(tier,1,-2.8f,new Item.Properties())));
  HinaLand.ALL.put(m.id()+"_sword",HinaLand.ITEMS.register(m.id()+"_sword",()->new SwordItem(tier,3,-2.4f,new Item.Properties())));
  HinaLand.ALL.put(m.id()+"_axe",HinaLand.ITEMS.register(m.id()+"_axe",()->new AxeItem(tier,5,-3.1f,new Item.Properties())));
  for(var type:ArmorItem.Type.values()){
   String id=m.id()+"_"+type.getName();HinaLand.ALL.put(id,HinaLand.ITEMS.register(id,()->new ArmorItem(armor,type,new Item.Properties())));
  }
 }}
 public record MineralArmor(String id,int grade) implements ArmorMaterial {
  @Override public int getDurabilityForType(ArmorItem.Type type){return switch(type){case HELMET->11;case CHESTPLATE->16;case LEGGINGS->15;case BOOTS->13;}*new int[]{18,27,35}[grade];}
  @Override public int getDefenseForType(ArmorItem.Type type){return switch(type){case HELMET,BOOTS->grade==0?2:3;case CHESTPLATE->grade==0?6:8;case LEGGINGS->grade==0?5:6;};}
  @Override public int getEnchantmentValue(){return new int[]{14,18,22}[grade];}
  @Override public SoundEvent getEquipSound(){return SoundEvents.ARMOR_EQUIP_IRON;}
  @Override public Ingredient getRepairIngredient(){return Ingredient.of(HinaLand.item(id));}
  @Override public String getName(){return HinaLand.ID+":"+id;}
  @Override public float getToughness(){return grade;}
  @Override public float getKnockbackResistance(){return grade==2?0.05f:0;}
 }
}
