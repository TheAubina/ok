package fr.hinaland;
import java.util.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.*;

public final class HinaSounds {
 public static final DeferredRegister<SoundEvent> SOUNDS=DeferredRegister.create(ForgeRegistries.SOUND_EVENTS,HinaLand.ID);
 public static final Map<String,RegistryObject<SoundEvent>> TRACKS=new LinkedHashMap<>();
 static {for(String name:List.of("mario_overworld","sonic_green_hill","omori_trees","omori_planetarium","omori_snow"))TRACKS.put(name,SOUNDS.register("music."+name,()->SoundEvent.createVariableRangeEvent(new ResourceLocation(HinaLand.ID,"music."+name))));}
 public static List<String> playlist(String family){return switch(family){case "mario"->List.of("mario_overworld");case "sonic"->List.of("sonic_green_hill");case "omori"->List.of("omori_trees","omori_planetarium","omori_snow");default->List.of();};}
 public static String choose(String family,String previous,Random random){var tracks=new ArrayList<>(playlist(family));if(tracks.size()>1)tracks.remove(previous);return tracks.isEmpty()?null:tracks.get(random.nextInt(tracks.size()));}
}
