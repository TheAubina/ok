package fr.hinaland;
import com.mojang.serialization.Codec;
import java.util.stream.Stream;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.placement.*;
import net.minecraftforge.registries.*;

/** Keep generated trees out of chunks occupied by curated Hina constructions. */
public final class StructureTreeClearance extends PlacementModifier {
 public static final Codec<StructureTreeClearance> CODEC=Codec.unit(StructureTreeClearance::new);
 public static final DeferredRegister<PlacementModifierType<?>> TYPES=DeferredRegister.create(Registries.PLACEMENT_MODIFIER_TYPE,HinaLand.ID);
 public static final RegistryObject<PlacementModifierType<StructureTreeClearance>> TYPE=TYPES.register("structure_tree_clearance",()->()->CODEC);
 @Override public PlacementModifierType<?> type(){return TYPE.get();}
 @Override public Stream<BlockPos> getPositions(PlacementContext c,RandomSource r,BlockPos p){
  boolean occupied=c.getLevel().getChunk(p).getAllReferences().entrySet().stream().anyMatch(e->!e.getValue().isEmpty()&&e.getKey() instanceof GroundedStructure);
  return occupied?Stream.empty():Stream.of(p);
 }
}
