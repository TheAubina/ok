package fr.hinaland.client;
import fr.hinaland.*;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

@Mod.EventBusSubscriber(modid=HinaLand.ID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public class LethalRenderers {
 @SubscribeEvent public static void register(EntityRenderersEvent.RegisterRenderers event){
  for(String id:LethalMobs.NAMES){final String kind=id;
   event.registerEntityRenderer(LethalMobs.ENTITIES.get(kind).get(),context->new GeoEntityRenderer<LethalMobs.LethalEntity>(context,new Model(kind)){
    { withScale(switch(kind){case "barber"->.74f;case "bracken"->.88f;case "bunker_spider"->.63f;case "coil_head"->.78f;case "ghost_girl"->.76f;case "nutcracker"->.65f;default->.4f;}); }
    @Override public boolean shouldRender(LethalMobs.LethalEntity e,net.minecraft.client.renderer.culling.Frustum f,double x,double y,double z){
     var player=net.minecraft.client.Minecraft.getInstance().player;
     if(kind.equals("ghost_girl")&&(player==null||e.hauntingVictim().isEmpty()||!e.hauntingVictim().get().equals(player.getUUID())))return false;
     if(kind.equals("barber")&&player!=null&&e.distanceToSqr(player)>100)return false;
     return super.shouldRender(e,f,x,y,z);
    }
   });
  }
 }
 static class Model extends GeoModel<LethalMobs.LethalEntity>{
  private final String id;Model(String id){this.id=id;}
  @Override public ResourceLocation getModelResource(LethalMobs.LethalEntity e){return new ResourceLocation(HinaLand.ID,"geo/"+id+".geo.json");}
  @Override public ResourceLocation getTextureResource(LethalMobs.LethalEntity e){return new ResourceLocation(HinaLand.ID,"textures/entity/lethal/"+id+".png");}
  @Override public ResourceLocation getAnimationResource(LethalMobs.LethalEntity e){return new ResourceLocation(HinaLand.ID,"animations/"+id+".animation.json");}
 }
}
