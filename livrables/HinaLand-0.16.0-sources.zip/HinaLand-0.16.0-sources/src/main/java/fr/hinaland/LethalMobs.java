package fr.hinaland;

import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.network.syncher.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.*;
import net.minecraftforge.eventbus.api.IEventBus;
import java.util.*;

/** Server-authoritative beta behaviours; client renderers use the supplied GeckoLib models. */
@Mod.EventBusSubscriber(modid=HinaLand.ID,bus=Mod.EventBusSubscriber.Bus.MOD)
public final class LethalMobs {
 public static final String[] NAMES={"bracken","coil_head","hoarding_bug","barber","bunker_spider","ghost_girl","nutcracker"};
 public static final DeferredRegister<EntityType<?>> TYPES=DeferredRegister.create(ForgeRegistries.ENTITY_TYPES,HinaLand.ID);
 public static final Map<String,RegistryObject<EntityType<LethalEntity>>> ENTITIES=new LinkedHashMap<>();
 static {for(String id:NAMES) ENTITIES.put(id,TYPES.register("lethal_"+id,()->EntityType.Builder.<LethalEntity>of((type,world)->new LethalEntity(type,world,id),MobCategory.MONSTER).sized(switch(id){case "bunker_spider"->1.3f;case "hoarding_bug"->1.0f;case "bracken"->0.9f;default->0.7f;},switch(id){case "bunker_spider","hoarding_bug"->0.9f;case "bracken"->2.6f;case "coil_head"->2.5f;case "ghost_girl"->1.6f;case "nutcracker"->2.1f;default->1.9f;}).clientTrackingRange(8).build("hinaland:lethal_"+id)));}
 public static void register(IEventBus bus){TYPES.register(bus);}
 @SubscribeEvent public static void attributes(EntityAttributeCreationEvent e){for(var r:ENTITIES.values())e.put(r.get(),Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH,30).add(Attributes.FOLLOW_RANGE,30).add(Attributes.MOVEMENT_SPEED,r.getId().getPath().equals("lethal_coil_head")?0.55:0.28).add(Attributes.ATTACK_DAMAGE,5).build());}
 public static class LethalEntity extends Monster implements GeoEntity {
  private final AnimatableInstanceCache cache=GeckoLibUtil.createInstanceCache(this);
  private static final EntityDataAccessor<Optional<UUID>> VICTIM=SynchedEntityData.defineId(LethalEntity.class,EntityDataSerializers.OPTIONAL_UUID);
  @Override protected void defineSynchedData(){super.defineSynchedData();entityData.define(VICTIM,Optional.empty());}
  public Optional<UUID> hauntingVictim(){return entityData.get(VICTIM);}
  public String kind(){return kind;}
  private Vec3 lastObservedPlayerPosition;
  private UUID lastObservedPlayer;
  private int magazine=2;
  private int attackTimer,alertTimer; private int angerTicks; private ItemStack stolen=ItemStack.EMPTY;
  // PathfinderMob also checks walk-target brightness after the registered spawn predicate.
  @Override public float getWalkTargetValue(BlockPos pos,net.minecraft.world.level.LevelReader level){return 0.0f;}
  @Override public AnimatableInstanceCache getAnimatableInstanceCache(){return cache;}
  @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers){controllers.add(new AnimationController<>(this,"movement",4,state->{String name=getDeltaMovement().horizontalDistanceSqr()>0.003?switch(kind){case "coil_head"->"run";case "nutcracker"->"march";case "ghost_girl"->"hop_walk";case "hoarding_bug"->"crawl_crouch";default->"walk";}:kind.equals("hoarding_bug")?"idle_crouch":"idle";if(kind.equals("hoarding_bug")&&!onGround())name="fly";if(kind.equals("barber"))name=getDeltaMovement().horizontalDistanceSqr()>0.003?"jump_forward":"idle";return state.setAndContinue(RawAnimation.begin().thenLoop("animation."+kind+"."+name));}));controllers.add(new AnimationController<>(this,"action",0,state->software.bernie.geckolib.core.object.PlayState.STOP).triggerableAnim("attack",RawAnimation.begin().thenPlay("animation."+kind+"."+switch(kind){case "bracken"->"neck_twist";case "barber"->"attack_close";case "nutcracker"->"shoot";case "hoarding_bug"->"fly_attack";case "bunker_spider"->"attack";default->"idle";})));}
  @Override protected void registerGoals(){
    goalSelector.addGoal(0,new Goal(){
     {setFlags(EnumSet.of(Flag.MOVE));}
     @Override public boolean canUse(){return kind!=null&&kind.equals("hoarding_bug")&&angerTicks>0&&getTarget()!=null&&distanceToSqr(getTarget())>16;}
     @Override public void start(){setNoGravity(true);}
     @Override public void stop(){setNoGravity(false);}
     private boolean keepInside(){
   if(level().isClientSide)return true;
   if(IndoorHabitat.isInterior(level(),blockPosition())){lastIndoorPosition=blockPosition();return true;}
   getNavigation().stop();setTarget(null);setDeltaMovement(Vec3.ZERO);
   if(lastIndoorPosition!=null&&IndoorHabitat.isInterior(level(),lastIndoorPosition)){
    setPos(lastIndoorPosition.getX()+0.5,lastIndoorPosition.getY(),lastIndoorPosition.getZ()+0.5);return true;
   }
   discard();return false;
  }
  @Override public void tick(){
   if(!keepInside())return;
   if(!level().isClientSide&&getTarget() instanceof Player target&&!valid(target))setTarget(null);Vec3 d=getTarget().getEyePosition().subtract(position());setDeltaMovement(d.normalize().scale(0.25));}
    });
    goalSelector.addGoal(1,new FloatGoal(this));
    goalSelector.addGoal(2,new MeleeAttackGoal(this,1.2,false));
    goalSelector.addGoal(6,new WaterAvoidingRandomStrollGoal(this,0.8));
    goalSelector.addGoal(7,new LookAtPlayerGoal(this,Player.class,12));
    goalSelector.addGoal(8,new RandomLookAroundGoal(this));
  }
  private final String kind;
  private int behaviorClock;
  private BlockPos lastIndoorPosition;
  private int watchedTicks;
  private boolean frozenByGaze;
  private UUID hauntingTarget;
  public LethalEntity(EntityType<? extends Monster> type,Level level,String kind){super(type,level);this.kind=kind;}

  private boolean keepInside(){
   if(level().isClientSide)return true;
   if(IndoorHabitat.isInterior(level(),blockPosition())){lastIndoorPosition=blockPosition();return true;}
   getNavigation().stop();setTarget(null);setDeltaMovement(Vec3.ZERO);
   if(lastIndoorPosition!=null&&IndoorHabitat.isInterior(level(),lastIndoorPosition)){
    setPos(lastIndoorPosition.getX()+0.5,lastIndoorPosition.getY(),lastIndoorPosition.getZ()+0.5);return true;
   }
   discard();return false;
  }
  @Override public void tick(){
   if(!keepInside())return;
   if(!level().isClientSide&&getTarget() instanceof Player target&&!valid(target))setTarget(null);
   if(!level().isClientSide&&kind.equals("coil_head")){
    frozenByGaze=level().getEntitiesOfClass(Player.class,getBoundingBox().inflate(30)).stream().anyMatch(v->valid(v)&&isWatched(v));
    if(frozenByGaze){getNavigation().stop();setTarget(null);setDeltaMovement(0,getDeltaMovement().y,0);}
   }
   super.tick();if(level().isClientSide)return;behaviorClock++;if(attackTimer>0)attackTimer--;if(alertTimer>0)alertTimer--;if(angerTicks>0)angerTicks--;
   // Apply gaze freeze on every server tick, not every fifth tick.
   if(kind.equals("coil_head")){
    frozenByGaze=false;
    for(Player viewer:level().getEntitiesOfClass(Player.class,getBoundingBox().inflate(30))){
     if(valid(viewer)&&isWatched(viewer)){frozenByGaze=true;break;}
    }
    if(frozenByGaze){getNavigation().stop();setTarget(null);setDeltaMovement(0,getDeltaMovement().y,0);}
   }
   if(kind.equals("nutcracker") && getTarget() instanceof Player target && hasLineOfSight(target) && distanceToSqr(target)<400 && attackTimer==0){
     for(int pellet=0;pellet<5;pellet++){
      net.minecraft.world.entity.projectile.AbstractArrow arrow=new net.minecraft.world.entity.projectile.Arrow(level(),this);
      arrow.setPos(getX(),getEyeY()-0.2,getZ());Vec3 d=target.getEyePosition().subtract(arrow.position());arrow.shoot(d.x,d.y,d.z,2.2f,9);arrow.setBaseDamage(2);arrow.pickup=net.minecraft.world.entity.projectile.AbstractArrow.Pickup.DISALLOWED;level().addFreshEntity(arrow);
     }
     triggerAnim("action","attack");level().playSound(null,blockPosition(),SoundEvents.FIREWORK_ROCKET_BLAST,SoundSource.HOSTILE,1.4f,0.7f);
     if(--magazine==0){magazine=2;attackTimer=120;}else attackTimer=35;
   }
   if(kind.equals("bunker_spider")&&net.minecraftforge.event.ForgeEventFactory.getMobGriefingEvent(level(),this)&&getTarget() instanceof Player target&&attackTimer==0&&distanceToSqr(target)<30){BlockPos web=target.blockPosition();if(level().getBlockState(web).isAir()){level().setBlock(web,Blocks.COBWEB.defaultBlockState(),3);attackTimer=120;}}
   if(kind.equals("hoarding_bug")&&stolen.isEmpty()&&behaviorClock%20==0){List<ItemEntity> items=level().getEntitiesOfClass(ItemEntity.class,getBoundingBox().inflate(7));if(!items.isEmpty()){ItemEntity drop=items.stream().filter(item->item.isAlive()&&!item.getItem().isEmpty()).min(Comparator.comparingDouble(this::distanceToSqr)).orElse(null);if(drop==null)return;getNavigation().moveTo(drop,1.2);if(distanceToSqr(drop)<2){stolen=drop.getItem().copy();drop.discard();}}}
   if(behaviorClock%5!=0)return;
   Player p=nearestValidPlayer(28);
   if(kind.equals("coil_head")&&!frozenByGaze&&p!=null)setTarget(p);
   if(kind.equals("bracken")&&p!=null){
    watchedTicks=isWatched(p)?watchedTicks+5:Math.max(0,watchedTicks-5);
    if(isWatched(p)&&watchedTicks<60){
     setTarget(null);
     Vec3 away=position().subtract(p.position());
     if(away.lengthSqr()>0.01){Vec3 retreat=position().add(away.normalize().scale(9));getNavigation().moveTo(retreat.x,retreat.y,retreat.z,1.3);}
    }else if(distanceToSqr(p)<225||watchedTicks>=60)setTarget(p);
   }
   if(kind.equals("ghost_girl")){
    Player victim=hauntingTarget==null?null:level().getPlayerByUUID(hauntingTarget);
    if(!valid(victim)){victim=p;hauntingTarget=victim==null?null:victim.getUUID();entityData.set(VICTIM,Optional.ofNullable(hauntingTarget));}
    // The renderer checks the synchronized victim UUID; the server retains the entity.
    setInvisible(false);
    setTarget(victim);
   }
   if(kind.equals("hoarding_bug")){
    if(p!=null&&(angerTicks>0||(!stolen.isEmpty()&&distanceToSqr(p)<16)))setTarget(p);else setTarget(null);
   }
   if(kind.equals("nutcracker")&&p!=null){
    boolean moving=lastObservedPlayerPosition!=null&&p.getUUID().equals(lastObservedPlayer)&&p.position().distanceToSqr(lastObservedPlayerPosition)>0.002;
    lastObservedPlayerPosition=p.position();lastObservedPlayer=p.getUUID();
    if(moving&&hasLineOfSight(p))setTarget(p);else setTarget(null);
   }
   if(kind.equals("barber")&&p!=null&&distanceToSqr(p)<196){setTarget(p);if(distanceToSqr(p)<16&&attackTimer==0){Vec3 jump=p.position().subtract(position()).normalize();setDeltaMovement(jump.x*0.9,0.45,jump.z*0.9);attackTimer=65;}}
   if(kind.equals("bunker_spider")&&p!=null&&distanceToSqr(p)<144)setTarget(p);
   if(kind.equals("ghost_girl")&&getTarget() instanceof Player victim&&distanceToSqr(victim)<9&&attackTimer==0){victim.addEffect(new MobEffectInstance(MobEffects.BLINDNESS,75));victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,60,1));attackTimer=140;}
   if(kind.equals("bracken")&&p!=null&&distanceToSqr(p)<4&&(!isWatched(p)||watchedTicks>=60)&&attackTimer==0){p.hurt(damageSources().mobAttack(this),11);level().playSound(null,blockPosition(),SoundEvents.SKELETON_HURT,SoundSource.HOSTILE,1,0.6f);attackTimer=80;}
  }
  @Override public boolean hurt(DamageSource source,float amount){boolean hit=super.hurt(source,amount);if(hit&&kind.equals("hoarding_bug")&&source.getEntity() instanceof Player player&&valid(player)){angerTicks=600;setTarget(player);}return hit;}
  @Override public boolean doHurtTarget(Entity target){if(!level().isClientSide&&(!IndoorHabitat.isInterior(level(),blockPosition())||(target instanceof Player p&&!valid(p))))return false;if(kind.equals("coil_head")&&frozenByGaze)return false;boolean hit=super.doHurtTarget(target);if(hit)triggerAnim("action","attack");return hit;}
  @Override public void travel(Vec3 input){
   // Zombie AI goals may request movement even while the Coil-Head is watched.
   if(!level().isClientSide && kind.equals("coil_head") && frozenByGaze){
    super.travel(Vec3.ZERO);
    setDeltaMovement(0,getDeltaMovement().y,0);
   } else super.travel(input);
   if(!level().isClientSide)keepInside();
  }
  @Override public void addAdditionalSaveData(CompoundTag tag){super.addAdditionalSaveData(tag);if(lastIndoorPosition!=null)tag.putLong("LastIndoorPosition",lastIndoorPosition.asLong());tag.putInt("LethalAttackTimer",attackTimer);tag.putInt("Magazine",magazine);tag.putInt("AngerTicks",angerTicks);if(hauntingTarget!=null)tag.putUUID("LethalVictim",hauntingTarget);if(!stolen.isEmpty())tag.put("LethalLoot",stolen.save(new CompoundTag()));}
  @Override public void readAdditionalSaveData(CompoundTag tag){super.readAdditionalSaveData(tag);if(tag.contains("LastIndoorPosition"))lastIndoorPosition=BlockPos.of(tag.getLong("LastIndoorPosition"));attackTimer=tag.getInt("LethalAttackTimer");angerTicks=tag.getInt("AngerTicks");magazine=tag.contains("Magazine")?tag.getInt("Magazine"):2;if(tag.hasUUID("LethalVictim"))hauntingTarget=tag.getUUID("LethalVictim");entityData.set(VICTIM,Optional.ofNullable(hauntingTarget));if(tag.contains("LethalLoot"))stolen=ItemStack.of(tag.getCompound("LethalLoot"));}
  @Override public void die(DamageSource source){if(!stolen.isEmpty()){spawnAtLocation(stolen.copy());stolen=ItemStack.EMPTY;}super.die(source);}
  private boolean valid(Player p){return p!=null&&p.isAlive()&&!p.isSpectator()&&!p.isCreative()&&IndoorHabitat.isInterior(level(),p.blockPosition());}
  private Player nearestValidPlayer(double radius){Player result=null;double best=radius*radius;for(Player p:level().getEntitiesOfClass(Player.class,getBoundingBox().inflate(radius))){double d=distanceToSqr(p);if(valid(p)&&d<best){result=p;best=d;}}return result;}
  private boolean isWatched(Player p){if(!p.hasLineOfSight(this))return false;Vec3 toward=position().add(0,getBbHeight()/2,0).subtract(p.getEyePosition());if(toward.lengthSqr()<0.01)return true;return p.getViewVector(1).normalize().dot(toward.normalize())>0.92;}
 }
}
