package fr.hinaland;
import net.minecraft.world.item.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** The Hammer Bro's weapon is also a craftable, consumable player projectile. */
public final class ThrowableHammerItem extends Item {
 public ThrowableHammerItem(Properties properties){super(properties);}
 @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
  var stack=player.getItemInHand(hand);if(!level.isClientSide){var bolt=new DarknerProjectile(level,player);bolt.setItem(stack.copyWithCount(1));bolt.shootFromRotation(player,player.getXRot(),player.getYRot(),0,1.2f,.3f);level.addFreshEntity(bolt);player.getCooldowns().addCooldown(this,20);if(!player.getAbilities().instabuild)stack.shrink(1);}
  return InteractionResultHolder.sidedSuccess(stack,level.isClientSide);
 }
}
