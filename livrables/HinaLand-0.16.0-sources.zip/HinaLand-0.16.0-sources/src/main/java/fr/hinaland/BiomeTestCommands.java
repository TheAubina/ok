package fr.hinaland;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.Set;

/** Solo-world testing: real biome ids via vanilla fillbiome + surface conversion.
 * Commands intentionally require cheats/operator privileges. */
@Mod.EventBusSubscriber(modid=HinaLand.ID)
public final class BiomeTestCommands {
 private static final Set<String> REGIONS=Set.of("mario","sonic","omori","deltarune");
 @SubscribeEvent public static void commands(RegisterCommandsEvent e){
  e.getDispatcher().register(Commands.literal("hinaland")
   .requires(source->source.hasPermission(2))
   .then(Commands.literal("testbiome")
    .then(Commands.argument("region",StringArgumentType.word())
     .executes(ctx->create(ctx.getSource(),StringArgumentType.getString(ctx,"region"),24))
     .then(Commands.argument("radius",IntegerArgumentType.integer(8,48))
      .executes(ctx->create(ctx.getSource(),StringArgumentType.getString(ctx,"region"),IntegerArgumentType.getInteger(ctx,"radius"))))))
   .then(Commands.literal("where").executes(ctx->{var s=ctx.getSource();var biome=s.getLevel().getBiome(BlockPos.containing(s.getPosition()));s.sendSuccess(()->Component.literal("Biome: "+biome.unwrapKey().map(k->k.location().toString()).orElse("unknown")),false);return 1;}))
   .then(Commands.literal("spawn")
    .then(Commands.argument("mob",StringArgumentType.word())
     .executes(ctx->spawn(ctx.getSource(),StringArgumentType.getString(ctx,"mob"))))));
 }
 private static int create(CommandSourceStack source,String region,int radius){
  if(!REGIONS.contains(region)){source.sendFailure(Component.literal("Use mario, sonic, omori or deltarune"));return 0;}
  ServerPlayer player;
  try{player=source.getPlayerOrException();}catch(Exception ex){source.sendFailure(Component.literal("Player required"));return 0;}
  ServerLevel level=player.serverLevel();
  if(!level.dimension().equals(net.minecraft.world.level.Level.OVERWORLD)){source.sendFailure(Component.literal("Overworld only"));return 0;}
  BlockPos center=player.blockPosition();
  // The native command modifies the registered biome palette, including client biome synchronization.
  int minX=center.getX()-radius,minZ=center.getZ()-radius,maxX=center.getX()+radius,maxZ=center.getZ()+radius;
  String command="fillbiome "+minX+" -64 "+minZ+" "+maxX+" 319 "+maxZ+" hinaland:"+region;
  // /fillbiome limits volumes; use 16x16 horizontal tiles, 64-high slices to remain under its 32768-block cap.
  for(int x=minX;x<=maxX;x+=16)for(int z=minZ;z<=maxZ;z+=16){
   for(int y=-64;y<320;y+=64){
    String part="fillbiome "+x+" "+y+" "+z+" "+Math.min(x+15,maxX)+" "+(y+63)+" "+Math.min(z+15,maxZ)+" hinaland:"+region;
    source.getServer().getCommands().performPrefixedCommand(source.withSuppressedOutput(),part);
   }
  }
  Block soil=HinaLand.WORLD_BLOCKS.get(region+"_dirt").get();
  Block grass=HinaLand.WORLD_BLOCKS.get(region+"_grass_block")!=null?HinaLand.WORLD_BLOCKS.get(region+"_grass_block").get():HinaLand.WORLD_BLOCKS.get(region+"_soil").get();
  Block stone=HinaLand.WORLD_BLOCKS.get(region+"_stone").get();
  int changed=0;
  for(int x=minX;x<=maxX;x++)for(int z=minZ;z<=maxZ;z++){
   if((x-center.getX())*(x-center.getX())+(z-center.getZ())*(z-center.getZ())>radius*radius)continue;
   BlockPos top=level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,new BlockPos(x,0,z)).below();
   if(top.getY()<level.getMinBuildHeight()+5||top.getY()>180)continue;
   if(level.getBlockState(top).is(Blocks.GRASS_BLOCK)||level.getBlockState(top).is(Blocks.DIRT)||level.getBlockState(top).is(Blocks.PODZOL)||level.getBlockState(top).is(Blocks.COARSE_DIRT)){
    level.setBlock(top,grass.defaultBlockState(),3);changed++;
    for(int d=1;d<=3;d++){BlockPos below=top.below(d);if(level.getBlockState(below).is(Blocks.DIRT))level.setBlock(below,soil.defaultBlockState(),3);}
    for(int d=4;d<=7;d++){BlockPos below=top.below(d);if(level.getBlockState(below).is(Blocks.STONE))level.setBlock(below,stone.defaultBlockState(),3);}
   }
  }
  final int count=changed;
  source.sendSuccess(()->Component.literal("Hina Land: biome "+region+" applied. Surface blocks: "+count+". Run /hinaland where"),true);
  return changed;
 }
 private static int spawn(CommandSourceStack source,String mob){
  ServerPlayer player;try{player=source.getPlayerOrException();}catch(Exception ex){return 0;}
  ServerLevel level=player.serverLevel();
  if(mob.startsWith("lethal_")){
   String id=mob.substring(7);
   if(!LethalMobs.ENTITIES.containsKey(id)){source.sendFailure(Component.literal("Unknown Lethal mob"));return 0;}
   var entity=LethalMobs.ENTITIES.get(id).get().create(level);
   if(entity==null)return 0;
   entity.moveTo(player.getX()+3,player.getY(),player.getZ()+3,0,0);level.addFreshEntity(entity);return 1;
  }
  if(!Set.of("goomba","koopa","sprout_mole","forest_bunny","motobug","buzz_bomber").contains(mob)){source.sendFailure(Component.literal("Use goomba, koopa, sprout_mole, forest_bunny, motobug, buzz_bomber or lethal_<name>"));return 0;}
  var entity=BiomeMobs.ENTITIES.get(mob).get().create(level);if(entity==null)return 0;
  entity.moveTo(player.getX()+3,player.getY(),player.getZ()+3,0,0);
  entity.setCustomName(Component.literal("[Hina Land] "+mob.replace('_',' ')));
  entity.getPersistentData().putString("HinaLandCreature",mob);
  entity.getPersistentData().putString("HinaLandRegion",mob.equals("goomba")||mob.equals("koopa")?"mario":mob.equals("sprout_mole")||mob.equals("forest_bunny")?"omori":"sonic");
  level.addFreshEntity(entity);return 1;
 }
}
