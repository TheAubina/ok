package fr.hinaland;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.LevelReader;

/** Bounded covered room or tunnel; leaves and water cannot count as a ceiling or wall. */
public final class IndoorHabitat {
 private static boolean solid(LevelReader level,BlockPos p){var s=level.getBlockState(p);return !s.is(BlockTags.LEAVES)&&s.getFluidState().isEmpty()&&s.isCollisionShapeFullBlock(level,p);}
 public static boolean isInterior(LevelReader level,BlockPos pos){
  if(!level.hasChunkAt(pos))return false;
  boolean roof=false;for(int dy=2;dy<=16;dy++)if(solid(level,pos.above(dy))){roof=true;break;}
  if(!roof)return false;
  int walls=0;for(var direction:net.minecraft.core.Direction.Plane.HORIZONTAL){
   for(int d=1;d<=12;d++){BlockPos p=pos.relative(direction,d).above();if(!level.hasChunkAt(p))break;if(solid(level,p)){walls++;break;}}
  }
  return walls>=3;
 }
}
