package fr.hinaland;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.item.*;
public final class ImportedIndustrialBlocks {
 public static void register(){
  add("lc_ff_lamina",net.minecraft.world.level.block.Block.box(0,15,0,16,16,16),0);
  add("lc_lc_bloque1",net.minecraft.world.level.block.Block.box(0,0,0,16,16,16),0);
  add("lc_lc_bloque2",net.minecraft.world.level.block.Block.box(0,0,0,16,16,16),0);
  add("lc_lc_bloque3",net.minecraft.world.level.block.Block.box(0,0,0,16,16,16),0);
  add("lc_lc_bloque5",net.minecraft.world.level.block.Block.box(0,14,0,16,16,16),0);
  add("lc_lc_bocina",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_bocina2",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_botellas",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_colonia",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_escalera1",net.minecraft.world.level.block.Block.box(0,0,8,16,8,24),0);
  add("lc_lc_estanteria1",net.minecraft.world.level.block.Block.box(0,0,0,16,16,16),0);
  add("lc_lc_iron_tuberia1",net.minecraft.world.level.block.Block.box(6,0,12,10,16,16),0);
  add("lc_lc_iron_tuberia2",net.minecraft.world.level.block.Block.box(4,0,4,12,16,8),0);
  add("lc_lc_iron_tuberia3",net.minecraft.world.level.block.Block.box(0,0,8,16,16,16),0);
  add("lc_lc_iron_tuberia4",net.minecraft.world.level.block.Block.box(4,0,12,12,16,16),0);
  add("lc_lc_iron_tuberia5",net.minecraft.world.level.block.Block.box(4,0,12,20,12,16),0);
  add("lc_lc_iron_tuberia6",net.minecraft.world.level.block.Block.box(0,6,12,16,10,16),0);
  add("lc_lc_iron_tuberia7",net.minecraft.world.level.block.Block.box(6,0,12,22,10,16),0);
  add("lc_lc_kill_block",net.minecraft.world.level.block.Block.box(0,0,0,16,12,16),0);
  add("lc_lc_lingote",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_luzletal",net.minecraft.world.phys.shapes.Shapes.empty(),8);
  add("lc_lc_mina",net.minecraft.world.level.block.Block.box(3,0,3,13,9,13),0);
  add("lc_lc_pato",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_pildoras",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_piruleta",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_portapapeles",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_propulsor",net.minecraft.world.level.block.Block.box(0,0,0,16,16,16),0);
  add("lc_lc_secador",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_telefono",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_tuberia1",net.minecraft.world.level.block.Block.box(6,0,12,10,16,16),0);
  add("lc_lc_tuberia2",net.minecraft.world.level.block.Block.box(4,0,4,12,16,8),0);
  add("lc_lc_tuberia3",net.minecraft.world.level.block.Block.box(0,0,8,16,16,16),0);
  add("lc_lc_tuberia4",net.minecraft.world.level.block.Block.box(4,0,12,12,16,16),0);
  add("lc_lc_tuberia5",net.minecraft.world.level.block.Block.box(4,0,12,20,12,16),0);
  add("lc_lc_tuberia6",net.minecraft.world.level.block.Block.box(0,6,12,16,10,16),0);
  add("lc_lc_tuberia7",net.minecraft.world.level.block.Block.box(6,0,12,22,10,16),0);
  add("lc_lc_tuerca1",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_tuerca2",net.minecraft.world.phys.shapes.Shapes.empty(),0);
  add("lc_lc_varandilla1",net.minecraft.world.level.block.Block.box(0,0,14,16,16,16),0);
  add("lc_lc_varandilla2",net.minecraft.world.level.block.Block.box(0,0,14,16,16,16),0);
  add("lc_lc_varandilla3",net.minecraft.world.level.block.Block.box(10,16,2,16,16,10),0);
  add("lc_lc_ventilacion_1",net.minecraft.world.level.block.Block.box(0,1,14,16,12,16),0);
 }
 private static void add(String id,VoxelShape shape,int light){net.minecraftforge.registries.RegistryObject<net.minecraft.world.level.block.Block> b=HinaLand.BLOCKS.register(id,()->new IndustrialBlock(shape,light));HinaLand.WORLD_BLOCKS.put(id,b);HinaLand.ALL.put(id,HinaLand.ITEMS.register(id,()->new BlockItem(b.get(),new Item.Properties())));}
}
