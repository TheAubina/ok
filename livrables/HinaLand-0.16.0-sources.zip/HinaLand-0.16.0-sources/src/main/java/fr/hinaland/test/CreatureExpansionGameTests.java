package fr.hinaland.test;

import fr.hinaland.*;
import java.util.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.core.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.*;
import net.minecraft.world.item.*;
import net.minecraftforge.gametest.*;

@GameTestHolder("hinaland") @PrefixGameTestTemplate(false)
public class CreatureExpansionGameTests {
 private static BiomeMobs.ThemedEntity mob(GameTestHelper h,String id){var e=h.spawn(BiomeMobs.ENTITIES.get(id).get(),2,3,2);e.setNoAi(true);e.setNoGravity(true);return e;}
 private static Player target(GameTestHelper h,BiomeMobs.ThemedEntity e,double z){var p=h.makeMockSurvivalPlayer();p.setPos(e.getX(),e.getY(),e.getZ()+z);e.setTarget(p);return p;}
 @GameTest(template="test_empty",timeoutTicks=60)
 public static void vanillaHostileJoinsRejectedPassivesAndNetherKept(GameTestHelper h){
  var level=h.getLevel();
  for(var type:List.of(EntityType.ZOMBIE,EntityType.SKELETON,EntityType.CREEPER,EntityType.SPIDER,EntityType.ENDERMAN,EntityType.SLIME,EntityType.PHANTOM,EntityType.PILLAGER,EntityType.GHAST,EntityType.BLAZE,EntityType.VEX)){
   var e=type.create(level);e.setPos(h.absolutePos(new BlockPos(2,3,2)).getCenter());h.assertTrue(OverworldMobPolicy.forbidden(e,level),"Vanilla hostile covered: "+type);h.assertFalse(level.addFreshEntity(e),"Real EntityJoinLevel event rejects vanilla hostile, including manual spawns");
  }
  var pig=EntityType.PIG.create(level);pig.setPos(h.absolutePos(new BlockPos(2,3,2)).getCenter());h.assertFalse(OverworldMobPolicy.forbidden(pig,level),"Passive vanilla remains permitted");h.assertTrue(level.addFreshEntity(pig),"Passive vanilla can actually join");pig.discard();
  var nether=level.getServer().getLevel(net.minecraft.world.level.Level.NETHER);var zombie=EntityType.ZOMBIE.create(nether);h.assertFalse(OverworldMobPolicy.forbidden(zombie,nether),"Vanilla hostile Nether roster unaffected");
  for(var r:BiomeMobs.ENTITIES.values()){var e=r.get().create(level);h.assertFalse(OverworldMobPolicy.forbidden(e,level),"Actual mod-owned creatures permitted");}h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=60)
 public static void oldSpawnerConvertedAndNativeSpawnerPreserved(GameTestHelper h){
  var rel=new BlockPos(2,3,2);h.setBlock(rel,Blocks.SPAWNER);var pos=h.absolutePos(rel);var be=(SpawnerBlockEntity)h.getLevel().getBlockEntity(pos);be.setEntityId(EntityType.SKELETON,h.getLevel().random);
  h.assertTrue(SpawnerMigration.convert(h.getLevel(),pos,be),"Old vanilla hostile spawner converted");var tag=be.getSpawner().save(new CompoundTag());String id=tag.getCompound("SpawnData").getCompound("entity").getString("id");h.assertTrue(id.startsWith("hinaland:"),"Saved spawner is now a real mod-owned entity");h.assertTrue(tag.getCompound("SpawnData").contains("custom_spawn_rules"),"Converted dungeon bypasses surface-only natural placement");
  h.assertFalse(SpawnerMigration.convert(h.getLevel(),pos,be),"Migration is idempotent and does not overwrite native encounters");h.assertTrue(SpawnerMigration.replacement("genshin").equals("hilichurl")&&SpawnerMigration.replacement("overwatch").equals("null_trooper"),"Old Genshin/Overwatch encounters keep their own universe");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=80)
 public static void newRangedEnemiesShootPhysicalProjectiles(GameTestHelper h){
  for(String id:List.of("magikoopa","hammer_bro","crabmeat","newtron","egg_pawn","marsha","clover","werewire","virovirokun","ruin_guard","null_trooper")){
   h.killAllEntities();var e=mob(h,id);target(h,e,2);h.assertTrue(e.hasLineOfSight(e.getTarget()),"Clear ranged fixture line of sight for "+id);e.ability.tick(e);var shots=h.getLevel().getEntitiesOfClass(DarknerProjectile.class,new AABB(e.blockPosition()).inflate(4));int expected=Set.of("crabmeat","clover","ruin_guard").contains(id)?3:1;
   h.assertTrue(shots.size()==expected,"Actual projectile count for "+id);for(var shot:shots)h.assertTrue(shot.getOwner()==e&&!shot.getItem().isEmpty()&&shot.getDeltaMovement().lengthSqr()>0,"Physical projectile has owner, visible item and velocity");
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=100)
 public static void fusePersistsAndExplosionPreservesStructures(GameTestHelper h){
  for(String id:List.of("bobomb","null_detonator")){
   h.killAllEntities();var e=mob(h,id);target(h,e,1.5);e.ability.tick(e);h.assertTrue(e.behaviorState()==3&&e.ability.armedTicks()>0,"Close target starts warned fuse");
   var tag=new CompoundTag();e.saveWithoutId(tag);var copy=BiomeMobs.ENTITIES.get(id).get().create(h.getLevel());copy.load(tag);h.assertTrue(copy.ability.armedTicks()==e.ability.armedTicks(),"Armed countdown survives save/load");
   var rel=new BlockPos(3,3,2);h.setBlock(rel,Blocks.STONE_BRICKS);for(int i=0;i<60&&!e.isRemoved();i++)e.ability.tick(e);h.assertTrue(e.isRemoved(),"Fuse really explodes and consumes the attacker");h.assertBlockPresent(Blocks.STONE_BRICKS,rel);
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=80)
 public static void booGazeAndNewtronCloak(GameTestHelper h){
  h.killAllEntities();var boo=mob(h,"boo");var player=target(h,boo,-1.5);player.lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES,boo.getEyePosition());boo.ability.tick(boo);h.assertTrue(boo.behaviorState()==5&&CreatureExpansion.meleeBlocked(boo),"Looked-at Boo stops attacking");
  player.setYRot(180);player.setYHeadRot(180);boo.ability.tick(boo);h.assertTrue(boo.behaviorState()==0,"Boo resumes after player looks away");
  boo.discard();var newtron=mob(h,"newtron");target(h,newtron,2);newtron.ability.tick(newtron);newtron.ability.tick(newtron);h.assertTrue(newtron.isInvisible(),"Newtron cloaks after firing");for(int i=0;i<26;i++)newtron.ability.tick(newtron);h.assertFalse(newtron.isInvisible(),"Cloak is bounded and becomes visible again");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=80)
 public static void ruinGuardWeakPointAndSpinyDefense(GameTestHelper h){
  h.killAllEntities();var guard=mob(h,"ruin_guard");var arrow=new net.minecraft.world.entity.projectile.Arrow(h.getLevel(),guard.getX(),guard.getY()+guard.getBbHeight()*.9,guard.getZ());guard.hurt(h.getLevel().damageSources().arrow(arrow,null),4);h.assertTrue(guard.behaviorState()==4,"Eye-height projectile interrupts ruin guard");
  var tag=new CompoundTag();guard.saveWithoutId(tag);h.assertTrue(tag.getInt("DisabledTicks")==80,"Weak point disables for four seconds");guard.discard();var spiny=mob(h,"spiny");var player=target(h,spiny,1);float health=player.getHealth();CreatureExpansion.incomingDamage(spiny,h.getLevel().damageSources().playerAttack(player),1);h.assertTrue(player.getHealth()<health,"Directly striking spikes hurts attacker");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=80)
 public static void plantAndElementalContactAbilities(GameTestHelper h){
  var plant=mob(h,"piranha_plant");var player=target(h,plant,1);h.assertTrue(plant.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)==0,"Rooted plant cannot pursue through navigation");float health=player.getHealth();plant.ability.tick(plant);h.assertTrue(player.getHealth()<health,"Rooted plant can actually bite close targets");plant.discard();
  var pyro=mob(h,"pyro_slime");h.assertTrue(pyro.fireImmune(),"Pyroblob immune to fire");CreatureExpansion.contact(pyro,player);h.assertTrue(player.isOnFire(),"Pyro contact burns target without igniting terrain");pyro.discard();var cryo=mob(h,"cryo_slime");CreatureExpansion.contact(cryo,player);h.assertTrue(player.hasEffect(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN),"Cryo contact slows target");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=80)
 public static void allSixNewDarknersCanBeSpared(GameTestHelper h){
  for(var spec:CreatureExpansion.SPECS)if(spec.family().equals("deltarune")){
   h.killAllEntities();var e=mob(h,spec.id());var player=target(h,e,2);player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,ItemStack.EMPTY);h.assertTrue(e.interact(player,net.minecraft.world.InteractionHand.MAIN_HAND).consumesAction(),"Native ACT interaction for "+spec.id());h.assertTrue(e.getTarget()==null&&e.isCalm(),"Spared enemy clears target and abilities");e.ability.tick(e);h.assertTrue(h.getLevel().getEntitiesOfClass(DarknerProjectile.class,new AABB(e.blockPosition()).inflate(8)).isEmpty(),"Spared Darkner cannot continue shooting");
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=80)
 public static void virovirokunHealsAndMoleBurrows(GameTestHelper h){
  var medic=mob(h,"virovirokun");target(h,medic,6);var friend=mob(h,"jigsawry");friend.setHealth(5);medic.ability.tick(medic);h.assertTrue(friend.getHealth()==7,"Virovirokun healing reaches nearby Darkners");friend.discard();medic.discard();var mole=mob(h,"monty_mole");var player=target(h,mole,8);mole.ability.tick(mole);h.assertTrue(mole.isInvisible()&&mole.behaviorState()==6,"Far target triggers burrowing visual");player.setPos(mole.getX(),mole.getY(),mole.getZ()+2);mole.ability.tick(mole);h.assertFalse(mole.isInvisible(),"Close target makes mole emerge");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=60)
 public static void throwableHammerConsumesAmmoAndCreatesProjectile(GameTestHelper h){
  h.killAllEntities();var player=h.makeMockSurvivalPlayer();player.setPos(h.absolutePos(new BlockPos(2,3,2)).getCenter());var stack=new ItemStack(HinaLand.item("mario_hammer"),2);player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,stack);stack.use(h.getLevel(),player,net.minecraft.world.InteractionHand.MAIN_HAND);
  h.assertTrue(stack.getCount()==1&&player.getCooldowns().isOnCooldown(stack.getItem()),"Player hammer consumes one item and prevents immediate spam");var shots=h.getLevel().getEntitiesOfClass(DarknerProjectile.class,new AABB(player.blockPosition()).inflate(3));h.assertTrue(shots.size()==1&&shots.get(0).getOwner()==player&&shots.get(0).getItem().is(HinaLand.item("mario_hammer")),"Actual throwable hammer projectile uses the player and its visible item");h.succeed();
 }
}
