package fr.hinaland;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.*;
import net.minecraft.world.level.levelgen.structure.pieces.*;
import net.minecraft.world.level.levelgen.structure.templatesystem.*;
import net.minecraftforge.registries.*;

/** One intact template, only on dry, nearly flat terrain, with foundations under its footprint. */
public final class GroundedStructure extends Structure {
 public static final Codec<GroundedStructure> CODEC=RecordCodecBuilder.create(i->i.group(settingsCodec(i),
  ResourceLocation.CODEC.fieldOf("template").forGetter((GroundedStructure s)->s.template),
  Codec.intRange(0,6).fieldOf("max_slope").forGetter((GroundedStructure s)->s.maxSlope)).apply(i,GroundedStructure::new));
 public static final DeferredRegister<StructureType<?>> TYPES=DeferredRegister.create(Registries.STRUCTURE_TYPE,HinaLand.ID);
 public static final RegistryObject<StructureType<GroundedStructure>> TYPE=TYPES.register("grounded",()->()->CODEC);
 public static final DeferredRegister<StructurePieceType> PIECES=DeferredRegister.create(Registries.STRUCTURE_PIECE,HinaLand.ID);
 public static final RegistryObject<StructurePieceType> PIECE=PIECES.register("grounded_piece",()->(context,nbt)->new Piece(context.structureTemplateManager(),nbt));
 private final ResourceLocation template;
 private final int maxSlope;
 public GroundedStructure(StructureSettings settings,ResourceLocation template,int maxSlope){super(settings);this.template=template;this.maxSlope=maxSlope;}
 public ResourceLocation templateId(){return template;}
 @Override public StructureType<?> type(){return TYPE.get();}
 @Override protected Optional<GenerationStub> findGenerationPoint(GenerationContext c){
  var t=c.structureTemplateManager().getOrCreate(template);var size=t.getSize();if(size.getX()==0)return Optional.empty();
  var rotation=Rotation.getRandom(c.random());var settings=Piece.settings(rotation);
  BlockPos anchor=new BlockPos(c.chunkPos().getMinBlockX()+8,0,c.chunkPos().getMinBlockZ()+8);var bb=t.getBoundingBox(settings,anchor);
  int low=Integer.MAX_VALUE,high=Integer.MIN_VALUE;
  // Query every footprint column before a structure is admitted, not just its centre.
  for(int x=bb.minX();x<=bb.maxX();x++)for(int z=bb.minZ();z<=bb.maxZ();z++){
   var column=c.chunkGenerator().getBaseColumn(x,z,c.heightAccessor(),c.randomState());
   int floor=c.heightAccessor().getMaxBuildHeight();
   while(floor>c.heightAccessor().getMinBuildHeight()+12&&column.getBlock(floor-1).isAir())floor--;
   if(floor<=c.heightAccessor().getMinBuildHeight()+12||!column.getBlock(floor-1).getFluidState().isEmpty())return Optional.empty();
   low=Math.min(low,floor);high=Math.max(high,floor);if(high-low>maxSlope)return Optional.empty();
   var biome=c.biomeSource().getNoiseBiome(Math.floorDiv(x,4),Math.floorDiv(floor,4),Math.floorDiv(z,4),c.randomState().sampler());
   if(!c.validBiome().test(biome))return Optional.empty();
  }
  // Source templates have three basal terrain layers: bury them, keeping the usable floor at ground level.
  BlockPos pos=anchor.atY(high-3);
  return Optional.of(new GenerationStub(pos,b->b.addPiece(new Piece(c.structureTemplateManager(),template,pos,rotation))));
 }
 public static final class Piece extends TemplateStructurePiece {
  public Piece(StructureTemplateManager manager,ResourceLocation id,BlockPos pos,Rotation rotation){super(PIECE.get(),0,manager,id,id.toString(),settings(rotation),pos);}
  public Piece(StructureTemplateManager manager,CompoundTag nbt){super(PIECE.get(),nbt,manager,id->settings(Rotation.valueOf(nbt.getString("HinaRotation"))));}
  public static StructurePlaceSettings settings(Rotation rotation){return new StructurePlaceSettings().setRotation(rotation).addProcessor(BlockIgnoreProcessor.STRUCTURE_AND_AIR);}
  @Override protected void addAdditionalSaveData(StructurePieceSerializationContext c,CompoundTag n){super.addAdditionalSaveData(c,n);n.putString("HinaRotation",getRotation().name());}
  @Override protected void handleDataMarker(String name,BlockPos p,ServerLevelAccessor l,RandomSource r,BoundingBox box){}
  public static int supportColumn(WorldGenLevel level,BlockPos base,net.minecraft.world.level.block.state.BlockState foundation){
   int count=0;for(int depth=1;depth<=8;depth++){
    var p=base.below(depth);var state=level.getBlockState(p);if(!state.isAir()&&state.getFluidState().isEmpty())break;
    level.setBlock(p,foundation,2);count++;
   }return count;
  }
  @Override public void postProcess(WorldGenLevel l,StructureManager sm,ChunkGenerator g,RandomSource random,BoundingBox box,ChunkPos cp,BlockPos p){
   super.postProcess(l,sm,g,random,box,cp,p);
   // Fill only beneath real template support blocks; never create a floating rectangular plate.
   var base=templatePosition.getY();var mutable=new BlockPos.MutableBlockPos();
   String family=new ResourceLocation(templateName).getPath().split("_")[0];var foundation=HinaLand.WORLD_BLOCKS.get(family+"_stone").get().defaultBlockState();
   for(int x=boundingBox.minX();x<=boundingBox.maxX();x++)for(int z=boundingBox.minZ();z<=boundingBox.maxZ();z++){
    if(!box.isInside(mutable.set(x,base,z)))continue;
    if(l.getBlockState(mutable).getCollisionShape(l,mutable).isEmpty())continue;
    supportColumn(l,new BlockPos(x,base,z),foundation);
   }
  }
 }
}
