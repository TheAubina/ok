package fr.hinaland;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Small rare covered salvage outpost; stays within the normal decoration neighborhood. */
public final class LethalFacilityFeature extends Feature<NoneFeatureConfiguration>{
 public LethalFacilityFeature(){super(NoneFeatureConfiguration.CODEC);}
 @Override public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c){
  var level=c.level();BlockPos o=c.origin();int y=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,o.getX()+4,o.getZ()+4);
  if(y<level.getSeaLevel()||y+7>=level.getMaxBuildHeight())return false;
  BlockPos base=new BlockPos(o.getX(),y,o.getZ());
  // Reject slopes rather than burying the room or placing it over a cliff.
  for(int dx:new int[]{0,8})for(int dz:new int[]{0,8})if(Math.abs(level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,base.getX()+dx,base.getZ()+dz)-y)>3)return false;
  for(int dx=0;dx<=8;dx++)for(int dz=0;dz<=8;dz++){
   for(int dy=-4;dy<0;dy++){var p=base.offset(dx,dy,dz);if(level.getBlockState(p).isAir()||!level.getFluidState(p).isEmpty())level.setBlock(p,Blocks.STONE_BRICKS.defaultBlockState(),2);}
   for(int dy=-1;dy<=6;dy++)level.setBlock(base.offset(dx,dy,dz),(dy==-1||dy==6||dx==0||dx==8||dz==0||dz==8)?Blocks.STONE_BRICKS.defaultBlockState():Blocks.AIR.defaultBlockState(),2);
  }
  level.setBlock(base.offset(4,0,0),Blocks.AIR.defaultBlockState(),2);level.setBlock(base.offset(4,1,0),Blocks.AIR.defaultBlockState(),2);
  BlockPos chest=base.offset(6,0,6);level.setBlock(chest,Blocks.CHEST.defaultBlockState(),2);
  if(level.getBlockEntity(chest) instanceof ChestBlockEntity loot)loot.setLootTable(new ResourceLocation(HinaLand.ID,"chests/lethal_facility"),c.random().nextLong());
  if(level.getLevel().getDifficulty()!=net.minecraft.world.Difficulty.PEACEFUL){
   for(int i=0;i<2;i++){String kind=i==0?"hoarding_bug":LethalMobs.NAMES[c.random().nextInt(LethalMobs.NAMES.length)];var mob=LethalMobs.ENTITIES.get(kind).get().create(level.getLevel());if(mob!=null){mob.moveTo(base.getX()+2.5+i*3,base.getY(),base.getZ()+2.5,0,0);level.addFreshEntity(mob);}}
  }
  return true;
 }
}
