package fr.hinaland;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.BlockStateConfiguration;
import net.minecraftforge.registries.*;

/** Keep cave biomes and minerals while theming the host rock beneath themed surface columns. */
public final class ThemedGeology extends Feature<BlockStateConfiguration> {
 public static final DeferredRegister<Feature<?>> FEATURES=DeferredRegister.create(ForgeRegistries.FEATURES,HinaLand.ID);
 public static final RegistryObject<Feature<?>> GEOLOGY=FEATURES.register("themed_geology",ThemedGeology::new);
 public static final RegistryObject<Feature<?>> FACILITY=FEATURES.register("lethal_facility",LethalFacilityFeature::new);
 public ThemedGeology(){super(BlockStateConfiguration.CODEC);}
 @Override public boolean place(FeaturePlaceContext<BlockStateConfiguration> context){
  var level=context.level();var origin=context.origin();var stone=context.config().state;
  String family=ForgeRegistries.BLOCKS.getKey(stone.getBlock()).getPath().replace("_stone","");
  BlockPos.MutableBlockPos p=new BlockPos.MutableBlockPos();boolean changed=false;
  for(int dx=0;dx<16;dx++)for(int dz=0;dz<16;dz++){
   int x=origin.getX()+dx,z=origin.getZ()+dz,top=level.getHeight(Heightmap.Types.WORLD_SURFACE_WG,x,z);
   var biome=level.getBiome(p.set(x,top,z)).unwrapKey().orElseThrow().location();if(!HinaWorldgen.family(biome).equals(family))continue;
   for(int y=level.getMinBuildHeight();y<top;y++){
    var state=level.getBlockState(p.set(x,y,z));
    if(state.is(Blocks.STONE)||state.is(Blocks.DEEPSLATE)){level.setBlock(p,stone,2);changed=true;}
    else if(state.is(Blocks.BEDROCK)){level.setBlock(p,HinaLand.WORLD_BLOCKS.get(family+"_bedrock").get().defaultBlockState(),2);changed=true;}
   }
  }
  return changed;
 }
}
