package fr.hinaland.test;

import fr.hinaland.*;
import java.util.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.levelgen.structure.templatesystem.*;
import net.minecraftforge.gametest.*;

/** Real template placement and chest reward generation, not just JSON counts. */
@GameTestHolder("hinaland") @PrefixGameTestTemplate(false)
public class UniverseStructureGameTests {
 private static final String[][] IDS={
 {"toad_house","peach_gatehouse","bobomb_watchtower","yoshi_stable","underground_pipeworks","desert_pyramid","boo_manor","beanbean_market","delfino_fountain","airship_wreck"},
 {"green_hill_loop","tails_workshop","chemical_plant_station","angel_island_altar","casino_night_arcade","hydrocity_aqueduct","stardust_speedway_gate","oil_ocean_refinery","ice_cap_shelter","death_egg_outpost"},
 {"basil_greenhouse","neighbor_room","otherworld_campsite","spaceboy_observatory","sweetheart_keep","pyrefly_lantern_walk","orange_oasis_ruin","snowglobe_cottage","last_resort_kiosk","deeper_well_shrine"},
 {"castle_town_bakery","card_castle_keep","field_hopes_pavilion","forest_checker_bridge","cyber_city_crossing","spamton_shop","queen_signal_tower","mansion_basement","music_stage","hometown_bookshop"},
 {"mondstadt_windmill","dawn_winery_lodge","liyue_harbor_pavilion","wangshu_waystation","inazuma_torii","sumeru_study","fontaine_clockwork","dragonspine_camp","hilichurl_encampment","ruin_guard_hall"},
 {"gibraltar_launchpad","hanamura_gate","kings_row_pub","route66_diner","ilios_bell_tower","lijiang_control","numbani_transit","eichenwalde_gatehouse","volskaya_machinehall","busan_music_square"},
 {"landing_shuttle","assurance_pump","vow_dam","experimentation_rail","rend_lampposts","dine_checkpoint","titan_stairway","artifice_warehouse_yard","embrion_relay","company_loading_dock"}};
 private static boolean standable(net.minecraft.server.level.ServerLevel level,BlockPos pos){
  var shape=level.getBlockState(pos).getCollisionShape(level,pos);double height=shape.isEmpty()?0:shape.max(Direction.Axis.Y);if(height>.6)return false;
  if(height==0&&level.getBlockState(pos.below()).getCollisionShape(level,pos.below()).isEmpty())return false;
  return level.noCollision(new net.minecraft.world.phys.AABB(pos.getX()+.2,pos.getY()+height+.002,pos.getZ()+.2,pos.getX()+.8,pos.getY()+height+1.8,pos.getZ()+.8));
 }
 private static boolean reachable(net.minecraft.server.level.ServerLevel level,BlockPos anchor,StructurePlaceSettings settings,BlockPos chest){
  var queue=new ArrayDeque<BlockPos>();var seen=new HashSet<BlockPos>();queue.add(new BlockPos(6,3,0));
  while(!queue.isEmpty()){
   var local=queue.remove();if(!seen.add(local))continue;var p=anchor.offset(StructureTemplate.calculateRelativePosition(settings,local));if(!standable(level,p))continue;
   if(p.distSqr(chest)<=5&&Math.abs(p.getY()-chest.getY())<=1)return true;
   for(var d:List.of(Direction.NORTH,Direction.SOUTH,Direction.EAST,Direction.WEST))for(int dy=-1;dy<=1;dy++){
    var next=local.relative(d).offset(0,dy,0);if(next.getX()>=0&&next.getX()<=10&&next.getZ()>=0&&next.getZ()<=10&&next.getY()>=3&&next.getY()<=14&&!seen.contains(next))queue.add(next);
   }
  }return false;
 }
 private static void family(GameTestHelper h,int index){
  var world=h.getLevel();String family=HinaWorldgen.FAMILIES.get(index);var registry=world.registryAccess().registryOrThrow(Registries.STRUCTURE);var player=h.makeMockSurvivalPlayer();int dungeonCount=0;
  var tag=net.minecraft.tags.TagKey.create(Registries.STRUCTURE,new ResourceLocation(HinaLand.ID,family+"_new_landmarks"));var tagged=registry.getTag(tag).orElseThrow();h.assertTrue(tagged.size()==10,"Locate tag contains ten NEW structures only");
  for(int i=0;i<10;i++){
   String id=family+"_"+IDS[index][i];var resource=new ResourceLocation(HinaLand.ID,id);
   h.assertTrue(tagged.contains(registry.getHolderOrThrow(net.minecraft.resources.ResourceKey.create(Registries.STRUCTURE,resource))),"New structure belongs to its universe locate tag");
   h.assertTrue(registry.get(resource) instanceof GroundedStructure,"New structure is really registered for terrain checks: "+id);
   var template=world.getStructureManager().get(resource).orElseThrow();h.assertTrue(template.getSize().getX()<=11&&template.getSize().getZ()<=11,"Compact footprint admits sloping terrain without giant flat platforms");
   int ri=0;
   for(var rotation:Rotation.values()){
    var anchor=new BlockPos(3000+index*400+i*32,140,3000+ri*32);var settings=GroundedStructure.Piece.settings(rotation);
    var box=template.getBoundingBox(settings,anchor);for(int cx=Math.floorDiv(box.minX(),16);cx<=Math.floorDiv(box.maxX(),16);cx++)for(int cz=Math.floorDiv(box.minZ(),16);cz<=Math.floorDiv(box.maxZ(),16);cz++)world.getChunk(cx,cz);
    h.assertTrue(template.placeInWorld(world,anchor,anchor,settings,world.random,2),"Actual authored structure placed: "+id+" / "+rotation);
    var raw=template.save(new CompoundTag());var blocks=raw.getList("blocks",10);
    for(int bi=0;bi<blocks.size();bi++){var coords=blocks.getCompound(bi).getList("pos",3);var local=new BlockPos(coords.getInt(0),coords.getInt(1),coords.getInt(2));if(local.getY()<3)continue;
     var bp=anchor.offset(StructureTemplate.calculateRelativePosition(settings,local));var state=world.getBlockState(bp);h.assertFalse(state.isAir(),"Authored decorative block survives actual placement: "+id+" / "+local);h.assertTrue(state.canSurvive(world,bp),"Lantern, flower, ladder, sign or rail has real support: "+id+" / "+local);
    }
    var chests=template.filterBlocks(anchor,settings,Blocks.CHEST);h.assertTrue(chests.size()==1,"One accessible reward chest per new structure");
    var cp=chests.get(0).pos();h.assertTrue(world.getBlockEntity(cp) instanceof ChestBlockEntity,"Chest block entity survives production placement and rotation");
    h.assertFalse(world.getBlockState(cp.above()).isRedstoneConductor(world,cp.above()),"Chest lid is unobstructed: "+id);
    h.assertTrue(reachable(world,anchor,settings,cp),"Reward is reachable on foot through clear passages and steps: "+id+" / "+rotation);
    var chest=(ChestBlockEntity)world.getBlockEntity(cp);chest.unpackLootTable(player);boolean reward=false;for(int slot=0;slot<chest.getContainerSize();slot++)reward|=!chest.getItem(slot).isEmpty();h.assertTrue(reward,"Server actually resolves the universe loot table: "+id);
    var spawners=template.filterBlocks(anchor,settings,Blocks.SPAWNER);if(ri==0)dungeonCount+=spawners.size();
    for(var sp:spawners){var be=(SpawnerBlockEntity)world.getBlockEntity(sp.pos());h.assertTrue(be!=null,"Real dungeon spawner loads");var data=be.getSpawner().save(new CompoundTag());h.assertTrue(data.getCompound("SpawnData").contains("custom_spawn_rules"),"Dungeon does not incorrectly apply surface-only natural placement predicates");h.assertTrue(data.getShort("MaxNearbyEntities")==3&&data.getShort("SpawnCount")==1,"Bounded encounter population");}
    if(index==6)h.assertTrue(spawners.isEmpty(),"Lethal additions are exterior landmarks with no new dungeons or outdoor monster spawners");
    ri++;
   }
  }h.assertTrue(dungeonCount==(index==6?0:2),"Two new surface dungeons per non-Lethal universe");h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=200) public static void marioTenNewStructures(GameTestHelper h){family(h,0);}
 @GameTest(template="test_empty",timeoutTicks=200) public static void sonicTenNewStructures(GameTestHelper h){family(h,1);}
 @GameTest(template="test_empty",timeoutTicks=200) public static void omoriTenNewStructures(GameTestHelper h){family(h,2);}
 @GameTest(template="test_empty",timeoutTicks=200) public static void deltaruneTenNewStructures(GameTestHelper h){family(h,3);}
 @GameTest(template="test_empty",timeoutTicks=200) public static void genshinTenNewStructures(GameTestHelper h){family(h,4);}
 @GameTest(template="test_empty",timeoutTicks=200) public static void overwatchTenNewStructures(GameTestHelper h){family(h,5);}
 @GameTest(template="test_empty",timeoutTicks=200) public static void lethalTenNewExteriors(GameTestHelper h){family(h,6);}
 @GameTest(template="test_empty",timeoutTicks=120)
 public static void waterLandmarksDoNotFloodTheirSurroundings(GameTestHelper h){
  var level=h.getLevel();int i=0;
  for(String name:List.of("mario_delfino_fountain","sonic_hydrocity_aqueduct","lethal_vow_dam")){
   var anchor=new BlockPos(12000+i*48,200,12000);for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)level.getChunk(anchor.offset(x*16,0,z*16));
   var template=level.getStructureManager().get(new ResourceLocation(HinaLand.ID,name)).orElseThrow();h.assertTrue(template.placeInWorld(level,anchor,anchor,GroundedStructure.Piece.settings(Rotation.NONE),level.random,2),"Water landmark placed");
   for(int pass=0;pass<8;pass++)for(int y=7;y>=3;y--)for(int x=-2;x<=12;x++)for(int z=-2;z<=12;z++){
    var pos=anchor.offset(x,y,z);var fluid=level.getFluidState(pos);if(!fluid.isEmpty())fluid.tick(level,pos);
   }
   for(int y=3;y<=7;y++)for(int x=-2;x<=12;x++)for(int z=-2;z<=12;z++)if(x<0||x>10||z<0||z>10)h.assertTrue(level.getFluidState(anchor.offset(x,y,z)).isEmpty(),"Real fluid updates remain contained in the fountain/channel: "+name);
   i++;
  }h.succeed();
 }
 @GameTest(template="test_empty",timeoutTicks=200)
 public static void dungeonSpawnersProduceTheirActualEntities(GameTestHelper h){
  var level=h.getLevel();var difficulty=level.getDifficulty();level.getServer().setDifficulty(net.minecraft.world.Difficulty.NORMAL,true);
  String[] names={"mario_desert_pyramid","mario_boo_manor","sonic_chemical_plant_station","sonic_death_egg_outpost","omori_sweetheart_keep","omori_orange_oasis_ruin","deltarune_card_castle_keep","deltarune_mansion_basement","genshin_hilichurl_encampment","genshin_ruin_guard_hall","overwatch_eichenwalde_gatehouse","overwatch_volskaya_machinehall"};
  for(int i=0;i<names.length;i++){
   var template=level.getStructureManager().get(new ResourceLocation(HinaLand.ID,names[i])).orElseThrow();var anchor=new BlockPos(8000+i*32,180,8000);level.getChunk(anchor);level.getChunk(anchor.offset(16,0,16));
   var settings=GroundedStructure.Piece.settings(Rotation.NONE);h.assertTrue(template.placeInWorld(level,anchor,anchor,settings,level.random,2),"Encounter template placed");
   var pos=template.filterBlocks(anchor,settings,Blocks.SPAWNER).get(0).pos();var be=(SpawnerBlockEntity)level.getBlockEntity(pos);var tag=be.getSpawner().save(new CompoundTag());String id=tag.getCompound("SpawnData").getCompound("entity").getString("id");
   // Centre of a clear tile inside the room; no chunk ticking or natural-spawn assumptions.
   var entity=net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation(id));var player=net.minecraftforge.common.util.FakePlayerFactory.get(level,new com.mojang.authlib.GameProfile(UUID.randomUUID(),"dungeon-test"));level.addNewPlayer(player);player.setGameMode(net.minecraft.world.level.GameType.SURVIVAL);player.setPos(pos.getX()+2.5,pos.getY(),pos.getZ()-.5);h.assertTrue(level.hasNearbyAlivePlayer(pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5,12),"Real server player activates spawner");
   var area=new net.minecraft.world.phys.AABB(pos).inflate(8);boolean spawned=false;
   for(int attempt=0;attempt<30&&!spawned;attempt++){
    tag.putShort("Delay",(short)0);be.getSpawner().load(level,pos,tag);be.getSpawner().serverTick(level,pos);
    spawned=level.getEntitiesOfClass(net.minecraft.world.entity.Mob.class,area,m->m.getType()==entity).size()>0;
   }
   level.removePlayerImmediately(player,net.minecraft.world.entity.Entity.RemovalReason.DISCARDED);h.assertTrue(spawned,"Actual BaseSpawner creates dungeon entity despite daytime/surface-only natural rules: "+names[i]+" / "+id);
   for(var mob:level.getEntitiesOfClass(net.minecraft.world.entity.Mob.class,area))mob.discard();
  }
  level.getServer().setDifficulty(difficulty,true);h.succeed();
 }
}
