package fr.hinaland;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Enforce the requested Overworld roster, including saved mobs, raids and external spawn sources. */
@Mod.EventBusSubscriber(modid=HinaLand.ID)
public final class OverworldMobPolicy {
 public static boolean forbidden(net.minecraft.world.entity.Entity entity,Level level){
  if(!level.dimension().equals(Level.OVERWORLD)||!(entity instanceof Mob))return false;
  var id=ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
  return id!=null&&id.getNamespace().equals("minecraft")&&(entity instanceof Enemy||entity.getType().getCategory()==MobCategory.MONSTER);
 }
 @SubscribeEvent public static void join(EntityJoinLevelEvent event){
  if(event.getLevel() instanceof ServerLevel&&forbidden(event.getEntity(),event.getLevel()))event.setCanceled(true);
 }
}
