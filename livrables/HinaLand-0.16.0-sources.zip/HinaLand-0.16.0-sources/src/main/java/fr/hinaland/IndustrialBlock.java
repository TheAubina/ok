package fr.hinaland;
import net.minecraft.core.*;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.phys.shapes.*;
/** Imported industrial geometry with matching rotated collision, not a disguised full cube. */
public final class IndustrialBlock extends HorizontalDirectionalBlock {
 private final VoxelShape[] shapes=new VoxelShape[4];
 public IndustrialBlock(VoxelShape shape,int light){super(BlockBehaviour.Properties.of().strength(2.5f,6f).sound(SoundType.METAL).noOcclusion().lightLevel(s->light));
  registerDefaultState(stateDefinition.any().setValue(FACING,Direction.NORTH));shapes[0]=shape;
  for(int i=1;i<4;i++){var parts=new java.util.ArrayList<VoxelShape>();shapes[i-1].forAllBoxes((x1,y1,z1,x2,y2,z2)->parts.add(Shapes.box(1-z2,y1,x1,1-z1,y2,x2)));shapes[i]=parts.stream().reduce(Shapes.empty(),Shapes::or);}
 }
 private int index(BlockState s){return switch(s.getValue(FACING)){case EAST->1;case SOUTH->2;case WEST->3;default->0;};}
 @Override public VoxelShape getShape(BlockState s,BlockGetter l,BlockPos p,CollisionContext c){return shapes[index(s)].isEmpty()?Block.box(4,0,4,12,8,12):shapes[index(s)];}
 @Override public VoxelShape getCollisionShape(BlockState s,BlockGetter l,BlockPos p,CollisionContext c){return shapes[index(s)];}
 @Override public BlockState getStateForPlacement(BlockPlaceContext c){return defaultBlockState().setValue(FACING,c.getHorizontalDirection().getOpposite());}
 @Override public BlockState rotate(BlockState s,Rotation r){return s.setValue(FACING,r.rotate(s.getValue(FACING)));}
 @Override public BlockState mirror(BlockState s,Mirror m){return s.rotate(m.getRotation(s.getValue(FACING)));}
 @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){b.add(FACING);}
}
