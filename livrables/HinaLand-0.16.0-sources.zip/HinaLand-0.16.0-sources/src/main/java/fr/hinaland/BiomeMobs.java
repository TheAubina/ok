package fr.hinaland;
import java.util.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.*;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.*;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

@Mod.EventBusSubscriber(modid=HinaLand.ID,bus=Mod.EventBusSubscriber.Bus.MOD)
public final class BiomeMobs {
 public static final String[] NAMES=java.util.stream.Stream.concat(java.util.stream.Stream.of("goomba","koopa","motobug","buzz_bomber","sprout_mole","forest_bunny","dry_bones","pokey","rudinn","hathy"),CreatureExpansion.SPECS.stream().map(CreatureExpansion.Spec::id)).toArray(String[]::new);
 public static final DeferredRegister<EntityType<?>> TYPES=DeferredRegister.create(ForgeRegistries.ENTITY_TYPES,HinaLand.ID);
 public static final RegistryObject<EntityType<Omochao>> OMOCHAO=TYPES.register("omochao",()->EntityType.Builder.<Omochao>of(Omochao::new,MobCategory.CREATURE).sized(.6f,1.1f).clientTrackingRange(8).build(HinaLand.ID+":omochao"));
 public static final RegistryObject<EntityType<DarknerProjectile>> DARKNER_BOLT=TYPES.register("darkner_bolt",()->EntityType.Builder.<DarknerProjectile>of(DarknerProjectile::new,MobCategory.MISC).sized(.25f,.25f).clientTrackingRange(8).updateInterval(1).build(HinaLand.ID+":darkner_bolt"));
 public static final Map<String,RegistryObject<EntityType<ThemedEntity>>> ENTITIES=new LinkedHashMap<>();
 static {for(String id:NAMES)ENTITIES.put(id,TYPES.register(id,()->EntityType.Builder.<ThemedEntity>of((type,level)->new ThemedEntity(type,level,id),MobCategory.MONSTER).sized(CreatureExpansion.spec(id)==null?.7f:CreatureExpansion.spec(id).width(),CreatureExpansion.spec(id)==null?switch(id){case "dry_bones"->1.3f;case "pokey"->1.65f;case "goomba"->.8f;case "sprout_mole"->1f;case "koopa","rudinn","hathy"->1.25f;default->.8f;}:CreatureExpansion.spec(id).height()).clientTrackingRange(8).build(HinaLand.ID+":"+id)));}
 @SubscribeEvent public static void attributes(EntityAttributeCreationEvent e){e.put(OMOCHAO.get(),Omochao.attributes().build());for(var entry:ENTITIES.entrySet())e.put(entry.getValue().get(),Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH,CreatureExpansion.spec(entry.getKey())!=null?CreatureExpansion.spec(entry.getKey()).health():entry.getKey().equals("koopa")?24:16).add(Attributes.MOVEMENT_SPEED,entry.getKey().equals("piranha_plant")?0:java.util.Set.of("motobug","tasque","null_slicer","lost_sprout_mole").contains(entry.getKey())?.32:.23).add(Attributes.ATTACK_DAMAGE,3).add(Attributes.FOLLOW_RANGE,24).build());}
 @SubscribeEvent public static void placements(net.minecraftforge.event.entity.SpawnPlacementRegisterEvent e){e.register(OMOCHAO.get(),SpawnPlacements.Type.ON_GROUND,Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,(type,level,reason,pos,random)->level.getBlockState(pos.below()).is(net.minecraft.tags.BlockTags.DIRT),net.minecraftforge.event.entity.SpawnPlacementRegisterEvent.Operation.REPLACE);for(var r:ENTITIES.values())e.register(r.get(),SpawnPlacements.Type.ON_GROUND,Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,(type,level,reason,pos,random)->pos.getY()>=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,pos.getX(),pos.getZ())-2&&Monster.checkAnyLightMonsterSpawnRules(type,level,reason,pos,random),net.minecraftforge.event.entity.SpawnPlacementRegisterEvent.Operation.REPLACE);}
 public static String region(String id){if(CreatureExpansion.spec(id)!=null)return CreatureExpansion.spec(id).family();return switch(id){case "goomba","koopa","dry_bones","pokey"->"mario";case "motobug","buzz_bomber"->"sonic";case "rudinn","hathy"->"deltarune";default->"omori";};}
 public static class ThemedEntity extends Monster implements GeoEntity {
  public final String kind;
  private final AnimatableInstanceCache cache=GeckoLibUtil.createInstanceCache(this);
  private static final EntityDataAccessor<Integer> STATE=SynchedEntityData.defineId(ThemedEntity.class,EntityDataSerializers.INT);
  private int shotCooldown,disabledTicks,sparedTicks,chargeTicks;
  public final CreatureExpansion.Brain ability=new CreatureExpansion.Brain();
  public boolean isCalm(){return peaceful();}
  public void setBehaviorState(int state){entityData.set(STATE,state);}
  public void recoverFor(int ticks){disable(4,ticks);}
  private boolean previousNoAi;
  private Vec3 shellVelocity=Vec3.ZERO,chargeVelocity=Vec3.ZERO;
  public int behaviorState(){return entityData.get(STATE);}
  @Override protected void defineSynchedData(){super.defineSynchedData();entityData.define(STATE,0);}
  @Override public boolean fireImmune(){return "pyro_slime".equals(kind)||super.fireImmune();}
  public ThemedEntity(EntityType<? extends Monster> type,Level level,String kind){super(type,level);this.kind=kind;}
  private boolean peaceful(){return disabledTicks>0||sparedTicks>0;}
  private boolean ranged(){return CreatureExpansion.ranged(kind)||"rudinn".equals(kind)||"hathy".equals(kind)||"buzz_bomber".equals(kind);}
  @Override protected void registerGoals(){
   goalSelector.addGoal(0,new Goal(){
    {setFlags(EnumSet.of(Flag.MOVE));}
    @Override public boolean canUse(){return "buzz_bomber".equals(kind)&&getTarget()!=null&&distanceToSqr(getTarget())>9;}
    @Override public void start(){setNoGravity(true);}
    @Override public void stop(){setNoGravity(false);}
    @Override public void tick(){var target=getTarget();if(target!=null){var d=target.position().add(0,3,0).subtract(position());setDeltaMovement(d.normalize().scale(.18));}}
   });
   goalSelector.addGoal(1,new FloatGoal(this));
   goalSelector.addGoal(2,new MeleeAttackGoal(this,1.1,false){@Override public boolean canUse(){return !peaceful()&&!ranged()&&!CreatureExpansion.meleeBlocked(ThemedEntity.this)&&super.canUse();}@Override public boolean canContinueToUse(){return !peaceful()&&!ranged()&&!CreatureExpansion.meleeBlocked(ThemedEntity.this)&&super.canContinueToUse();}});
   goalSelector.addGoal(3,new Goal(){
    {setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
    @Override public boolean canUse(){return ranged()&&!peaceful()&&getTarget()!=null;}
    @Override public void tick(){var t=getTarget();if(t==null)return;getLookControl().setLookAt(t);if(distanceToSqr(t)>100)getNavigation().moveTo(t,1);else getNavigation().stop();}
   });
   goalSelector.addGoal(5,new WaterAvoidingRandomStrollGoal(this,.8));goalSelector.addGoal(6,new LookAtPlayerGoal(this,Player.class,8));goalSelector.addGoal(7,new RandomLookAroundGoal(this));
   targetSelector.addGoal(1,new HurtByTargetGoal(this));targetSelector.addGoal(2,new NearestAttackableTargetGoal<>(this,Player.class,10,true,false,p->!peaceful()));
  }
  private void disable(int state,int ticks){previousNoAi=isNoAi();disabledTicks=ticks;entityData.set(STATE,state);setNoAi(true);getNavigation().stop();setTarget(null);setDeltaMovement(Vec3.ZERO);}
  @Override public boolean hurt(net.minecraft.world.damagesource.DamageSource source,float amount){
   if(kind.equals("dry_bones")&&disabledTicks>0&&!source.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY))return false;
   if(kind.equals("dry_bones")&&amount>=getHealth()&&source.getEntity() instanceof LivingEntity){setHealth(getMaxHealth());disable(1,160);return true;}
   if(kind.equals("koopa")&&source.getEntity() instanceof Player p){
    if(disabledTicks==0)disable(2,160);
    else {Vec3 away=position().subtract(p.position()).multiply(1,0,1);if(away.lengthSqr()>0.01)shellVelocity=away.normalize().scale(.75);disabledTicks=160;}
    return true;
   }
   sparedTicks=0;return super.hurt(source,CreatureExpansion.incomingDamage(this,source,amount));
  }
  @Override protected InteractionResult mobInteract(Player player,InteractionHand hand){
   if(CreatureExpansion.spared(kind)&&player.getItemInHand(hand).isEmpty()){
    if(!level().isClientSide){sparedTicks=600;setTarget(null);getNavigation().stop();player.displayClientMessage(Component.literal("La créature accepte ton geste et cesse le combat."),true);}
    return InteractionResult.sidedSuccess(level().isClientSide);
   }
   return super.mobInteract(player,hand);
  }
  @Override public boolean doHurtTarget(Entity e){return !peaceful()&&!ranged()&&!CreatureExpansion.meleeBlocked(ThemedEntity.this)&&super.doHurtTarget(e);}
  private void darknerShot(Vec3 direction,boolean heart){var bolt=new DarknerProjectile(level(),this);bolt.setItem(new ItemStack(HinaLand.item(heart?"darkner_heart":"darkner_diamond")));bolt.setPos(getX(),getY()+.8,getZ());bolt.shoot(direction.x,direction.y,direction.z,.8f,0);level().addFreshEntity(bolt);}
  @Override public void tick(){
   super.tick();if(level().isClientSide)return;
   if(shotCooldown>0)shotCooldown--;if(sparedTicks>0){sparedTicks--;setTarget(null);getNavigation().stop();}
   if(disabledTicks>0){
    getNavigation().stop();setTarget(null);disabledTicks--;
    if(kind.equals("koopa")&&shellVelocity.lengthSqr()>.002){setDeltaMovement(shellVelocity.x,getDeltaMovement().y,shellVelocity.z);shellVelocity=shellVelocity.scale(.97);for(var victim:level().getEntitiesOfClass(LivingEntity.class,getBoundingBox().inflate(.15),e->e!=this))victim.hurt(damageSources().mobAttack(this),5);}
    if(disabledTicks==0){entityData.set(STATE,0);setNoAi(previousNoAi);shellVelocity=Vec3.ZERO;}
    return;
   }
   if((kind.equals("goomba")||kind.equals("koopa"))){for(var p:level().getEntitiesOfClass(Player.class,getBoundingBox().inflate(.35,1, .35))){if(p.getDeltaMovement().y<-.05&&p.getY()>=getY()+getBbHeight()-.35&&p.getY()<=getY()+getBbHeight()+.7){hurt(damageSources().playerAttack(p),20);p.setDeltaMovement(p.getDeltaMovement().x,.5,p.getDeltaMovement().z);p.fallDistance=0;break;}}}
   ability.tick(this);var target=getTarget();if(target==null||sparedTicks>0)return;
   if(kind.equals("buzz_bomber")&&hasLineOfSight(target)&&distanceToSqr(target)<256&&shotCooldown==0){var arrow=new net.minecraft.world.entity.projectile.Arrow(level(),this);arrow.setPos(getX(),getEyeY(),getZ());var d=target.getEyePosition().subtract(arrow.position());arrow.shoot(d.x,d.y,d.z,1.5f,6);arrow.setBaseDamage(2);arrow.pickup=net.minecraft.world.entity.projectile.AbstractArrow.Pickup.DISALLOWED;level().addFreshEntity(arrow);shotCooldown=60;}
   if((kind.equals("rudinn")||kind.equals("hathy"))&&hasLineOfSight(target)&&distanceToSqr(target)<256&&shotCooldown==0){
    Vec3 aim=target.position().add(0,.8,0).subtract(position().add(0,.8,0)).normalize();
    if(kind.equals("rudinn")){for(int i=-1;i<=1;i++)darknerShot(aim.yRot(i*.18f),false);}
    else for(int i=0;i<8;i++){double angle=i*Math.PI/4;darknerShot(new Vec3(Math.cos(angle),0,Math.sin(angle)),true);}
    shotCooldown=80;
   }
   if(kind.equals("motobug")){if(shotCooldown==0&&hasLineOfSight(target)&&distanceToSqr(target)<100){chargeVelocity=target.position().subtract(position()).multiply(1,0,1).normalize().scale(.48);chargeTicks=20;shotCooldown=100;}if(chargeTicks>0){chargeTicks--;getNavigation().stop();setDeltaMovement(chargeVelocity.x,getDeltaMovement().y,chargeVelocity.z);}}
   if(kind.equals("forest_bunny")&&shotCooldown==0&&onGround()&&distanceToSqr(target)<64){Vec3 d=target.position().subtract(position()).normalize();setDeltaMovement(d.x*.35,.45,d.z*.35);shotCooldown=50;}
  }
  @Override public void registerControllers(AnimatableManager.ControllerRegistrar c){c.add(new AnimationController<>(this,"locomotion",4,s->s.setAndContinue(RawAnimation.begin().thenLoop("animation."+kind+(CreatureExpansion.spec(kind)!=null&&behaviorState()==4?".stunned":CreatureExpansion.spec(kind)!=null&&behaviorState()==3?".armed":CreatureExpansion.spec(kind)!=null&&behaviorState()==5?".frozen":CreatureExpansion.spec(kind)!=null&&behaviorState()==6?".burrowed":kind.equals("dry_bones")&&behaviorState()==1?".collapsed":kind.equals("koopa")&&behaviorState()==2?".shell":s.isMoving()?".walk":".idle")))));}
  // PathfinderMob also checks walk-target brightness after the registered spawn predicate.
  @Override public float getWalkTargetValue(net.minecraft.core.BlockPos pos,net.minecraft.world.level.LevelReader level){return 0.0f;}
  @Override public AnimatableInstanceCache getAnimatableInstanceCache(){return cache;}
  @Override public void addAdditionalSaveData(CompoundTag n){super.addAdditionalSaveData(n);ability.save(n);n.putInt("ShotCooldown",shotCooldown);n.putInt("DisabledTicks",disabledTicks);n.putInt("BehaviorState",behaviorState());n.putInt("SparedTicks",sparedTicks);n.putBoolean("PreviousNoAi",previousNoAi);n.putDouble("ShellVX",shellVelocity.x);n.putDouble("ShellVZ",shellVelocity.z);}
  @Override public void readAdditionalSaveData(CompoundTag n){super.readAdditionalSaveData(n);ability.load(n);shotCooldown=n.getInt("ShotCooldown");disabledTicks=n.getInt("DisabledTicks");sparedTicks=n.getInt("SparedTicks");previousNoAi=n.getBoolean("PreviousNoAi");entityData.set(STATE,n.getInt("BehaviorState"));shellVelocity=new Vec3(n.getDouble("ShellVX"),0,n.getDouble("ShellVZ"));}
 }
}
