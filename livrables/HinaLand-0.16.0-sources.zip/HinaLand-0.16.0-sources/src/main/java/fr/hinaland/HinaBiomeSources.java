package fr.hinaland;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.biome.*;
import net.minecraftforge.registries.DeferredRegister;

/** Explicit sources: vanilla cannot enter the Overworld; Nether climates run at a smaller scale. */
public final class HinaBiomeSources {
 public static final DeferredRegister<Codec<? extends BiomeSource>> TYPES=DeferredRegister.create(Registries.BIOME_SOURCE,HinaLand.ID);
 static {TYPES.register("exclusive_overworld",()->Exclusive.CODEC);TYPES.register("fractured_nether",()->Fractured.CODEC);}
 public static final class Exclusive extends BiomeSource {
  public static final Codec<Exclusive> CODEC=RecordCodecBuilder.create(i->i.group(Biome.CODEC.listOf().fieldOf("biomes").forGetter((Exclusive s)->s.biomes)).apply(i,Exclusive::new));
  private final List<Holder<Biome>> biomes;
  public Exclusive(List<Holder<Biome>> biomes){
   if(biomes.size()!=28||biomes.stream().anyMatch(b->!b.unwrapKey().orElseThrow().location().getNamespace().equals(HinaLand.ID)))throw new IllegalArgumentException("Exclusive Overworld requires exactly 28 Hina biomes");
   this.biomes=List.copyOf(biomes);
  }
  @Override protected Codec<? extends BiomeSource> codec(){return CODEC;}
  @Override protected Stream<Holder<Biome>> collectPossibleBiomes(){return biomes.stream();}
  @Override public Holder<Biome> getNoiseBiome(int x,int y,int z,Climate.Sampler sampler){
   // Use the world seed through the climate sampler, with stable vertical columns and broad regions.
   var climate=sampler.sample(Math.floorDiv(x,2),0,Math.floorDiv(z,2));
   float t=Climate.unquantizeCoord(climate.temperature()),h=Climate.unquantizeCoord(climate.humidity());
   int family=Math.floorMod((int)Math.floor((t+1)*7),7);
   int variant=h<-.25f?3:h<0?0:h<.3f?1:2;
   return biomes.get(family*4+variant);
  }
 }
 public static final class Fractured extends BiomeSource {
  public static final Codec<Fractured> CODEC=RecordCodecBuilder.create(i->i.group(
   Climate.ParameterList.codec(Biome.CODEC.fieldOf("biome")).fieldOf("biomes").forGetter((Fractured s)->s.parameters),
   Codec.intRange(1,16).fieldOf("coordinate_scale").forGetter((Fractured s)->s.scale)).apply(i,Fractured::new));
  private final Climate.ParameterList<Holder<Biome>> parameters;
  private final int scale;
  public Fractured(Climate.ParameterList<Holder<Biome>> parameters,int scale){this.parameters=parameters;this.scale=scale;}
  public int coordinateScale(){return scale;}
  public Holder<Biome> atScale(int x,int y,int z,Climate.Sampler sampler,int coordinateScale){return parameters.findValue(sampler.sample(x*coordinateScale,y,z*coordinateScale));}
  @Override protected Codec<? extends BiomeSource> codec(){return CODEC;}
  @Override protected Stream<Holder<Biome>> collectPossibleBiomes(){return parameters.values().stream().map(p->p.getSecond());}
  @Override public Holder<Biome> getNoiseBiome(int x,int y,int z,Climate.Sampler sampler){return atScale(x,y,z,sampler,scale);}
 }
}
