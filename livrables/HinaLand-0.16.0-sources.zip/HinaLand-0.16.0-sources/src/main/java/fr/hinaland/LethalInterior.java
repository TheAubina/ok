package fr.hinaland;
import com.google.gson.*;
import java.io.*;
import java.util.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.*;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.levelgen.structure.templatesystem.*;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.BlockHitResult;
/** One persistent finite converted facility, shared by entrances, with individual saved return locations. */
public final class LethalInterior {
 public static final ResourceKey<Level> DIMENSION=ResourceKey.create(Registries.DIMENSION,new ResourceLocation(HinaLand.ID,"lethal_interior"));
 public static final BlockPos ORIGIN=new BlockPos(0,64,0);
 private static final JsonObject MANIFEST=manifest();
 public static final BlockPos ARRIVAL=ORIGIN.offset(vector(MANIFEST.getAsJsonArray("arrival")));
 public static final BlockPos RETURN_DOOR=ORIGIN.offset(vector(MANIFEST.getAsJsonArray("return_door")));
 private static JsonObject manifest(){try(var in=LethalInterior.class.getResourceAsStream("/data/hinaland/lethal_interior_manifest.json")){return JsonParser.parseReader(new InputStreamReader(Objects.requireNonNull(in),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();}catch(IOException e){throw new IllegalStateException("Missing converted Lethal map",e);}}
 private static BlockPos vector(JsonArray a){return new BlockPos(a.get(0).getAsInt(),a.get(1).getAsInt(),a.get(2).getAsInt());}
 public static void register(){ImportedIndustrialBlocks.register();net.minecraftforge.registries.RegistryObject<Block> b=HinaLand.BLOCKS.register("lethal_facility_door",Door::new);HinaLand.WORLD_BLOCKS.put("lethal_facility_door",b);HinaLand.ALL.put("lethal_facility_door",HinaLand.ITEMS.register("lethal_facility_door",()->new DoubleHighBlockItem(b.get(),new Item.Properties())));}
 public static final class Door extends DoorBlock {
  Door(){super(BlockBehaviour.Properties.copy(Blocks.IRON_DOOR),BlockSetType.IRON);}
  @Override public InteractionResult use(BlockState state,Level level,BlockPos pos,Player player,InteractionHand hand,BlockHitResult hit){if(player instanceof ServerPlayer serverPlayer&&hand==InteractionHand.MAIN_HAND)travel(serverPlayer);return InteractionResult.sidedSuccess(level.isClientSide);}
 }
 public static final class MapState extends SavedData {
  private boolean initialized;
  public static MapState load(CompoundTag n){var s=new MapState();s.initialized=n.getBoolean("initialized");return s;}
  @Override public CompoundTag save(CompoundTag n){n.putBoolean("initialized",initialized);return n;}
 }
 public static boolean initialized(ServerLevel level){return level.getDataStorage().computeIfAbsent(MapState::load,MapState::new,"hinaland_lethal_interior").initialized;}
 public static void ensureInterior(ServerLevel level){
  var saved=level.getDataStorage().computeIfAbsent(MapState::load,MapState::new,"hinaland_lethal_interior");if(saved.initialized)return;
  var size=vector(MANIFEST.getAsJsonArray("interior_size"));
  for(int x=-1;x<=size.getX()/16;x++)for(int z=-1;z<=size.getZ()/16;z++)level.getChunk(x,z);
  // A sealed shell prevents missing Bedrock terrain outside the finite complex from becoming a void fall.
  var shell=Blocks.BEDROCK.defaultBlockState();
  for(int x=-1;x<=size.getX();x++)for(int z=-1;z<=size.getZ();z++){level.setBlock(ORIGIN.offset(x,-1,z),shell,2);level.setBlock(ORIGIN.offset(x,size.getY(),z),shell,2);}
  for(int y=0;y<size.getY();y++){
   for(int x=-1;x<=size.getX();x++){level.setBlock(ORIGIN.offset(x,y,-1),shell,2);level.setBlock(ORIGIN.offset(x,y,size.getZ()),shell,2);}
   for(int z=0;z<size.getZ();z++){level.setBlock(ORIGIN.offset(-1,y,z),shell,2);level.setBlock(ORIGIN.offset(size.getX(),y,z),shell,2);}
  }
  for(var item:MANIFEST.getAsJsonArray("tiles")){
   var tile=item.getAsJsonObject();var id=new ResourceLocation(tile.get("template").getAsString());var template=level.getStructureManager().get(id).orElseThrow(()->new IllegalStateException("Missing map tile "+id));var pos=ORIGIN.offset(vector(tile.getAsJsonArray("offset")));
   if(!template.placeInWorld(level,pos,pos,new StructurePlaceSettings().addProcessor(BlockIgnoreProcessor.STRUCTURE_BLOCK),level.random,2))throw new IllegalStateException("Could not place map tile "+id);
  }
  if(!safeFeet(level,ARRIVAL)||!IndoorHabitat.isInterior(level,ARRIVAL))throw new IllegalStateException("Converted Lethal arrival is not a safe covered room: "+ARRIVAL);
  saved.initialized=true;saved.setDirty();
 }
 public static boolean safeFeet(ServerLevel level,BlockPos p){return level.getBlockState(p.below()).isFaceSturdy(level,p.below(),Direction.UP)&&level.getBlockState(p).getCollisionShape(level,p).isEmpty()&&level.getBlockState(p.above()).getCollisionShape(level,p.above()).isEmpty()&&level.getFluidState(p).isEmpty();}
 public static boolean travel(ServerPlayer player){
  long now=player.server.overworld().getGameTime();var memory=player.getPersistentData();if(memory.getLong("HinaLethalCooldown")>now)return false;
  ServerLevel target;double x,y,z;float yaw=player.getYRot(),pitch=player.getXRot();
  if(player.level().dimension().equals(DIMENSION)){
   if(!memory.contains("HinaLethalReturn",Tag.TAG_COMPOUND)){player.displayClientMessage(Component.literal("Aucune entrée mémorisée : utilisez un portail Lethal depuis l’Overworld."),false);return false;}
   var n=memory.getCompound("HinaLethalReturn");target=player.server.getLevel(ResourceKey.create(Registries.DIMENSION,new ResourceLocation(n.getString("dimension"))));if(target==null)return false;
   x=n.getDouble("x");y=n.getDouble("y");z=n.getDouble("z");yaw=n.getFloat("yaw");pitch=n.getFloat("pitch");target.getChunk(BlockPos.containing(x,y,z));
   if(!safeFeet(target,BlockPos.containing(x,y,z))){player.displayClientMessage(Component.literal("La sortie est obstruée. Libérez votre point de retour avant de ressortir."),false);return false;}
  }else{
   target=player.server.getLevel(DIMENSION);if(target==null)return false;ensureInterior(target);
   if(!safeFeet(target,ARRIVAL)){player.displayClientMessage(Component.literal("L’entrée du complexe est obstruée."),false);return false;}
   var n=new CompoundTag();n.putString("dimension",player.level().dimension().location().toString());n.putDouble("x",player.getX());n.putDouble("y",player.getY());n.putDouble("z",player.getZ());n.putFloat("yaw",yaw);n.putFloat("pitch",pitch);memory.put("HinaLethalReturn",n);x=ARRIVAL.getX()+0.5;y=ARRIVAL.getY();z=ARRIVAL.getZ()+0.5;
  }
  memory.putLong("HinaLethalCooldown",now+20);player.teleportTo(target,x,y,z,yaw,pitch);player.fallDistance=0;return true;
 }
}
