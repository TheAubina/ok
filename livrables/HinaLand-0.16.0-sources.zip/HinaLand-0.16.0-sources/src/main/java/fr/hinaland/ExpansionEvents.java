package fr.hinaland;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.*;

@Mod.EventBusSubscriber(modid=HinaLand.ID)
public class ExpansionEvents {
 private static final Random RANDOM=new Random();
 private static final String[] MOB_NAMES={"Goomba","Sprout Mole","Badnik","Rudinn","Hilichurl","Ethereal","Scarlet Fairy","Wild Creature","Facility Worker","Robe Minion","Animatronic"};
 private static final Map<UUID,Long> cooldowns=new HashMap<>();
 public static String region(BlockPos pos){
  // Large deterministic territories separated by ordinary vanilla land.
  int cx=Math.floorDiv(pos.getX(),16),cz=Math.floorDiv(pos.getZ(),16);
  int gx=Math.floorDiv(cx,240),gz=Math.floorDiv(cz,240);
  long h=((long)gx*341873128712L)^((long)gz*132897987541L)^0x48696e614c616e64L;
  Random r=new Random(h);int which=r.nextInt(HinaLand.REGIONS.length);
  int ox=r.nextInt(160)+40,oz=r.nextInt(160)+40;
  double dx=cx-(gx*240+ox),dz=cz-(gz*240+oz);
  return dx*dx+dz*dz<85*85?HinaLand.REGIONS[which]:"vanilla";
 }
 @SubscribeEvent public static void use(PlayerInteractEvent.RightClickItem e){
  if(!(e.getEntity() instanceof ServerPlayer p))return;
  ItemStack stack=e.getItemStack();String id=net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(stack.getItem()).getPath();
  if(!net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(stack.getItem()).getNamespace().equals(HinaLand.ID))return;
  if(!Set.of("flame_staff","frost_staff","lightning_staff","teleport_dagger","healing_orb","invasion_detector","boss_locator","stronghold_compass","echo_pouch").contains(id))return;
  long time=p.level().getGameTime();if(time<cooldowns.getOrDefault(p.getUUID(),0L))return;
  if(id.equals("invasion_detector")){p.displayClientMessage(Component.literal("Région : "+region(p.blockPosition())+" | invasion : "+RiftState.get(p.serverLevel()).invasionRegion),true);return;}
  if(id.equals("boss_locator")){p.displayClientMessage(Component.literal("Les sceaux invoquent des Échos de boss sur les blocs solides."),true);return;}
  if(id.equals("stronghold_compass")){p.displayClientMessage(Component.literal("Utilise les Yeux de l'End pour localiser la forteresse."),true);return;}
  if(id.equals("echo_pouch")){p.addEffect(new MobEffectInstance(MobEffects.LUCK,600,0));cooldowns.put(p.getUUID(),time+600);return;}
  if(id.equals("healing_orb")){p.heal(8);p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,100,1));if(!p.isCreative())stack.shrink(1);cooldowns.put(p.getUUID(),time+100);return;}
  if(id.equals("teleport_dagger")){Vec3 aim=p.getLookAngle();Vec3 dest=p.position().add(aim.scale(5));BlockPos b=BlockPos.containing(dest);if(p.serverLevel().getBlockState(b).getCollisionShape(p.serverLevel(),b).isEmpty()&&p.serverLevel().getBlockState(b.above()).getCollisionShape(p.serverLevel(),b.above()).isEmpty())p.teleportTo(dest.x,dest.y,dest.z);cooldowns.put(p.getUUID(),time+100);return;}
  if(id.equals("flame_staff")||id.equals("frost_staff")||id.equals("lightning_staff")){
   var target=p.level().getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class,p.getBoundingBox().inflate(12),mob->mob!=p&&mob.position().subtract(p.position()).normalize().dot(p.getLookAngle())>0.65);
   if(!target.isEmpty()){var mob=target.get(0);mob.hurt(p.damageSources().playerAttack(p),id.equals("lightning_staff")?10:6);if(id.equals("flame_staff"))mob.setSecondsOnFire(5);if(id.equals("frost_staff"))mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,120,2));}
   stack.hurtAndBreak(1,p,player->player.broadcastBreakEvent(InteractionHand.MAIN_HAND));cooldowns.put(p.getUUID(),time+35);
  }
 }
 @SubscribeEvent public static void altar(PlayerInteractEvent.RightClickBlock e){
  if(!(e.getEntity() instanceof ServerPlayer p))return;
  ServerLevel level=p.serverLevel();BlockPos pos=e.getPos();if(!level.getBlockState(pos).is(HinaLand.WORLD_BLOCKS.get("sanctuary_altar").get()))return;
  e.setCanceled(true);RiftState s=RiftState.get(level);
  if(!level.dimension().equals(Level.END)||!s.unlocked){p.displayClientMessage(Component.literal("Le Sanctuaire ne fonctionne qu'après la première victoire, dans l'End."),true);return;}
  String key=pos.asLong()+"";String boss=HinaLand.bossFromEye(e.getItemStack().getItem());
  if(boss!=null){
   if(s.altarEyes.containsValue(boss)){p.displayClientMessage(Component.literal("Cet œil est déjà déposé."),true);return;}
   if(s.altarEyes.size()>=12){p.displayClientMessage(Component.literal("Douze yeux sont déjà déposés."),true);return;}
   int slot=0;while(s.altarEyes.containsKey(key+":"+slot))slot++;
   String skey=key+":"+slot;s.altarEyes.put(skey,boss);s.altarOwners.put(skey,p.getUUID().toString());if(!p.isCreative())e.getItemStack().shrink(1);s.setDirty();p.displayClientMessage(Component.literal("Œil déposé : "+boss+" ("+s.altarEyes.size()+"/12)"),true);return;
  }
  if(p.isShiftKeyDown()){
   int returned=0;for(String k:new ArrayList<>(s.altarEyes.keySet()))if(k.startsWith(key+":")&&p.getUUID().toString().equals(s.altarOwners.get(k))){String eye=s.altarEyes.remove(k);s.altarOwners.remove(k);p.getInventory().placeItemBackInInventory(new ItemStack(HinaLand.item("eye_"+eye)));returned++;}
   s.setDirty();p.displayClientMessage(Component.literal("Yeux récupérés : "+returned),true);return;
  }
  if(s.altarEyes.size()==12){
   // The altar stores its loadout; actual vanilla End crystal placement still summons the dragon.
   s.dragonPowers.clear();s.dragonPowers.addAll(s.altarEyes.values());s.presets.put(p.getUUID().toString(),String.join(",",s.dragonPowers));s.setDirty();p.displayClientMessage(Component.literal("§dConfiguration du Dragon enregistrée ! Pose 4 cristaux de l'End pour le réinvoquer."),false);
  }else p.displayClientMessage(Component.literal("Sanctuaire : "+s.altarEyes.size()+"/12 yeux. Accroupi + clic droit pour reprendre tes yeux."),true);
 }
 @SubscribeEvent public static void tick(TickEvent.LevelTickEvent e){
  if(e.phase!=TickEvent.Phase.END||!(e.level instanceof ServerLevel level)||!level.dimension().equals(Level.OVERWORLD))return;
  long time=level.getGameTime();if(time%200!=0)return;
  RiftState s=RiftState.get(level);
  if(time-s.lastInvasion>24000&&RANDOM.nextInt(100)<12&&!level.players().isEmpty()){
   ServerPlayer p=level.players().get(RANDOM.nextInt(level.players().size()));String biome=level.getBiome(p.blockPosition()).unwrapKey().map(k->k.location().toString()).orElse("");String reg=HinaWorldgen.family(new net.minecraft.resources.ResourceLocation(biome.isEmpty()?"minecraft:plains":biome));if(!reg.equals("vanilla")){
    s.lastInvasion=time;s.invasionRegion=reg;s.setDirty();for(ServerPlayer q:level.players())q.displayClientMessage(Component.literal("§c[HINA LAND] Invasion aléatoire : "+reg+" !"),false);
    for(int i=0;i<6;i++){BlockPos pos=level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,p.blockPosition().offset(RANDOM.nextInt(26)-13,0,RANDOM.nextInt(26)-13));String[] choices=Arrays.stream(BiomeMobs.NAMES).filter(name->BiomeMobs.region(name).equals(reg)).toArray(String[]::new);if(choices.length==0)continue;var mob=BiomeMobs.ENTITIES.get(choices[RANDOM.nextInt(choices.length)]).get().create(level);if(mob!=null){mob.moveTo(pos.getX()+.5,pos.getY(),pos.getZ()+.5,0,0);level.addFreshEntity(mob);}}
   }
  }
 }
}
