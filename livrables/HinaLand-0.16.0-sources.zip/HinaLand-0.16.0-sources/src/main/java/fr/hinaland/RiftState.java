package fr.hinaland;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import java.util.*;
public class RiftState extends SavedData {
 public final Map<String,String> eyes=new HashMap<>();
 public final List<String> dragonPowers=new ArrayList<>();
 public boolean unlocked=false;
 public final Map<String,String> altarEyes=new HashMap<>();
 public final Map<String,String> altarOwners=new HashMap<>();
 public final Map<String,String> presets=new HashMap<>();
 public long lastInvasion=0;
 public String invasionRegion="";
 public int dragonKills=0;
 public static RiftState get(ServerLevel level){return level.getServer().overworld().getDataStorage().computeIfAbsent(RiftState::load,RiftState::new,"hinaland_rifts");}
 public static RiftState load(CompoundTag tag){RiftState s=new RiftState();CompoundTag e=tag.getCompound("eyes");for(String k:e.getAllKeys())s.eyes.put(k,e.getString(k));for(int i=0;i<tag.getInt("power_count");i++)s.dragonPowers.add(tag.getString("power_"+i));s.unlocked=tag.getBoolean("unlocked");s.dragonKills=tag.getInt("dragonKills");s.lastInvasion=tag.getLong("lastInvasion");s.invasionRegion=tag.getString("invasionRegion");
 for(String k:tag.getCompound("altarEyes").getAllKeys())s.altarEyes.put(k,tag.getCompound("altarEyes").getString(k));
 for(String k:tag.getCompound("altarOwners").getAllKeys())s.altarOwners.put(k,tag.getCompound("altarOwners").getString(k));
 for(String k:tag.getCompound("presets").getAllKeys())s.presets.put(k,tag.getCompound("presets").getString(k));return s;}
 @Override public CompoundTag save(CompoundTag tag){CompoundTag e=new CompoundTag();eyes.forEach(e::putString);tag.put("eyes",e);tag.putInt("power_count",dragonPowers.size());for(int i=0;i<dragonPowers.size();i++)tag.putString("power_"+i,dragonPowers.get(i));tag.putBoolean("unlocked",unlocked);tag.putInt("dragonKills",dragonKills);tag.putLong("lastInvasion",lastInvasion);tag.putString("invasionRegion",invasionRegion);
 CompoundTag a=new CompoundTag();altarEyes.forEach(a::putString);tag.put("altarEyes",a);
 CompoundTag o=new CompoundTag();altarOwners.forEach(o::putString);tag.put("altarOwners",o);
 CompoundTag p=new CompoundTag();presets.forEach(p::putString);tag.put("presets",p);return tag;}
}
