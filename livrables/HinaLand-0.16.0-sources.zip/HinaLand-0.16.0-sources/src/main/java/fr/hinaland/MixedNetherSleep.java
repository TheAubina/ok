package fr.hinaland;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.level.SleepFinishedTimeEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Secondary dimensions share the Overworld clock but cannot write DerivedLevelData themselves. */
@Mod.EventBusSubscriber(modid=HinaLand.ID)
public final class MixedNetherSleep {
 @SubscribeEvent public static void finished(SleepFinishedTimeEvent event){
  if(event.getLevel() instanceof ServerLevel level&&level.dimension().equals(Level.NETHER)&&level.dimensionType().bedWorks()&&level.dimensionType().natural()){
   level.getServer().overworld().setDayTime(event.getNewTime());
  }
 }
}
