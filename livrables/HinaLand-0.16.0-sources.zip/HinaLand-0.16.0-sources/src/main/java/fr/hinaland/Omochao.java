package fr.hinaland;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.navigation.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Items;
import net.minecraft.network.chat.Component;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;

/** Friendly flying helper, using the supplied mechanical Chao CEM model and texture. */
public class Omochao extends PathfinderMob implements GeoEntity {
 private final AnimatableInstanceCache cache=GeckoLibUtil.createInstanceCache(this);
 public Omochao(EntityType<? extends Omochao> type,Level level){super(type,level);moveControl=new FlyingMoveControl(this,10,true);setNoGravity(true);}
 @Override protected PathNavigation createNavigation(Level level){var n=new FlyingPathNavigation(this,level);n.setCanFloat(true);return n;}
 @Override protected void registerGoals(){
  goalSelector.addGoal(1,new Goal(){
   private Player follower;
   {setFlags(java.util.EnumSet.of(Flag.MOVE,Flag.LOOK));}
   @Override public boolean canUse(){follower=level().getNearestPlayer(Omochao.this,12);return follower!=null&&!follower.isSpectator()&&distanceToSqr(follower)>9;}
   @Override public void tick(){if(follower!=null){getLookControl().setLookAt(follower);getMoveControl().setWantedPosition(follower.getX(),follower.getY()+1.2,follower.getZ(),.8);}}
  });goalSelector.addGoal(4,new RandomLookAroundGoal(this));
 }
 @Override public void tick(){super.tick();setNoGravity(true);}
 @Override protected InteractionResult mobInteract(Player p,InteractionHand hand){
  if(p.getItemInHand(hand).is(Items.GOLD_NUGGET)){
   if(!level().isClientSide){heal(5);if(!p.isCreative())p.getItemInHand(hand).shrink(1);p.displayClientMessage(Component.literal("Omochao : surveille les Badniks et leurs tirs !"),true);}
   return InteractionResult.sidedSuccess(level().isClientSide);
  }return super.mobInteract(p,hand);
 }
 public static AttributeSupplier.Builder attributes(){return Mob.createMobAttributes().add(Attributes.MAX_HEALTH,10).add(Attributes.MOVEMENT_SPEED,.2).add(Attributes.FLYING_SPEED,.25);}
 @Override public void registerControllers(AnimatableManager.ControllerRegistrar c){c.add(new AnimationController<>(this,"flight",4,s->s.setAndContinue(RawAnimation.begin().thenLoop("animation.omochao.idle"))));}
 @Override public AnimatableInstanceCache getAnimatableInstanceCache(){return cache;}
}
