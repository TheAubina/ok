package fr.hinaland;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.*;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;

/** Physical diamond/heart bullets, with collision, damage, ownership and bounded lifetime. */
public class DarknerProjectile extends ThrowableItemProjectile {
 public DarknerProjectile(EntityType<? extends DarknerProjectile> type,Level level){super(type,level);}
 public DarknerProjectile(Level level,LivingEntity owner){super(BiomeMobs.DARKNER_BOLT.get(),owner,level);setNoGravity(true);}
 @Override protected Item getDefaultItem(){return HinaLand.item("darkner_diamond");}
 @Override protected void onHitEntity(EntityHitResult hit){super.onHitEntity(hit);if(!level().isClientSide&&hit.getEntity()!=getOwner())hit.getEntity().hurt(damageSources().thrown(this,getOwner()),4);}
 @Override protected void onHit(HitResult hit){super.onHit(hit);if(!level().isClientSide)discard();}
 @Override public void tick(){super.tick();if(!level().isClientSide&&tickCount>120)discard();}
 @Override public Packet<ClientGamePacketListener> getAddEntityPacket(){return net.minecraftforge.network.NetworkHooks.getEntitySpawningPacket(this);}
}
