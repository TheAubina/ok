package fr.hinaland;

import java.util.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.common.ForgeTier;
import net.minecraftforge.common.TierSortingRegistry;

/** Original Hina mining progression, with names and supplied textures inspired by each universe. */
public final class UniverseMinerals {
 public record Family(String name,String primary,String secondary,int durability,float speed,int attack) {}
 public static final List<Family> FAMILIES=List.of(
  new Family("mario","star_fragment","moon_shard",1600,8.5f,3),
  new Family("sonic","chaos_emerald","phantom_ruby",1400,10f,3),
  new Family("omori","dream_glass","heart_stone",1800,8f,3),
  new Family("deltarune","dark_crystal","light_shard",1550,9f,3),
  new Family("genshin","crystal_chunk","amethyst_lump",1700,8.5f,3),
  new Family("overwatch","hardlight_crystal","talon_alloy",1450,9.5f,3),
  new Family("lethal","apparatus_core","company_alloy",1900,8f,3));
 public static final Map<String,Tier> TIERS=new LinkedHashMap<>();
 private UniverseMinerals(){}
 public static void register(){
  for(Family f:FAMILIES){
   for(String material:List.of(f.primary(),f.secondary())){
    HinaLand.ALL.put(material,HinaLand.ITEMS.register(material,()->new Item(new Item.Properties().rarity(material.equals(f.primary())?Rarity.UNCOMMON:Rarity.COMMON))));
    String ore=material+"_ore",storage=material+"_block";
    net.minecraftforge.registries.RegistryObject<Block> oreBlock=HinaLand.BLOCKS.register(ore,()->new DropExperienceBlock(BlockBehaviour.Properties.copy(Blocks.DIAMOND_ORE),UniformInt.of(2,5)));
    net.minecraftforge.registries.RegistryObject<Block> storageBlock=HinaLand.BLOCKS.register(storage,()->new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    HinaLand.WORLD_BLOCKS.put(ore,oreBlock);HinaLand.WORLD_BLOCKS.put(storage,storageBlock);
    HinaLand.ALL.put(ore,HinaLand.ITEMS.register(ore,()->new BlockItem(oreBlock.get(),new Item.Properties())));
    HinaLand.ALL.put(storage,HinaLand.ITEMS.register(storage,()->new BlockItem(storageBlock.get(),new Item.Properties())));
   }
   Tier tier=new ForgeTier(3,f.durability(),f.speed(),f.attack(),18,net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.BLOCK,new ResourceLocation(HinaLand.ID,"needs_"+f.name()+"_mineral_tool")),()->Ingredient.of(HinaLand.item(f.primary())));
   TierSortingRegistry.registerTier(tier,new ResourceLocation(HinaLand.ID,f.name()+"_mineral"),List.of(Tiers.DIAMOND),List.of(Tiers.NETHERITE));
   TIERS.put(f.name(),tier);
   String pick=f.name()+"_mineral_pickaxe",sword=f.name()+"_mineral_sword";
   HinaLand.ALL.put(pick,HinaLand.ITEMS.register(pick,()->new PickaxeItem(tier,1,-2.8f,new Item.Properties())));
   HinaLand.ALL.put(sword,HinaLand.ITEMS.register(sword,()->new SwordItem(tier,3,-2.4f,new Item.Properties())));
  }
 }
}
