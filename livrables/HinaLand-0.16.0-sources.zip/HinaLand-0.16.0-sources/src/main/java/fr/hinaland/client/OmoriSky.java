package fr.hinaland.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import fr.hinaland.HinaLand;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/** Camera-centered skybox, visible only in OMORI; fade by distance to nearby biome borders. */
@Mod.EventBusSubscriber(modid=HinaLand.ID,value=Dist.CLIENT)
public final class OmoriSky {
 private static final ResourceLocation TEXTURE=new ResourceLocation(HinaLand.ID,"textures/environment/omori_sky_reference.png");
 private static boolean omori(net.minecraft.client.multiplayer.ClientLevel level,net.minecraft.core.BlockPos p){return level.getBiome(p).unwrapKey().map(k->fr.hinaland.HinaWorldgen.family(k.location()).equals("omori")).orElse(false);}
 @SubscribeEvent public static void render(RenderLevelStageEvent e){
  Minecraft mc=Minecraft.getInstance();if(e.getStage()!=RenderLevelStageEvent.Stage.AFTER_SKY||mc.level==null||mc.player==null)return;
  var pos=e.getCamera().getBlockPosition();if(!omori(mc.level,pos))return;
  // Fade inside the border. Outside the biome the vanilla sky is untouched.
  float alpha=1;
  for(int d=2;d<=16;d+=2)if(!omori(mc.level,pos.offset(d,0,0))||!omori(mc.level,pos.offset(-d,0,0))||!omori(mc.level,pos.offset(0,0,d))||!omori(mc.level,pos.offset(0,0,-d))){alpha=d/16f;break;}
  if(mc.player.isUnderWater())return;
  PoseStack pose=e.getPoseStack();pose.pushPose();
  RenderSystem.depthMask(false);RenderSystem.disableDepthTest();RenderSystem.disableCull();RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();
  RenderSystem.setShader(GameRenderer::getPositionTexShader);RenderSystem.setShaderTexture(0,TEXTURE);RenderSystem.setShaderColor(1,1,1,alpha);
  for(int face=0;face<6;face++){
   pose.pushPose();
   if(face<4)pose.mulPose(Axis.YP.rotationDegrees(face*90));else pose.mulPose(Axis.XP.rotationDegrees(face==4?90:-90));
   Matrix4f m=pose.last().pose();BufferBuilder b=Tesselator.getInstance().getBuilder();b.begin(VertexFormat.Mode.QUADS,DefaultVertexFormat.POSITION_TEX);
   b.vertex(m,-100,-100,-100).uv(0,1).endVertex();b.vertex(m,100,-100,-100).uv(1,1).endVertex();b.vertex(m,100,100,-100).uv(1,0).endVertex();b.vertex(m,-100,100,-100).uv(0,0).endVertex();BufferUploader.drawWithShader(b.end());pose.popPose();
  }
  RenderSystem.setShaderColor(1,1,1,1);RenderSystem.disableBlend();RenderSystem.enableCull();RenderSystem.enableDepthTest();RenderSystem.depthMask(true);pose.popPose();
 }
}
