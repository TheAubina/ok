package fr.hinaland;

import java.util.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.effect.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;

/** Gameplay approximations for the new game-inspired roster, independent of vanilla zombie/skeleton classes. */
public final class CreatureExpansion {
 public static final Map<String,Integer> SPRITE_FRAMES=Map.ofEntries(Map.entry("lost_sprout_mole",4),Map.entry("harold",4),Map.entry("marsha",4),Map.entry("space_bunny",4),Map.entry("something",1),Map.entry("jigsawry",6),Map.entry("rabbick",3),Map.entry("clover",6),Map.entry("tasque",6),Map.entry("werewire",28),Map.entry("virovirokun",6));
 public record Spec(String id,String family,String label,String behavior,float health,float width,float height){}
 public static final List<Spec> SPECS=List.of(
  new Spec("bobomb","mario","Bob-omb","fuse",14,.7f,.9f),
  new Spec("boo","mario","Boo","gaze",18,.9f,1f),
  new Spec("shy_guy","mario","Maskass","melee",16,.6f,1.1f),
  new Spec("magikoopa","mario","Kamek","magic",20,.65f,1.5f),
  new Spec("hammer_bro","mario","Frère Marto","hammer",24,.7f,1.4f),
  new Spec("piranha_plant","mario","Plante Piranha","plant",20,.8f,1.4f),
  new Spec("monty_mole","mario","Topi Taupe","burrow",18,.7f,.9f),
  new Spec("spiny","mario","Hériss","spikes",16,.8f,.75f),
  new Spec("crabmeat","sonic","Crabmeat","volley",18,.9f,.8f),
  new Spec("caterkiller","sonic","Caterkiller","segments",24,1.2f,.65f),
  new Spec("newtron","sonic","Newtron","cloak",16,.7f,1f),
  new Spec("egg_pawn","sonic","Egg Pawn","gun",24,.8f,1.5f),
  new Spec("lost_sprout_mole","omori","Lost Sprout Mole","berserk",18,.7f,1.2f),
  new Spec("harold","omori","Harold","guard",28,.8f,1.5f),
  new Spec("marsha","omori","Marsha","magic",22,.8f,1.5f),
  new Spec("ye_old_sprout","omori","Ye Old Sprout","melee",10,.7f,1.1f),
  new Spec("space_bunny","omori","Space Bunny","hop",14,.7f,1.1f),
  new Spec("something","omori","SOMETHING","fear",26,.7f,1.5f),
  new Spec("jigsawry","deltarune","Jigsawry","melee",16,.7f,1.1f),
  new Spec("rabbick","deltarune","Rabbick","hop",20,.8f,1.1f),
  new Spec("clover","deltarune","Clover","triple",28,1.1f,1.4f),
  new Spec("tasque","deltarune","Tasque","pounce",18,1f,.8f),
  new Spec("werewire","deltarune","Werewire","electric",26,.8f,1.6f),
  new Spec("virovirokun","deltarune","Virovirokun","heal",20,.8f,1.2f),
  new Spec("hilichurl","genshin","Brutocollinus","club",24,.7f,1.5f),
  new Spec("pyro_slime","genshin","Pyroblob","fire_hop",16,.9f,.8f),
  new Spec("cryo_slime","genshin","Cryoblob","frost_hop",16,.9f,.8f),
  new Spec("ruin_guard","genshin","Gardien des ruines","ruin",60,1.3f,2.7f),
  new Spec("null_trooper","overwatch","Fantassin du Secteur zéro","gun",24,.8f,1.6f),
  new Spec("null_slicer","overwatch","Trancheur du Secteur zéro","pounce",16,.8f,.8f),
  new Spec("null_eradicator","overwatch","Éradicateur du Secteur zéro","guard",42,1.1f,2f),
  new Spec("null_detonator","overwatch","Détonateur du Secteur zéro","fuse",24,.9f,1.2f)
 );
 public static Spec spec(String id){for(var s:SPECS)if(s.id().equals(id))return s;return null;}
 public static boolean ranged(String id){var s=spec(id);return s!=null&&Set.of("magic","hammer","volley","cloak","gun","triple","electric","heal").contains(s.behavior());}
 public static boolean watched(BiomeMobs.ThemedEntity mob,LivingEntity target){
  var direction=mob.getEyePosition().subtract(target.getEyePosition());return target.hasLineOfSight(mob)&&direction.lengthSqr()>0&&target.getViewVector(1).dot(direction.normalize())>.8;
 }
 public static boolean meleeBlocked(BiomeMobs.ThemedEntity mob){
  var s=spec(mob.kind);return s!=null&&(ranged(mob.kind)||s.behavior().equals("plant")||(s.behavior().equals("gaze")&&mob.getTarget()!=null&&watched(mob,mob.getTarget()))||mob.behaviorState()==5||mob.behaviorState()==6);
 }
 public static boolean spared(String id){return id.equals("rudinn")||id.equals("hathy")||(spec(id)!=null&&spec(id).family().equals("deltarune"));}
 public static final class Brain {
  private int cooldown,armed,cloakTicks,hopTicks;
  public int armedTicks(){return armed;}
  public void save(CompoundTag tag){tag.putInt("HinaAbilityCooldown",cooldown);tag.putInt("HinaFuse",armed);tag.putInt("HinaCloakTicks",cloakTicks);tag.putInt("HinaHopTicks",hopTicks);}
  public void load(CompoundTag tag){cooldown=tag.getInt("HinaAbilityCooldown");armed=tag.getInt("HinaFuse");cloakTicks=tag.getInt("HinaCloakTicks");hopTicks=tag.getInt("HinaHopTicks");}
  private void shoot(BiomeMobs.ThemedEntity mob,LivingEntity target,String item,int spread){
   var direction=target.getEyePosition().subtract(mob.position().add(0,mob.getBbHeight()*.6,0)).normalize();
   for(int i=-spread;i<=spread;i++){
    var bolt=new DarknerProjectile(mob.level(),mob);bolt.setItem(new ItemStack(net.minecraftforge.registries.ForgeRegistries.ITEMS.getValue(new net.minecraft.resources.ResourceLocation(item))));bolt.setPos(mob.getX(),mob.getY()+mob.getBbHeight()*.6,mob.getZ());var d=direction.yRot(i*.2f);bolt.shoot(d.x,d.y,d.z,1.1f,0);mob.level().addFreshEntity(bolt);
   }
  }
  public void tick(BiomeMobs.ThemedEntity mob){
   var spec=spec(mob.kind);if(spec==null||mob.isCalm())return;if(cooldown>0)cooldown--;if(hopTicks>0)hopTicks--;
   if(cloakTicks>0){cloakTicks--;mob.setInvisible(true);if(cloakTicks==0)mob.setInvisible(false);}
   var target=mob.getTarget();String behavior=spec.behavior();
   if(behavior.equals("burrow")){
    boolean hidden=target!=null&&mob.distanceToSqr(target)>36;mob.setBehaviorState(hidden?6:0);mob.setInvisible(hidden);if(hidden){mob.getNavigation().stop();mob.setDeltaMovement(0,mob.getDeltaMovement().y,0);return;}
   }
   if(behavior.equals("gaze")){
    boolean frozen=target!=null&&watched(mob,target);mob.setBehaviorState(frozen?5:0);if(frozen){mob.getNavigation().stop();mob.setDeltaMovement(Vec3.ZERO);return;}
   }
   if(armed>0){
    mob.setBehaviorState(3);armed--;if(mob.level() instanceof net.minecraft.server.level.ServerLevel server){server.sendParticles(net.minecraft.core.particles.ParticleTypes.SMOKE,mob.getX(),mob.getEyeY(),mob.getZ(),1,.1,.1,.1,0);}
    if(armed==0){mob.level().explode(mob,mob.getX(),mob.getY(),mob.getZ(),mob.kind.equals("bobomb")?2:3,Level.ExplosionInteraction.NONE);mob.discard();}return;
   }
   if(target==null)return;double distance=mob.distanceToSqr(target);
   if(behavior.equals("fuse")&&distance<9){armed=mob.kind.equals("bobomb")?40:55;mob.setBehaviorState(3);return;}
   if(behavior.equals("plant")){
    mob.getNavigation().stop();mob.setDeltaMovement(0,mob.getDeltaMovement().y,0);if(distance<5&&cooldown==0){target.hurt(mob.damageSources().mobAttack(mob),3);cooldown=35;}return;
   }
   if(behavior.contains("hop")||behavior.equals("pounce")){
    if(mob.onGround()&&distance<100&&hopTicks==0){var d=target.position().subtract(mob.position()).multiply(1,0,1).normalize();mob.setDeltaMovement(d.x*.3,.42,d.z*.3);hopTicks=35;}
   }
   if(behavior.equals("fear")&&distance<64&&mob.hasLineOfSight(target)&&cooldown==0){target.addEffect(new MobEffectInstance(MobEffects.DARKNESS,80,0));cooldown=100;}
   if(behavior.equals("heal")&&cooldown==0){
    for(var ally:mob.level().getEntitiesOfClass(BiomeMobs.ThemedEntity.class,mob.getBoundingBox().inflate(5),m->BiomeMobs.region(m.kind).equals("deltarune")))ally.heal(2);
   }
   if((ranged(mob.kind)||behavior.equals("ruin"))&&distance<225&&mob.hasLineOfSight(target)&&cooldown==0){
    String item=behavior.equals("hammer")?"hinaland:mario_hammer":Set.of("gun","ruin").contains(behavior)?"minecraft:iron_nugget":behavior.equals("electric")?"hinaland:darkner_diamond":behavior.equals("magic")?"hinaland:star_fragment":"hinaland:darkner_diamond";
    shoot(mob,target,item,Set.of("volley","triple","ruin").contains(behavior)?1:0);cooldown=behavior.equals("ruin")?120:behavior.equals("heal")?160:65;
    if(behavior.equals("cloak"))cloakTicks=25;
   }
  }
 }
 public static float incomingDamage(BiomeMobs.ThemedEntity mob,net.minecraft.world.damagesource.DamageSource source,float amount){
  var spec=spec(mob.kind);if(spec==null)return amount;
  if(spec.behavior().equals("spikes")&&source.getEntity() instanceof Player p&&source.getDirectEntity()==p)p.hurt(mob.damageSources().mobAttack(mob),2);
  if(spec.behavior().equals("ruin")&&source.is(net.minecraft.tags.DamageTypeTags.IS_PROJECTILE)&&source.getDirectEntity()!=null&&source.getDirectEntity().getY()>=mob.getY()+mob.getBbHeight()*.7)mob.recoverFor(80);
  if(spec.behavior().equals("guard")&&source.is(net.minecraft.tags.DamageTypeTags.IS_PROJECTILE))return amount*.4f;
  return amount;
 }
 public static void contact(BiomeMobs.ThemedEntity mob,Entity victim){
  var spec=spec(mob.kind);if(spec==null||!(victim instanceof LivingEntity target))return;
  if(spec.behavior().equals("fire_hop"))target.setSecondsOnFire(3);
  if(spec.behavior().equals("frost_hop"))target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,60,0));
 }
}
