package fr.hinaland;

import net.minecraft.nbt.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Convert old Overworld dungeon spawners rather than leave them displaying forbidden vanilla enemies. */
@Mod.EventBusSubscriber(modid=HinaLand.ID)
public final class SpawnerMigration {
 private record Pending(ServerLevel level, LevelChunk chunk) {}
 private static final ConcurrentLinkedQueue<Pending> pending = new ConcurrentLinkedQueue<>();
 public static String replacement(String family){return switch(family){case "genshin"->"hilichurl";case "overwatch"->"null_trooper";case "sonic"->"crabmeat";case "omori"->"lost_sprout_mole";case "deltarune"->"jigsawry";case "lethal"->"lethal_hoarding_bug";default->"goomba";};}
 public static boolean convert(ServerLevel level,BlockPos pos,SpawnerBlockEntity spawner){
  if(!level.dimension().equals(Level.OVERWORLD))return false;
  var data=spawner.getSpawner().save(new CompoundTag());String name=data.getCompound("SpawnData").getCompound("entity").getString("id");var id=ResourceLocation.tryParse(name);
  if(id==null||!id.getNamespace().equals("minecraft"))return false;var type=ForgeRegistries.ENTITY_TYPES.getValue(id);
  if(type==null||type.getCategory()!=net.minecraft.world.entity.MobCategory.MONSTER)return false;
  var biome=level.getBiome(pos).unwrapKey().orElseThrow().location();String family=HinaWorldgen.family(biome);
  var spawn=new CompoundTag();var entity=new CompoundTag();entity.putString("id",HinaLand.ID+":"+replacement(family));spawn.put("entity",entity);spawn.put("custom_spawn_rules",new CompoundTag());data.put("SpawnData",spawn);
  var choice=new CompoundTag();choice.putInt("weight",1);choice.put("data",spawn.copy());var potentials=new ListTag();potentials.add(choice);data.put("SpawnPotentials",potentials);
  data.putShort("SpawnCount",(short)1);data.putShort("MaxNearbyEntities",(short)3);data.putShort("MinSpawnDelay",(short)240);data.putShort("MaxSpawnDelay",(short)480);
  spawner.getSpawner().load(level,pos,data);spawner.setChanged();return true;
 }
 @SubscribeEvent public static void load(ChunkEvent.Load event){
  if(!(event.getLevel() instanceof ServerLevel level)||!level.dimension().equals(Level.OVERWORLD)||!(event.getChunk() instanceof LevelChunk chunk))return;
  // execute() may run inline during chunk loading. Wait for a completed server tick instead.
  pending.add(new Pending(level,chunk));
 }
 @SubscribeEvent public static void tick(TickEvent.ServerTickEvent event){
  if(event.phase!=TickEvent.Phase.END)return;
  for(int i=0;i<32;i++){var task=pending.poll();if(task==null)break;var pos=task.chunk.getPos();
   if(task.level.getChunkSource().getChunkNow(pos.x,pos.z)!=task.chunk)continue;
   for(var be:task.chunk.getBlockEntities().values())if(be instanceof SpawnerBlockEntity spawner)convert(task.level,spawner.getBlockPos(),spawner);
  }
 }
 @SubscribeEvent public static void stopped(ServerStoppedEvent event){pending.clear();}
}
