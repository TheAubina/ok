package fr.hinaland.client;
import fr.hinaland.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.*;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mojang.logging.LogUtils;
import java.util.Random;

/** Client-local playlist, stopped on biome-family changes; MUSIC slider and pause are respected. */
@Mod.EventBusSubscriber(modid=HinaLand.ID,value=Dist.CLIENT)
public final class BiomeMusic {
 private static final Random RANDOM=new Random();
 private static String family="vanilla",previous="";private static SoundInstance current;
 private static int delay=0,age=0;private static boolean confirmed=false;
 private static String family(Minecraft mc){return mc.level==null||mc.player==null?"vanilla":HinaWorldgen.family(mc.level.getBiome(mc.player.blockPosition()).unwrapKey().orElseThrow().location());}
 @SubscribeEvent public static void suppressVanillaMusic(PlaySoundEvent event){
  var sound=event.getSound();
  if(sound!=null&&sound.getSource()==SoundSource.MUSIC&&sound.getLocation().getNamespace().equals("minecraft")&&!family(Minecraft.getInstance()).equals("vanilla"))event.setSound(null);
 }
 @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event){
  if(event.phase!=TickEvent.Phase.END)return;var mc=Minecraft.getInstance();if(mc.isPaused())return;
  String next=family(mc);
  if(!next.equals(family)){
   if(current!=null)mc.getSoundManager().stop(current);current=null;
   if(!next.equals("vanilla"))mc.getMusicManager().stopPlaying();
   family=next;delay=20;age=0;confirmed=false;
  }
  if(family.equals("vanilla")||mc.level==null)return;
  if(mc.options.getSoundSourceVolume(SoundSource.MUSIC)<=0)return;
  if(current!=null){
   age++;boolean active=mc.getSoundManager().isActive(current);
   if(active&&!confirmed){LogUtils.getLogger().info("Hina music active: {}",current.getLocation());confirmed=true;}
   if(active||age<40)return;
   current=null;delay=180+RANDOM.nextInt(181);confirmed=false;
  }
  if(delay-->0)return;
  String track=HinaSounds.choose(family,previous,RANDOM);if(track==null)return;
  previous=track;current=SimpleSoundInstance.forMusic(HinaSounds.TRACKS.get(track).get());age=0;confirmed=false;
  mc.getSoundManager().play(current);
 }
}
