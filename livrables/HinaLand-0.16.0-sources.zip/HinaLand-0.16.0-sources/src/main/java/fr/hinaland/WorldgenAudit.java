package fr.hinaland;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.nio.file.*;
import java.util.*;

/** Operator-only diagnostic: sample the actual generator without generating thousands of chunks. */
@Mod.EventBusSubscriber(modid=HinaLand.ID)
public final class WorldgenAudit {
 @SubscribeEvent public static void naturalSpawn(net.minecraftforge.event.entity.living.MobSpawnEvent.FinalizeSpawn e){
  if(e.getSpawnType()==net.minecraft.world.entity.MobSpawnType.NATURAL||e.getSpawnType()==net.minecraft.world.entity.MobSpawnType.CHUNK_GENERATION)e.getEntity().getPersistentData().putString("HinaSpawnOrigin",e.getSpawnType().name());
 }
 @SubscribeEvent public static void commands(RegisterCommandsEvent e){
  e.getDispatcher().register(Commands.literal("hinaland").requires(s->s.hasPermission(2)).then(Commands.literal("auditspawns").executes(ctx->{
   var level=ctx.getSource().getLevel();Map<String,Integer> counts=new TreeMap<>();int natural=0,surface=0;
   var mobs=level.getEntitiesOfClass(net.minecraft.world.entity.Mob.class,new net.minecraft.world.phys.AABB(BlockPos.containing(ctx.getSource().getPosition())).inflate(128));
   for(var mob:mobs){String origin=mob.getPersistentData().getString("HinaSpawnOrigin");if(!origin.isEmpty())natural++;if(level.canSeeSky(mob.blockPosition()))surface++;counts.merge(net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getKey(mob.getType())+"/"+origin,1,Integer::sum);}
   String report="Spawn audit near "+ctx.getSource().getPosition()+": "+counts+"; total="+mobs.size()+", natural/chunk_generation="+natural+", open_sky="+surface;
   ctx.getSource().sendSuccess(()->Component.literal(report),true);return natural;
  })));
  e.getDispatcher().register(Commands.literal("hinaland").requires(s->s.hasPermission(2))
   .then(Commands.literal("auditworldgen").executes(ctx->{
    ServerLevel level=ctx.getSource().getLevel();
    var source=level.getChunkSource().getGenerator().getBiomeSource();
    var sampler=level.getChunkSource().randomState().sampler();
    StringBuilder csv=new StringBuilder("x,z,biome\n");Map<String,Integer> counts=new TreeMap<>();Map<String,String> positions=new TreeMap<>();
    for(int x=-8192;x<=8192;x+=128)for(int z=-8192;z<=8192;z+=128){
     var holder=source.getNoiseBiome(Math.floorDiv(x,4),20,Math.floorDiv(z,4),sampler);
     String key=holder.unwrapKey().orElseThrow().location().toString();
     csv.append(x).append(',').append(z).append(',').append(key).append('\n');counts.merge(key,1,Integer::sum);
     if(key.startsWith("hinaland:"))positions.putIfAbsent(key,x+" "+z);
    }
    try{Files.writeString(Path.of("hinaland-worldgen-audit-"+level.dimension().location().getPath()+".csv"),csv);}catch(java.io.IOException ex){ctx.getSource().sendFailure(Component.literal(ex.toString()));return 0;}
    ctx.getSource().sendSuccess(()->Component.literal("Worldgen sample (16641 points at Y=80): "+counts+"; first positions: "+positions),true);
    return counts.size();
   })));
 }
}
