Bêta Forge 1.20.1 : textures adaptées des cinq packs, 16 biomes dont DELTARUNE, 12 fleurs naturelles, Skelerex/Pokey/Rudinn/Hathy/Omochao et 27 objets MirRP. Les sept monstres Lethal restent dans des zones couvertes, Ghost Girl comprise.

- [JAR installable](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/hinaland-0.10.0.jar)
- [Modpack de test avec dépendances](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.10.0-modpack-test-4.zip)
- [Sources](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.10.0-sources.zip)
- [Rapport de validation et limites](https://github.com/TheAubina/ok/blob/main/docs/RAPPORT_PACKS_CREATURES_0.10_FR.md)

22 GameTests réussis ; 16 sites naturels, 12 fleurs et 9 coffres vérifiés ; client et serveur de production avec 22 mods. IA adaptées, Rudinn/Hathy en sprites ; plusieurs CEM et le système complet de lunes, quotas et vaisseau restent à développer. Campagne complète non testée.

Retirer l’ancien JAR. Le JAR seul demande GeckoLib 4.4.9 et TerraBlender 3.0.1.7. Utiliser un monde neuf ou de nouveaux chunks.
