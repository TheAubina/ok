# Hina Land 0.15.0 — Forge 1.20.1

Le mod compilé est `hinaland-0.15.0.jar`, à installer dans `mods` avec GeckoLib 4.4.9 et TerraBlender 3.0.1.7. Java 17 et Forge 47.3.0 sont la combinaison vérifiée. Les autres mods fournis sont regroupés dans le modpack de test 9.

Cette version ajoute **70 constructions : dix nouvelles par chacun des sept univers de l’Overworld**, en plus des 21 précédentes. Douze sont de petits donjons de surface ; les dix nouvelles constructions Lethal sont des extérieurs sans nouveau donjon. Chaque ajout contient un coffre de son univers ; les constructions Mario comportent également des blocs « ? » interactifs.

Voir [le catalogue](CATALOGUE_STRUCTURES_0.15_FR.md) pour les inspirations identifiées et [le rapport](RAPPORT_STRUCTURES_0.15_FR.md) pour les preuves et limites. Les équipements, biomes, mobs, portails complets et améliorations de la version 0.14 restent présents.

Pour compiler et vérifier les sources générées :

```bash
./gradlew runGameTestServer build --max-workers=2 --console=plain
python tools/check_assets.py
python tools/check_expansion_assets.py
python tools/check_universe_structures.py
```

La suite vérifiée exécute **49 GameTests Forge**. Exiger leur message de réussite, pas uniquement `BUILD SUCCESSFUL`. Les classes de test et leur modèle vide sont exclus du JAR de production. Les ressources générées présentes permettent la compilation sans les réimporter. Les importateurs plus anciens nécessitent les archives d’origine ; leurs gros fichiers ne sont pas dans le ZIP. En cas de régénération, exécuter `create_universe_structures.py` après les générateurs 0.14, pour conserver les 70 ajouts.

Explorer de nouveaux chunks pour les nouvelles constructions. Les bâtiments et ruines déjà enregistrés ne sont pas remplacés. Une copie Normal 0.13 avait été testée avec 0.14 ; cette version vérifie ses ajouts dans un nouveau monde Normal. Les migrations antérieures, les presets autres que Normal et le multijoueur simultané restent à vérifier.

Pour rechercher un nouvel ajout en tant qu’opérateur : `/locate structure #hinaland:mario_new_landmarks`, en remplaçant `mario` par `sonic`, `omori`, `deltarune`, `genshin`, `overwatch` ou `lethal`. Une recherche peut bloquer le tick serveur pendant plusieurs secondes ; l’exploration normale ne lance pas cette commande.
