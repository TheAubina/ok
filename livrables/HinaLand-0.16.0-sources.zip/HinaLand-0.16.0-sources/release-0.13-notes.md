Bêta pour Minecraft Java 1.20.1, Forge 47.3.0 et Java 17.

Les entrées March et Offense mènent au complexe Lethal converti de la carte Bedrock fournie, avec retour mémorisé par joueur. L’Overworld Normal est limité aux 28 biomes Hina ; les apparitions de surface, le placement des structures et le Nether noyé sont corrigés.

- [JAR installable](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/hinaland-0.13.0.jar)
- [Modpack de test 7 — 22 JAR](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.13.0-modpack-test-7.zip)
- [Sources compilables](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.13.0-sources.zip)
- [Rapport des vérifications et limites](https://github.com/TheAubina/ok/blob/main/docs/RAPPORT_GENERATION_LETHAL_0.13_FR.md)

32 GameTests Forge requis réussis, compilation et réobfuscation Gradle. Client/serveur testés avec les 22 mods ; apparitions naturelles et passages de portes observés. Les trois téléchargements sont vérifiés en HTTP 200, avec empreintes identiques aux fichiers locaux.

**Créer un monde neuf de type Normal.** Le JAR seul nécessite GeckoLib 4.4.9 et TerraBlender 3.0.1.7. Migration des anciennes sauvegardes, longue partie et multijoueur simultané non validés. End custom, quotas/navette Lethal et transport de coffres pleins restent à développer.
