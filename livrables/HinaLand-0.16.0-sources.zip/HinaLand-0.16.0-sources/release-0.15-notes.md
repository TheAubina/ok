Hina Land 0.15.0, Minecraft Java Forge 1.20.1 / Forge 47.3.0 / Java 17.

70 nouvelles constructions : dix par chacun des sept univers de l’Overworld, en plus des 21 précédentes. Douze petits donjons de surface hors Lethal ; dix nouveaux extérieurs Lethal sans donjon. Coffres thématiques et nouveaux blocs Mario interactifs dans les bâtiments.

49 GameTests Forge réussis ; 280 placements orientés, tenue des décors, accès aux coffres, génération du butin et douze générateurs d’ennemis contrôlés. Huit nouvelles structures vérifiées en génération naturelle, affichées dans le client ; apparition des Goombas et ouverture du coffre du donjon Mario naturel. Les 70 structures ne sont pas toutes parcourues naturellement sur plusieurs graines et l’équilibrage prolongé reste à vérifier.

[Télécharger le JAR compilé](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/hinaland-0.15.0.jar)

[Télécharger le modpack de test 9](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.15.0-modpack-test-9.zip)

[Sources compilables](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.15.0-sources.zip)

[Rapport et limites](https://github.com/TheAubina/ok/blob/main/docs/RAPPORT_STRUCTURES_0.15_FR.md) · [Catalogue des 70 ajouts](https://github.com/TheAubina/ok/blob/main/docs/CATALOGUE_STRUCTURES_0.15_FR.md) · [SHA256](https://github.com/TheAubina/ok/blob/main/docs/SHA256SUMS-0.15.0.txt)

Remplacer le précédent JAR ; GeckoLib et TerraBlender sont requis et inclus dans le pack. Explorer de nouveaux chunks pour les nouvelles constructions. Les bâtiments déjà enregistrés ne sont pas reconstruits.
