# Hina Land 0.2.0 — sources expérimentales

Ce projet **n’est pas un JAR testé**. Une machine avec Java 17, Gradle 8 et accès Internet aux dépôts Forge est indispensable pour compiler : `gradle build`.

Cette version ajoute des blocs et essences pour 11 régions, des objets avec effets, des spawns de créatures placeholders, une invasion aléatoire basique et un autel avec dépôt/récupération de douze yeux.

**Limites majeures** : les régions sont des zones calculées, PAS des biomes Minecraft enregistrés; les monstres sont des zombies placeholders, et la séparation stricte des spawns vanilla n'est PAS assurée; l'autel ne possède pas encore 12 socles physiques et n'est pas protégé contre tous les scénarios d'abandon; le Dragon n'a pas les cinq phases et son combat n'est pas équilibré. Les quêtes FTB existantes restent à vérifier en jeu. Les recettes ne sont pas encore équilibrées. Ne pas utiliser sur un monde précieux sans sauvegarde.

Installation quêtes : copier `config/ftbquests/quests` dans le dossier FTB Quests du monde, selon la version de FTB Quests.
