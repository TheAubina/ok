# Hina Land 0.7.0 — rapport de bêta du 11 octobre 2026

## Livrable et installation

Le fichier `hinaland-0.7.0.jar` est compilé pour Java 17 et réobfusqué par ForgeGradle. Placer les trois JAR du paquet d'installation dans `mods/`, sur Minecraft Java 1.20.1 / Forge 47.3.0 : Hina Land, GeckoLib 4.4.9 et TerraBlender 3.0.1.7. Créer un nouveau monde pour découvrir les nouveaux biomes. Les mêmes dépendances sont nécessaires sur serveur. Les classes et structures GameTest ne sont pas distribuées dans le JAR.

## Résultats vérifiés

| Élément | Vérification réalisée | Limite |
|---|---|---|
| Compilation | `build`, `reobfJar` et génération du JAR réussis ; installation cloud rejouée avec succès | Pas de test sur Windows |
| Ressources | Analyse de 489 JSON, références de textures, 13 modèles et leurs animations | La cohérence des fichiers ne prouve pas la qualité artistique |
| Biomes Mario, Sonic, OMORI | Serveur exécutant le JAR : localisation des trois biomes, lecture des chunks sauvegardés confirmant leurs identifiants et sols naturels | Structures et végétation thématique détaillée à développer |
| Ciel OMORI | Client Forge connecté au serveur : skybox violette affichée ; ciel vanilla observé hors du biome | Pas de vérification avec shaders ou mods de ciel |
| Six créatures des biomes | Enregistrement, attributs et isolation des listes de spawns vérifiés ; entités invoquées sur serveur | Modèles/textures simples ; fréquence naturelle et équilibrage en longue partie non validés |
| Sept créatures Lethal | Les sept types invoqués ; modèles observés en client Survie, dont le fusil Nutcracker | Toutes les séquences d'animation et interactions ne sont pas validées visuellement |
| Hoarding Bug | Ramassage, sauvegarde/relecture NBT et restitution sans duplication testés ; conservation de trois diamants vérifiée après redémarrage du vrai serveur | Nid/dépôt de butin absent ; vol à tester en partie |
| Coil Head | Immobilisation et refus d'attaque sous le regard, reprise hors du regard testés | Situations multijoueurs prolongées non testées |
| Ghost Girl | UUID de victime et persistance testés ; rendu conditionné à la victime | Séquence complète de hantise à enrichir |
| Bunker Spider | Pose de toile et délai testés | Escalade et nettoyage des toiles à terminer |
| Nutcracker | Cinq projectiles par tir, dégâts, deux tirs puis rechargement testés | Projectiles de type flèche ; pas de système complet d'arme récupérable |
| Bracken | Retraite sous le regard et poursuite hors du regard testées | Comportement expérimental, pas reproduction complète du jeu original |
| Barber | Saut d'attaque testé | Combat prolongé et synchronisation de toutes les animations non testés |
| Chargement réel | JAR chargé sur serveur Forge dédié, connexion du client réussie ; monde également chargé dans le serveur intégré du client de développement | Le chargement solo est un contrôle de base, pas une campagne complète sur le JAR en client de production |

La dernière exécution `build runGameTestServer` a terminé avec **BUILD SUCCESSFUL** et **All 9 required tests passed**. Les neuf tests couvrent l'enregistrement des entités, les spawns par biome et les sept comportements indiqués ci-dessus. Le contrôle des ressources est distinct de ces tests. La tâche Gradle `test` ne contient pas de tests JUnit.

Les contrôles graphiques ont utilisé un affichage virtuel et OpenGL logiciel. L'audio a utilisé un backend muet : aucun résultat audible n'est revendiqué. Les avertissements d'authentification du client de développement hors ligne ne prouvent pas un problème du mod. Les téléchargements d'assets vanilla ont finalement abouti.

## Corrections et contenu ajouté

Imports et accolades invalides corrigés ; œufs Forge adaptés à l'enregistrement différé ; versions des outils/dépendances fixées. Les monstres sont des entités propres et ne dérivent plus du Zombie vanilla. Six modèles, textures et animations simples ont été ajoutés pour les créatures Mario/Sonic/OMORI. TerraBlender ajoute les trois biomes à l'Overworld en conservant les biomes vanilla. Les règles de surface posent les sols thématiques. Les ressources de blocs disposent de loot tables et de tags d'outils. Le ciel utilise l'illustration OMORI fournie. Le butin et la victime Lethal sont sauvegardés ; les actions animées sont prioritaires sur la locomotion.

## À terminer ou non testé

Les installations Lethal et leurs spawns naturels restent absents : utiliser les œufs ou les commandes du README. Les soixante blocs décoratifs ne sont pas tous placés par la génération. Les six modèles de biome sont des ébauches. Les monstres Lethal ont une IA de bêta ; leurs animations originales disponibles sont raccordées, mais les séquences de mort et les comportements complets ne sont pas tous présents. Aucun son Lethal original n'a été fourni.

Les autres univers, structures, boss complets, Dragon en cinq phases, Sanctuaire à douze socles et intégrations des mods personnels restent dans la feuille de route. Les anciennes mécaniques de boss/quêtes sont des prototypes, pas des fonctionnalités validées. FTB Quests et les mods personnels n'ont pas été testés, leurs installations n'étant pas fournies. Aucun test de compatibilité shaders, charge multijoueur, endurance ou équilibrage de survie prolongé n'a été réalisé.

Le cahier des charges a été lu intégralement ; cette bêta traite la priorité d'installation et de jouabilité de base, sans présenter le projet complet comme terminé. Voir `ROADMAP_FR.md` pour la suite.

## Preuves fournies

Le paquet contient le journal final des neuf GameTests, le journal de compilation rejouée et des captures du ciel OMORI, du ciel extérieur, des modèles Lethal et du chargement solo. Les captures proviennent des exécutions de développement ; le serveur dédié a utilisé le JAR de production. La dernière modification de priorité des contrôleurs d'animation a repassé compilation et les neuf GameTests ; elle n'a pas fait l'objet d'une nouvelle session visuelle complète.
