# Hina Land 0.4 — Lethal beta (sources)

Ajouts réels : rendu GeckoLib 4, modèles convertis, contrôleur de locomotion, tir du Nutcracker, toiles de Bunker Spider, stockage/récupération d’objets du Hoarding Bug, bond du Barber, effet de hantise Ghost Girl, attaque furtive Bracken, Coil-Head immobilisé sous regard.

**Non testé/compilé :** dépendances Forge/GeckoLib indisponibles localement. Les animations doivent être ajustées aux noms et à la hiérarchie exportés ; les sons originaux ne sont pas inclus. Cette version est un projet de développement, pas un JAR certifié jouable.
