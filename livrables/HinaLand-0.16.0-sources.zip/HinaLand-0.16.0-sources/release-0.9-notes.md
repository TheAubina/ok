Bêta Forge 1.20.1 / 47.3.0, Java 17.

- [Télécharger le JAR 0.9.0](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/hinaland-0.9.0.jar)
- [Télécharger le modpack de test 3 — 22 JAR](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.9.0-modpack-test-3.zip)
- [Rapport précis des tests et limites](https://github.com/TheAubina/ok/blob/main/docs/RAPPORT_AUDIO_GEOLOGIE_0.9_FR.md)

Cinq pistes fournies intégrées : Mario, Sonic et trois morceaux OMORI. Faces d’herbe, extrémités des troncs et dessus du grès raccordés. Roche et bedrock thématiques jusque sous Y=0 dans les nouveaux chunks.

Build réussi, 12 GameTests Forge réussis, 12 sites naturels vérifiés, cinq OGG décodés et leurs lectures actives confirmées sur le client de production. Pas d’écoute humaine possible dans le cloud. Les images originales des fleurs sont introuvables dans les pièces jointes accessibles. Lunaria Media manque et trois succès associés restent bloqués.

Remplacer l’ancien JAR ; ne pas garder deux versions. Le JAR seul nécessite GeckoLib 4.4.9 et TerraBlender 3.0.1.7. Copier la configuration du pack pour les régions agrandies. Les anciens chunks ne sont pas convertis.
