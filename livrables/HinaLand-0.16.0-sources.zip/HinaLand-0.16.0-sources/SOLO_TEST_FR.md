# Hina Land — Essai solo (sources expérimentales)

Cette archive **n’est pas un JAR compilé** et les modèles Blockbench ne sont pas encore rendus par GeckoLib.

## Préparation
1. Installer JDK 17 et Gradle compatible ForgeGradle 6.
2. Dans le dossier du projet, lancer `gradle build` (accès internet nécessaire au premier téléchargement Forge).
3. Si la compilation réussit, copier `build/libs/hinaland-*.jar` dans `mods` de Forge 1.20.1.
4. Créer un nouveau monde solo de test.

## Commandes de vérification
`/summon hinaland:lethal_bracken ~ ~ ~`
`/summon hinaland:lethal_coil_head ~ ~ ~`
`/summon hinaland:lethal_hoarding_bug ~ ~ ~`
`/summon hinaland:lethal_barber ~ ~ ~`
`/summon hinaland:lethal_bunker_spider ~ ~ ~`
`/summon hinaland:lethal_ghost_girl ~ ~ ~`
`/summon hinaland:lethal_nutcracker ~ ~ ~`

Tester les entités en Survie, car Créatif et Spectateur ne sont pas ciblés.

## Ce qui reste manquant
- Modèles et animations GeckoLib non branchés : rendu zombie provisoire.
- Audio Lethal original absent.
- IA fidèle du Nutcracker, de la Ghost Girl, du Hoarding Bug et de l'araignée non finalisée.
- Aucune compilation Minecraft ni essai en jeu réalisé ici.

Ne pas confondre cette archive de sources avec une bêta jouable validée.
