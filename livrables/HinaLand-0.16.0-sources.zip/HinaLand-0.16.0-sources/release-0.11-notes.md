Bêta Forge 1.20.1 : Genshin, Overwatch et Lethal rejoignent l’Overworld (28 biomes Hina Land), avec 24 fleurs et 32 structures/décors. Le Nether combine les 63 biomes vanilla jouables et permet le sommeil ainsi que la réapparition au lit.

- [JAR installable](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/hinaland-0.11.0.jar)
- [Modpack avec dépendances](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.11.0-modpack-test-5.zip)
- [Sources](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.11.0-sources.zip)
- [Rapport des tests et limites](https://github.com/TheAubina/ok/blob/main/docs/RAPPORT_MONDES_STRUCTURES_0.11_FR.md)

25 GameTests réussis ; 12 sites naturels des nouveaux thèmes et 9 sites Nether inspectés ; les 12 nouvelles fleurs comptées ; 17 débuts de structures naturelles enregistrés. Client et serveur avec 22 mods, sommeil/réveil/réapparition dans le Nether et accès par portail vanilla vérifiés.

Remplacer l’ancien JAR. Java 17, Forge 47.3.0, GeckoLib 4.4.9 et TerraBlender 3.0.1.7 requis. Créer un nouveau monde pour reproduire le Nether testé : migration des anciennes sauvegardes non validée.

L’End custom reste à réaliser. Certaines plantes hautes, les monstres Genshin/Overwatch et le système complet Lethal restent à développer. Une longue campagne Survie et les performances d’une exploration prolongée ne sont pas validées.
