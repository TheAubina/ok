# Lethal Company alpha integration — IMPORTANT

Seven **placeholder entities** registered with spawn eggs in Hina Land creative tab: bracken, coil_head, hoarding_bug, barber, bunker_spider, ghost_girl, nutcracker. Jester remains in the separate existing mod.

The Blockbench source models (including shotgun) are copied to `reference_models/lethal/`. They are NOT yet rendered or animated in-game; Forge/GeckoLib conversion, client renderers, animations and authoritative AI remain to implement. The current entity class uses a Zombie base and very rough behavior approximations; **do not consider these canon-faithful or production ready**. Spawn eggs exist for manual tests; natural facility-only spawning is not implemented.

Audio: wiki pages identify original sound event names, but NO third-party game audio has been embedded in this archive. Use legally sourced files placed at `assets/hinaland/sounds/lethal/`, convert to OGG, and register sound events. Example source page names: Bracken FoundBracken/AngeredBracken/CrackNeckBracken; Nutcracker NutcrackerAngry/NutcrackerDie/NutcrackerHitEye/NutcrackerTurn/ShotgunReloadNutcracker; Ghost Girl Ghost Chimes, Ghost Laughter, SkipWalk. Reference: https://lethal-company.fandom.com/wiki/Bracken and /wiki/Nutcracker and /wiki/Ghost_Girl.

Compile and runtime NOT verified. The upstream 0.2 alpha has not been established to compile. This is source-only, not a ready-to-play JAR.
