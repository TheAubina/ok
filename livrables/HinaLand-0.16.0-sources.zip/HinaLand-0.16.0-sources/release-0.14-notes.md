Hina Land bêta 0.14.0 pour Minecraft Java Forge 1.20.1.

- Trois nouveaux minerais par chacun des sept univers, leurs blocs et trois niveaux d’équipement : 21 pioches, 42 armes, 84 pièces d’armure, 231 recettes minérales.
- Blocs « ? » Mario réellement interactifs, récompense unique, pièces échangeables et Super Champignon consommable.
- Onze nouvelles constructions, dont sept portails du Nether complets et allumés. Les ruines déjà sauvegardées ne sont pas reconstruites automatiquement.
- Peaufinage des silhouettes, UV, échelles et poses des créatures. Les références directes officielles des deux robots Sonic restent à compléter.
- 40 GameTests Forge réussis, contrôle avec un client et serveur de 22 mods, 21 minerais observés dans 63 chunks naturels, jardin Mario naturel interactif et trajet aller-retour par portail. Une copie de sauvegarde 0.13 a été ouverte et contrôlée.

Téléchargements directs :

- [JAR compilé](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/hinaland-0.14.0.jar)
- [Modpack de test 8](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.14.0-modpack-test-8.zip)
- [Sources](https://github.com/TheAubina/ok/raw/refs/heads/main/livrables/HinaLand-0.14.0-sources.zip)
- [Rapport complet et limites](https://github.com/TheAubina/ok/blob/main/docs/RAPPORT_PEAUFINAGE_0.14_FR.md)

Java 17, Forge 47.3.0, GeckoLib 4.4.9 et TerraBlender 3.0.1.7. Les dépendances sont incluses dans le modpack. Remplacer l’ancien JAR ; pour les nouveautés, explorer de nouveaux chunks. Équilibrage de longue partie et multijoueur simultané non validés ; certains équipements utilisent les textures vanilla. Les limites antérieures du compagnon de quêtes, de Lunaria Media, de l’End custom et des missions Lethal restent documentées.
