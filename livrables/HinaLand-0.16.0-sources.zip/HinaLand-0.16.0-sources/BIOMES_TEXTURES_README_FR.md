# Hina Land 0.5 — Pack textures Mario / Sonic / OMORI

Textures extraites des trois packs fournis, sans écraser `minecraft:` globalement.

- 60 nouveaux blocs de construction et de décoration enregistrés sous `hinaland:`.
- Trois blocs `*_soil` reprennent désormais les textures herbe (haut/côté) et terre (bas) du pack correspondant.
- Les ressources des trois packs sont intégrées aux ressources du mod et visibles dans son onglet créatif.
- Image `textures/environment/omori_sky_reference.png` conservée comme référence pour le ciel OMORI.
- Les biomes ne sont PAS encore des biomes Forge enregistrés : la fonction `region()` du code précédent définit des territoires mais ne change pas les blocs du terrain ni le ciel.
- Aucun rendu de ciel dynamique n'est intégré à cette livraison ; ne pas confondre la texture de référence avec un ciel actif.
- Compilation Forge/GeckoLib non vérifiée : ZIP de sources, pas un JAR.

## Prochaine étape technique pour le ciel
Enregistrer les biomes OMORI via datapack/registries, créer un effet client de ciel dépendant du biome et une transition douce aux frontières.
