# Suite du cahier des charges Hina Land

Référence : cahier des charges joint par l'utilisateur. Priorité conservée : livrer la bêta compilée avant d'étendre le contenu.

## Prochain lot de bêta

- Essais solo intégrés prolongés, équilibre du combat, performances et transitions aux frontières.
- Raffiner les six modèles de créatures thématiques ; végétation, architecture et structures propres aux trois biomes.
- Affiner les animations de locomotion, attaque, mort et les hitboxes des sept Lethal. Le contrôleur déclenche les animations d'attaque disponibles ; les animations de mort dédiées ne sont pas fournies.
- Hoarding Bug : passer du transport d'une pile au dépôt/protection d'un véritable nid accessible ; comportement de vol complet.
- Ghost Girl : essais avec plusieurs clients ; effets et apparitions individualisés plus élaborés.
- Nutcracker : animations de scan/rechargement plus précises et projectile dédié visuellement distinct des flèches utilisées pour les plombs de cette bêta.
- Bunker Spider : gestion du cycle de vie des toiles et navigation d'araignée plus fidèle.
- Installations Lethal, spawns liés aux structures, sons fournis/licenciés ; Jester demeure un mod distinct.

## Contenu multivers

Conserver les univers dans l'Overworld et les biomes vanilla. Créer les territoires et fragments Deltarune, Genshin, ZZZ, Manoir Scarlet/Touhou, Pokémon, Lethal, R.E.P.O. et FNAF. Kirby reste exclu. Ajouter progressivement végétation, structures, bestiaires, musique et progression.

Les 16 boss hérités restent des échos zombies de test : remplacer chacun par un boss avec arène, modèle, patterns, animations, yeux et récompenses distincts. Conditionner les premières rencontres à l'exploration et la réinvocation aux victoires enregistrées.

## End et progression

- Valider et sécuriser les 12 yeux différents du portail.
- Construire un Dragon utilisant exactement les 12 pouvoirs choisis, en cinq phases.
- Sanctuaire physique à douze socles, restitution des yeux, quatre cristaux consommés ; empêcher duplication et conflits après redémarrage.
- Participants, difficulté dynamique et récompenses individuelles, dont Œil du Dragon et premier Cœur du Multivers.
- Advancements et livre FTB Quests vérifiés ; conserver les invasions aléatoires, sans déclencheur de gameplay volontaire.

## Intégrations optionnelles

Inspecter les vrais JAR/IDs/APIs avant toute liaison avec OverCraft, Flandre, Luigi Boots, Brobot, Aubrey, Jonathan, Jester, Robe R.E.P.O., LunariaMedia ou Portal Gun. Ces JAR ne figurent pas dans les fichiers reçus. Conserver les intégrations optionnelles pour permettre le lancement sans eux.
