# Hina Land 0.3.1 — Lethal behavior source preview (NOT COMPILED)

This is an experimental source update, not a validated Minecraft beta JAR.

## Changes since 0.3
- Coil-Head: checks every nearby survival player rather than only the nearest; removes dangerous setNoAi toggling.
- Bracken: retreat vector normalized to avoid runaway coordinates; pursues unwatched nearby player.
- Ghost Girl: persistent target UUID, explicitly does not claim per-player visibility (client rendering missing).
- Nutcracker: basic movement detection; not yet a ranged gun AI.
- Barber and Bunker Spider: explicit short-range target acquisition.
- All entities ignore creative/spectator players in new target selection.

## Known blockers
- Blockbench models and GeckoLib animations are NOT wired into the renderer.
- All seven mobs still inherit Zombie AI/renderer, so Coil-Head can still move through inherited goals even when watched.
- No genuine Lethal Company audio assets included; redistribution rights not established.
- No successful Forge build or Minecraft launch test performed.
- No natural Lethal-only spawning, correct Ghost Girl per-player visibility, Nutcracker gun, spider web system or hoarding inventory.

## Testing once the project builds
1. Use Java 17 and Minecraft Forge 1.20.1.
2. Build with a working ForgeGradle/Gradle installation.
3. In a throwaway creative world use `/summon hinaland:lethal_bracken`, and repeat for coil_head, hoarding_bug, barber, bunker_spider, ghost_girl, nutcracker.
4. Check entity rendering, survival targeting, multiplayer, save/reload, death and server logs.
5. Do not use in a production server or valuable world.
