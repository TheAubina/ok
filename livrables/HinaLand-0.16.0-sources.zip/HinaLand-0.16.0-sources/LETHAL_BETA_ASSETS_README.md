# Hina Land Lethal — asset conversion preview

Seven Blockbench models were exported to GeckoLib-style geometry, animation JSON and PNG textures. These files are not yet wired to entity renderers; they have not been loaded in Minecraft. Geometry UV/pivots and animations require in-game verification.

The source project requires Forge 1.20.1 and a working Java 17/Gradle build environment. Do not install the ZIP into mods/.
