# Hina Land 0.6 — Test des biomes en solo

**Sources uniquement : compilation et démarrage non vérifiés.** Nécessite Forge 1.20.1 et GeckoLib 4, Java 17.

1. Créer un monde de test avec commandes activées.
2. Se placer dans une zone dégagée de l'Overworld.
3. `/hinaland testbiome mario 24` — convertit les blocs de surface et affecte le véritable biome `hinaland:mario` avec la commande Minecraft `fillbiome`.
4. `/hinaland where` — confirme l'identifiant du biome au niveau du joueur.
5. `/hinaland testbiome sonic 24` ou `/hinaland testbiome omori 24` pour les autres régions.
6. `/hinaland spawn goomba`, `/hinaland spawn koopa`, `/hinaland spawn sprout_mole`, `/hinaland spawn forest_bunny`, `/hinaland spawn motobug`, `/hinaland spawn buzz_bomber`.
7. `/hinaland spawn lethal_bracken`, `lethal_coil_head`, `lethal_nutcracker`, `lethal_ghost_girl`, `lethal_hoarding_bug`, `lethal_bunker_spider`, `lethal_barber`.

Les six mobs Mario/Sonic/OMORI sont **des zombies provisoires nommés** avec l'IA vanilla ; pas des modèles/IA spécifiques. Le ciel OMORI violet est défini dans les propriétés de biome mais le motif étoilé fourni n'est pas encore dessiné comme une skybox client. Les régions générées automatiquement ne sont pas encore intégrées au pipeline de génération des biomes de l'Overworld. La commande est prévue pour tester les biomes et les textures immédiatement dans un monde existant.

**Attention** : la commande remplace des blocs de surface de façon permanente. Utiliser un monde de test. Les textures existantes sont réutilisées sans modification.
